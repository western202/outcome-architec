import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import API_BASE_URL from "../../Config";

const student = createApi({
  reducerPath: "student",
  baseQuery: fetchBaseQuery({ baseUrl: API_BASE_URL }),
  tagTypes: ["students"],
  endpoints: (builder) => ({
    inviteStudent: builder.mutation({
      query: (data) => ({
        url: "/api/student/register-student",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["students"],
    }),
    allStudents: builder.query({
      query: (id) => ({
        url: `/api/student/all-students/${id}`,
        method: "GET",
      }),
      providesTags: ["students"],
    }),
    instructorPosts: builder.query({
      query: (id) => ({
        url: `/api/student/${id}/all-posts`,
        method: "GET",
      }),
    }),
    getNotifications: builder.query({
      query: (id) => ({
        url: `/api/notifications/all-notifications/${id}`,
        method: "GET",
      }),
    }),
    deleteStudents: builder.mutation({
      query: ({ id, data }) => ({
        url: `/api/student/delete-students/${id}`,
        method: "DELETE",
        data,
      }),
      invalidatesTags: ["students"],
    }),
    studentSingleProfile: builder.query({
      query: (id) => ({
        url: `/api/single-user/${id}`,
        method: "GET",
      }),
    }),
  }),
});

export const {
  useInviteStudentMutation,
  useAllStudentsQuery,
  useInstructorPostsQuery,
  useGetNotificationsQuery,
  useDeleteStudentsMutation,
  useStudentSingleProfileQuery,
} = student;

export default student;
