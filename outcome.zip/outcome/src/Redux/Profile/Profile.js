import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import API_BASE_URL from "../../Config";

const profile = createApi({
  reducerPath: "profileApi",
  baseQuery: fetchBaseQuery({ baseUrl: API_BASE_URL }),
  endpoints: (builder) => ({
    updateProfile: builder.mutation({
      query: ({ userID, data }) => ({
        url: `/api/${userID}/update-user`,
        method: "PATCH",
        body: data,
      }),
    }),
    profileData: builder.query({
      query: (userID) => ({
        url: `/api/user-data/${userID}`,
        method: "GET",
      }),
    }),
  }),
});

export const { useUpdateProfileMutation, useProfileDataQuery } = profile;

export default profile;
