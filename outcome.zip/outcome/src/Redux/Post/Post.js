import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import API_BASE_URL from "../../Config";

const post = createApi({
  reducerPath: "postApi",
  baseQuery: fetchBaseQuery({ baseUrl: API_BASE_URL }),
  tagTypes: ["createPost", "sharedPosts", "replies"],
  endpoints: (builder) => ({
    addPost: builder.mutation({
      query: ({ userid, data }) => ({
        url: `/api/posts/${userid}/create-post`,
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["createPost"],
    }),
    // replyComment: builder.mutation({
    //   query: ({ postId, userID, commentId, comments }) => {
    //     return {
    //       url: `/api/${userID}/posts/${postId}/comments/${commentId}/replies`,
    //       method: "POST",
    //       body: { comments },
    //     };
    //   },
    // }),
    replyComment: builder.mutation({
      query: ({ postId, userID, commentId, reply }) => {
        return {
          url: `api/${userID}/posts/${postId}/comments/${commentId}/replies`,
          method: "POST",
          body: { comments: reply },
        };
      },
      invalidatesTags: ["replies"],
    }),
    deleteComment: builder.mutation({
      query: ({ postId, userId, commentId }) => {
        return {
          url: `/api/${userId}/post/${postId}/delete-comments/${commentId}`,
          method: "DELETE",
        };
      },
    }),
    // sharePost: builder.mutation({
    //   query: ({ postId, userId, data }) => {
    //     return {
    //       url: `/api/${userId}/shared-post/${postId}`,
    //       method: "POST",
    //       data,
    //     };
    //   },
    //   invalidatesTags: ["sharedPosts"],
    // }),
    // getSharePost: builder.query({
    //   query: (userId) => {
    //     return {
    //       url: `/api/${userId}/shared-posts`,
    //       method: "GET",
    //     };
    //   },
    //   providesTags: ["sharedPosts"],
    // }),
    // deleteSharePost: builder.mutation({
    //   query: ({ userId, postId }) => {
    //     return {
    //       url: `/api/${userId}/delete-shared/${postId}`,
    //       method: "POST",
    //     };
    //   },
    //   invalidatesTags: ["sharedPosts"],
    // }),
    singlePostComment: builder.query({
      query: (id) => {
        return {
          url: `/api/all-comments/${id}`,
          method: "GET",
        };
      },
      providesTags: ["replies"],
    }),
    deleteReplies: builder.mutation({
      query: ({ userID, postID, commentID, replyID }) => {
        return {
          url: `/api/${userID}/post/${postID}/delete-replies/${commentID}/${replyID}`,
          method: "DELETE",
          // body: data,
        };
      },
      invalidatesTags: ["replies"],
    }),
  }),
});

export const {
  useAddPostMutation,
  useReplyCommentMutation,
  useUpdatePostMutation,
  useDeleteCommentMutation,
  useSharePostMutation,
  useGetSharePostQuery,
  useDeleteSharePostMutation,
  useSinglePostCommentQuery,
  useDeleteRepliesMutation,
} = post;

export default post;
