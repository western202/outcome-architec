import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import API_BASE_URL from "../../Config";

const instructor = createApi({
  reducerPath: "instructor",
  baseQuery: fetchBaseQuery({ baseUrl: API_BASE_URL }),
  tagTypes: ["instructor"],
  endpoints: (builder) => ({
    inviteInstructor: builder.mutation({
      query: (data) => ({
        url: "/api/instructor/register-instructor",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["instructor"],
    }),
    allInstructors: builder.query({
      query: (id) => ({
        url: "/api/instructor/all-instructors",
        method: "GET",
      }),
      providesTags: ["instructor"],
    }),
    deleteInstructors: builder.mutation({
      query: ({ id }) => ({
        url: `/api/instructor/delete-instrctor/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["instructor"],
    }),
  }),
});

export const {
  useInviteInstructorMutation,
  useAllInstructorsQuery,
  useDeleteInstructorsMutation,
} = instructor;

export default instructor;
