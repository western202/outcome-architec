import { configureStore } from "@reduxjs/toolkit";
import adminLogin from "./AdminSlices/AdminLogin";
import student from "./StudentSlices/Student";
import instructor from "./InstructorSlices/Instructor";
import global from "./GlobalSlices/Global";
import post from "./Post/Post";
import profile from "./Profile/Profile";
import sheduleEvent from "./ScheduleEventSlice/ScheduleEvent";
const store = configureStore({
  reducer: {
    [adminLogin.reducerPath]: adminLogin.reducer,
    [student.reducerPath]: student.reducer,
    [instructor.reducerPath]: instructor.reducer,
    [global.reducerPath]: global.reducer,
    [post.reducerPath]: post.reducer,
    [profile.reducerPath]: profile.reducer,
    [sheduleEvent.reducerPath]: sheduleEvent.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware()
      .concat(adminLogin.middleware)
      .concat(instructor.middleware)
      .concat(student.middleware)
      .concat(global.middleware)
      .concat(post.middleware)
      .concat(profile.middleware)
      .concat(sheduleEvent.middleware),
});

export default store;
