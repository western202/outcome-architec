import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import API_BASE_URL from "../../Config";

const sheduleEventQueries = createApi({
  reducerPath: "sheduleEvents",
  baseQuery: fetchBaseQuery({ baseUrl: API_BASE_URL }),
  tagTypes: ["Post_Event"],
  endpoints: (builder) => ({
    createEvent: builder.mutation({
      query: ({ data, instructorId }) => {
        return {
          url: `/api/events/${instructorId}/schedule-event`,
          method: "POST",
          body: data,
        };
      },
      invalidatesTags: ["Post_Event"],
    }),
    getInstructorEvent: builder.query({
      query: (instructorId) => {
        return {
          url: `/api/events/${instructorId}/get-schedules-by-instructor`,
          method: "GET",
        };
      },
      providesTags: ["Post_Event"],
    }),
    getAllEvent: builder.query({
      query: () => {
        return {
          url: `/api/events/all-events`,
          method: "GET",
        };
      },
      providesTags: ["Post_Event"],
    }),
    getStudentEvent: builder.query({
      query: (instructorId) => {
        return {
          url: `/api/events/${instructorId}/get-schedules-by-instructor`,
          method: "GET",
        };
      },
      providesTags: ["Post_Event"],
    }),
    deleteInstructorEvent: builder.mutation({
      query: ({ instructorId, eventId }) => {
        return {
          url: `/api/events/${instructorId}/delete-event/${eventId}`,
          method: "DELETE",
        };
      },
      invalidatesTags: ["Post_Event"],
    }),
    updateEvent: builder.mutation({
      query: ({ data, instructorId, eventId }) => {
        return {
          url: `/api/events/${instructorId}/update-event/${eventId}`,
          method: "PATCH",
          body: data,
        };
      },
      invalidatesTags: ["Post_Event"],
    }),
  }),
});

export const {
  useCreateEventMutation,
  useGetInstructorEventQuery,
  useGetAllEventQuery,
  useGetStudentEventQuery,
  useDeleteInstructorEventMutation,
  useUpdateEventMutation,
} = sheduleEventQueries;

export default sheduleEventQueries;
