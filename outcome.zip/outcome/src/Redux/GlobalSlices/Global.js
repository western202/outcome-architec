import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import API_BASE_URL from "../../Config";

const global = createApi({
  reducerPath: "globalApis",
  baseQuery: fetchBaseQuery({ baseUrl: API_BASE_URL }),
  tagTypes: [
    "getPosts",
    "reviews",
    "courses",
    "likes",
    "singleCourse",
    "singlePosts",
  ],
  endpoints: (builder) => ({
    completeInfo: builder.mutation({
      query: ({ id, data }) => {
        // Destructure the `body` object directly in the query function parameters
        return {
          url: `/api/complete-info/${id}`,
          method: "PATCH",
          body: data, // Use `body` instead of `data` to send the payload
        };
      },
    }),

    getPost: builder.query({
      query: (id) => {
        return {
          url: `/api/posts/instructor-posts/${id}`,
          method: "GET",
        };
      },
      providesTags: ["getPosts"],
    }),

    deletePost: builder.mutation({
      query: ({ postId, userID, data }) => {
        return {
          url: `/api/posts/${userID}/delete-post/${postId}`,
          method: "DELETE",
          data,
        };
      },
      invalidatesTags: ["getPosts"],
    }),

    GetPostsForAdmin: builder.query({
      query: () => {
        // Destructure the `body` object directly in the query function parameters
        return {
          url: `/api/get-all-posts`,
          method: "GET",
        };
      },
    }),
    coursesByInstructor: builder.query({
      query: (id) => {
        // Destructure the `body` object directly in the query function parameters
        return {
          url: `api/courses/all-courses/${id}`,
          method: "GET",
        };
      },
      providesTags: ["courses"],
    }),

    singleCourse: builder.query({
      query: (id) => {
        // Destructure the `body` object directly in the query function parameters
        return {
          url: `api/courses/single-course/${id}`,
          method: "GET",
        };
      },
      providesTags: ["singleCourse"],
    }),

    courseReview: builder.mutation({
      query: ({ courseID, studentID, review, rating }) => {
        return {
          url: `/api/reviews/${courseID}/post-review/${studentID}`,
          method: "POST",
          body: {
            review,
            rating,
          },
        };
      },
      invalidatesTags: ["reviews"],
    }),

    getReviews: builder.query({
      query: (id) => {
        return {
          url: `/api/reviews/${id}/all-reviews`,
          method: "GET",
        };
      },
      providesTags: ["reviews"],
    }),

    singlePost: builder.query({
      query: (id) => {
        return {
          url: `/api/posts/${id}/single-post`,
          method: "GET",
        };
      },
      providesTags: ["singlePosts"],
    }),

    createCourse: builder.mutation({
      query: (data) => ({
        url: `/api/courses/create-course/${data.id}`,
        method: "POST",
        body: data.formData,
      }),
      invalidatesTags: ["courses"],
    }),

    likes: builder.mutation({
      query: (data) => {
        const { userID, postID, ...body } = data;
        return {
          url: `/api/${userID}/like/${postID}`,
          method: "POST",
          body,
        };
      },
      providesTags: ["likes"],
    }),

    allCourses: builder.query({
      query: () => {
        return {
          url: "/api/courses/all-courses",
          method: "GET",
        };
      },
      providesTags: ["courses"],
    }),

    postComment: builder.mutation({
      query: ({ postId, userID, comments }) => {
        return {
          url: `api/${userID}/posts/${postId}/comments`,
          method: "POST",
          body: { comments },
        };
      },
      invalidatesTags: ["singlePosts"],
    }),

    deleteInstructorCourse: builder.mutation({
      query: ({ userId, courseId }) => {
        return {
          url: `api/courses/${userId}/delete-courses/${courseId}`,
          method: "DELETE",
        };
      },
      invalidatesTags: ["courses"],
    }),
    updateCourse: builder.mutation({
      query: ({ instructorID, courseID, data }) => {
        return {
          url: `/api/courses/${instructorID}/update-course/${courseID}`,
          method: "PATCH",
          body: data,
        };
      },
      invalidatesTags: ["courses"],
    }),
    addRating: builder.mutation({
      query: ({ studentID, courseID, reviewID, data }) => {
        return {
          url: `/api/reviews/${courseID}/update-review/${studentID}/${reviewID}`,
          method: "PATCH",
          body: { rating: data },
        };
      },
      invalidatesTags: ["reviews"],
    }),
    getRating: builder.query({
      query: (courseID) => {
        return {
          url: `/api/reviews/${courseID}/average-reviews`,
          method: "GET",
        };
      },
      providesTags: ["reviews"],
    }),
    deleteReview: builder.mutation({
      query: ({ reviewID }) => {
        return {
          url: `/api/reviews/delete-review/${reviewID}`,
          method: "DELETE",
        };
      },
      invalidatesTags: ["reviews"],
    }),
    uploadCourse: builder.mutation({
      query: ({ instructorID, courseID, data }) => {
        return {
          url: `api/courses/${instructorID}/upload-course-files/${courseID}`,
          method: "PATCH",
          body: data,
        };
      },
      invalidatesTags: ["singleCourse"],
    }),
    deleteCourse: builder.mutation({
      query: ({ userID, courseID, data }) => {
        return {
          url: `/api/courses/${userID}/remove-course-files/${courseID}`,
          method: "PATCH",
          body: { files: data },
        };
      },
      invalidatesTags: ["singleCourse"],
    }),
    allStudent: builder.query({
      query: () => {
        return {
          url: `/api/student/all-students`,
          method: "GET",
        };
      },
      invalidatesTags: ["singleCourse"],
    }),
    updatePost: builder.mutation({
      query: ({ postId, userID, data }) => {
        return {
          url: `/api/posts/${userID}/update-post/${postId}`,
          method: "PATCH",
          body: data,
        };
      },
      invalidatesTags: ["getPosts"],
    }),
    // new
    sharePost: builder.mutation({
      query: ({ postId, userId, data }) => {
        return {
          url: `/api/${userId}/shared-post/${postId}`,
          method: "POST",
          data,
        };
      },
      invalidatesTags: ["getPosts"],
    }),
    getSharePost: builder.query({
      query: (userId) => {
        return {
          url: `/api/${userId}/shared-posts`,
          method: "GET",
        };
      },
      providesTags: ["getPosts"],
    }),
    deleteSharePost: builder.mutation({
      query: ({ userId, postId }) => {
        return {
          url: `/api/${userId}/delete-shared/${postId}`,
          method: "POST",
        };
      },
      invalidatesTags: ["getPosts"],
    }),
  }),
});

export const {
  useCompleteInfoMutation,
  useCreateImgPostMutation,
  useGetPostQuery,
  useDeletePostMutation,
  useCreateVidPostMutation,
  useCreateContentPostMutation,
  useGetPostsForAdminQuery,
  useCoursesByInstructorQuery,
  useCourseReviewMutation,
  useGetReviewsQuery,
  useCreateCourseMutation,
  useSingleCourseQuery,
  useSinglePostQuery,
  useLikesMutation,
  useAllCoursesQuery,
  usePostCommentMutation,
  useReplyCommentMutation,
  useDeleteInstructorCourseMutation,
  useUpdateCourseMutation,
  useAddRatingMutation,
  useGetRatingQuery,
  useDeleteReviewMutation,
  useUploadCourseMutation,
  useDeleteCourseMutation,
  useAllStudentQuery,
  useUpdatePostMutation,
  useSharePostMutation,
  useGetSharePostQuery,
  useDeleteSharePostMutation,
} = global;

export default global;
