import React from "react";
import { useRoutes } from "react-router-dom";
import AdminRoutes from "./routes/AdminRoutes";
import InstructorRoutes from "./routes/InstructorRoutes";
import StudentRoutes from "./routes/StudentRoutes";
import LoggedOut from "./routes/LoggedOut";
import { useEffect } from "react";
import "swiper/css/bundle";
import socket from "./Utils/Socket";

function App() {
  const admin = useRoutes(AdminRoutes);
  const instructor = useRoutes(InstructorRoutes);
  const student = useRoutes(StudentRoutes);
  const loggodOut = useRoutes(LoggedOut);

  useEffect(() => {
    socket.on("firstEvent", (msg) => console.log(msg));
  }, []);

  const userData = JSON.parse(localStorage.getItem("user"));

  let routes;

  switch (userData?.user?.role?.[0]) {
    case "Admin":
      routes = admin;
      break;
    case "Instructor":
      routes = instructor;
      break;
    case "Student":
      routes = student;
      break;
    default:
      routes = loggodOut;
      break;
  }

  return <>{routes}</>;
}

export default App;
