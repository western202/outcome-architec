import { CircularProgressbar } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";
import style from "./chart.module.css";

function Circularchart({ percentage = 60 }) {
  return (
    <div style={{ width: "10rem" }} className={style.circleChart}>
      <CircularProgressbar value={percentage} text={`${percentage}%`} />
    </div>
  );
}

export default Circularchart;
