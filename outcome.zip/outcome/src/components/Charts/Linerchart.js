import React, { useEffect, useState } from "react";
import style from "./chart.module.css";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { DarkColors, LightColors } from "../../Utils/Colors";
import { DarkContext } from "../../Context/DarkContext";
import { useContext } from "react";

const data = [
  {
    name: "Mon",
    uv: 4000,
    pv: 2400,
    amt: 2400,
  },
  {
    name: "Tue",
    uv: 3000,
    pv: 1398,
    amt: 2210,
  },
  {
    name: "Wed",
    uv: 2000,
    pv: 9800,
    amt: 2290,
  },
  {
    name: "Thu",
    uv: 2780,
    pv: 3908,
    amt: 2000,
  },
  {
    name: "Fri",
    uv: 1890,
    pv: 4800,
    amt: 2181,
  },
  {
    name: "Sat",
    uv: 1890,
    pv: 4800,
    amt: 2181,
  },
  {
    name: "Sun",
    uv: 1890,
    pv: 4800,
    amt: 2181,
  },
];

function Linerchart() {
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);
  return (
    <div
      style={{ marginTop: "3rem", height: "18rem" }}
      className="d-flex flex-column gap-1"
    >
      <span
        className={`d-flex justify-content-between ${style.chartContainer}`}
      >
        <h3
          className={style.linerHeading}
          style={
            darkmode
              ? {
                  color: DarkColors.headingcolor,
                  fontWeight: "700",
                  paddingLeft: "1rem",
                  fontSize: "1.5vmax",
                }
              : {
                  color: LightColors.headingcolor,
                  fontWeight: "700",
                  paddingLeft: "1rem",
                  fontSize: "1.5vmax",
                }
          }
        >
          Learning Activity
        </h3>
        <div
          className={` ${style.Subheading} d-flex gap-3 justify-content-end`}
          style={{ width: "15vmax" }}
        >
          <span className={` ${style.week} d-flex gap-1 align-items-center`}>
            <div
              style={{
                width: "1rem",
                height: "1rem",
                borderRadius: "50%",
                gap: "0.5rem",
                backgroundColor: "blue",
              }}
            ></div>
            <p
              className={`${style.linerWeekName} m-0 w-auto`}
              // style={{  }}
              style={
                darkmode
                  ? { color: DarkColors.headingcolor, fontSize: "1vmax" }
                  : { color: LightColors.headingcolor, fontSize: "1vmax" }
              }
            >
              Last Week
            </p>
          </span>
          <span className={` ${style.month} d-flex gap-1 align-items-center`}>
            <div
              style={{
                width: "1rem",
                height: "1rem",
                borderRadius: "50%",
                gap: "0.5rem",
                backgroundColor: "#6AA22C",
              }}
            ></div>
            <p
              className={`${style.linerMonthName} m-0 w-auto`}
              // style={{ fontSize: "1vmax" }}
              style={
                darkmode
                  ? { color: DarkColors.headingcolor, fontSize: "1vmax" }
                  : { color: LightColors.headingcolor, fontSize: "1vmax" }
              }
            >
              This Week
            </p>
          </span>
        </div>
      </span>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart width={600} height={300} data={data}>
          <CartesianGrid />
          <XAxis dataKey="name" padding={{ left: 30, right: 30 }} />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="pv" stroke="blue" />
          <Line type="monotone" dataKey="uv" stroke="#6AA22C" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export default Linerchart;
