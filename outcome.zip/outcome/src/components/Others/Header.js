import React, { useState } from "react";
import { Col, Container, Row } from "react-bootstrap";
import styles from "./header.module.css";
import { faBell, faBars, faBookOpen } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Form } from "react-bootstrap";
import logo from "../../assets/logo.png";
// import profile_img from "../../assets/profile_img.png";
import { useNavigate } from "react-router-dom";
import Sidebar from "../Sidebar/Sidebar";
import { LightColors, DarkColors } from "../../Utils/Colors";
import darkmodelogo from "../../assets/darkmode logo.png";
import { DarkContext } from "../../Context/DarkContext";
import { useContext } from "react";
import { useEffect } from "react";
import socket from "../../Utils/Socket";

function Header({ pageName, updater }) {
  const [openSidebar, setOpenSidebar] = useState(false);
  const [notiNum, setNotinum] = useState(0);
  console.log(notiNum);
  const name = JSON.parse(localStorage.getItem("user"));
  const profileImg = name?.user?.profileImg;
  const { themeMode, setThemeMode } = useContext(DarkContext);
  const darkMode = JSON.parse(localStorage.getItem("isdarkmode"));
  const handleToggleDark = () => {
    setThemeMode(!themeMode);
    localStorage.setItem("isdarkmode", themeMode);
  };

  const navigate = useNavigate();

  useEffect(() => {
    socket.on("connection", () => {
      socket.emit("userConnected", name.user._id);
      socket.on("notificationEvent", (data) => {
        setNotinum(data);
        console.log(data, "connection");
      });
    });
    // eslint-disable-next-line
  }, [updater]);

  return (
    <>
      <Container
        fluid
        className={styles.mobileHeader}
        style={
          darkMode
            ? { backgroundColor: DarkColors.bgsecondarycolordark }
            : { backgroundColor: LightColors.bgsecondarycolorlight }
        }
      >
        <Row className="py-3">
          <Col xs="8" style={{ paddingLeft: "1.5rem" }}>
            <img
              src={darkMode ? darkmodelogo : logo}
              alt="profile"
              width="150px"
              onClick={() => navigate("/home")}
            />
          </Col>
          <Col
            xs="2"
            className="text-end pe-4 d-flex justify-content-center align-items-center"
          >
            <div className="d-flex flex-row justify-content-end align-items-center text-end gap-3">
              <div
                style={{ position: "relative" }}
                className={styles.notificationWrapper2}
              >
                <div style={{ position: "relative" }}>
                  <FontAwesomeIcon
                    onClick={() => navigate("/notification")}
                    icon={faBell}
                    className={`${styles.mobileHeaderBellIcon} fa-2x`}
                    style={
                      darkMode
                        ? {
                            color: DarkColors.btntextcolordark,
                            cursor: "pointer",
                            gap: "1rem",
                          }
                        : {
                            color: LightColors.fonttextcolorlight,
                            cursor: "pointer",
                            gap: "1rem",
                          }
                    }
                  />
                  <div
                    className={styles.notif_Counter2}
                    onClick={() => navigate("/notification")}
                    style={{ cursor: "pointer" }}
                  ></div>
                </div>
              </div>
              <div className={styles.DarkMode} style={{}}>
                <Form>
                  <Form.Switch
                    type="switch"
                    id="custom-switch"
                    onClick={handleToggleDark}
                    defaultChecked={darkMode}
                  />
                </Form>
              </div>
            </div>
          </Col>

          <Col
            xs="2"
            className="text-end ps-3 d-flex justify-content-center align-items-center"
          >
            <FontAwesomeIcon
              className="fa-2x"
              icon={faBars}
              // style={{  cursor: "pointer" }}
              style={
                darkMode
                  ? {
                      color: DarkColors.btntextcolordark,
                      cursor: "pointer",
                      fontSize: "1.8rem",
                    }
                  : {
                      color: LightColors.fonttextcolorlight,
                      cursor: "pointer",
                      fontSize: "1.8rem",
                    }
              }
              onClick={() => {
                setOpenSidebar(!openSidebar);
              }}
            />
          </Col>
        </Row>
        <div>{openSidebar && <Sidebar />}</div>
      </Container>

      <Container
        fluid
        className={styles.pc}
        style={
          darkMode
            ? { backgroundColor: DarkColors.bgsecondarycolordark }
            : { backgroundColor: LightColors.bgsecondarycolorlight }
        }
      >
        <Row className={styles.wrapper}>
          <Col className="d-flex align-items-center" xs={12} sm={8} md={3}>
            <img
              src={darkMode ? darkmodelogo : logo}
              className={styles.logo}
              alt="logo"
              onClick={() => navigate("/")}
            />
          </Col>

          <Col xs={12} sm={8} md={6} lg={4}>
            <p
              style={
                darkMode
                  ? {
                      fontSize: "2vmax",
                      margin: "0",
                      fontWeight: "bold",
                      display: "flex",
                      justifyContent: "start",
                      color: DarkColors.btntextcolordark,
                    }
                  : {
                      fontSize: "2vmax",
                      margin: "0",
                      fontWeight: "bold",
                      display: "flex",
                      justifyContent: "start",
                      color: DarkColors.btntextcolorlight,
                    }
              }
            >
              {pageName}
            </p>
          </Col>

          <Col
            xs={12}
            sm={4}
            md={3}
            lg={5}
            className="d-flex justify-content-end"
          >
            <div
              className="w-100 d-flex flex-row justify-content-end gap-5 align-items-center text-end"
              // style={{ paddingLeft: "5rem" }}
            >
              <div
                className={styles.checkComment}
                onClick={() => navigate("/courses")}
              >
                <FontAwesomeIcon
                  icon={faBookOpen}
                  className="fa-2x"
                  style={
                    darkMode
                      ? {
                          color: DarkColors.btntextcolordark,
                          cursor: "pointer",
                        }
                      : {
                          color: LightColors.fonttextcolorlight,
                          cursor: "pointer",
                        }
                  }
                />
              </div>
              <div
                style={{ position: "relative" }}
                className={styles.notificationWrapper}
              >
                <div style={{ position: "relative" }}>
                  <FontAwesomeIcon
                    style={
                      darkMode
                        ? {
                            color: DarkColors.btntextcolordark,
                            cursor: "pointer",
                          }
                        : {
                            color: LightColors.fonttextcolorlight,
                            cursor: "pointer",
                          }
                    }
                    icon={faBell}
                    className="fa-2x"
                    onClick={() => navigate("/notification")}
                  />
                  {/* {notiNum > 0 && ( */}
                  <div
                    className={styles.notif_Counter}
                    onClick={() => navigate("/notification")}
                    style={{ cursor: "pointer" }}
                  ></div>
                  {/* // )} */}
                </div>
              </div>
              <div className={styles.DarkMode}>
                <Form>
                  <Form.Switch
                    type="switch"
                    id="custom-switch"
                    onClick={handleToggleDark}
                    defaultChecked={darkMode}
                  />
                </Form>
              </div>
              <div className="d-flex">
                <div className="d-flex justify-content-center align-items-center gap-3">
                  <img
                    alt="profile"
                    src={profileImg}
                    className={styles.profile_img}
                    style={{ cursor: "pointer" }}
                    onClick={() => navigate("/profile")}
                  />
                  <div className={styles.headerNames}>
                    <h5
                      className={`${styles.headerUserName} m-0`}
                      style={
                        darkMode
                          ? { color: DarkColors.btntextcolordark }
                          : { color: LightColors.fonttextcolorlight }
                      }
                    >
                      {name?.user?.username}
                    </h5>
                    <p
                      style={
                        darkMode
                          ? { color: DarkColors.fonttextcolordark }
                          : { color: LightColors.fonttextcolorlight }
                      }
                      className={`${styles.headeruserRole} d-flex flex-column justify-content-center align-items-baseline m-0`}
                    >
                      {name?.user?.role?.[0] === "Student"
                        ? "Learner"
                        : name?.user?.role?.[0] === "Instructor"
                        ? "Coach"
                        : "Admin"}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </>
  );
}

export default Header;
