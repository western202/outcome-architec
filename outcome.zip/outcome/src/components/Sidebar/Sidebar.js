import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

import {
  faHome,
  faDiceFour,
  faBookOpen,
  faUserFriends,
  faCalendar,
  faUser,
  faBell,
  faRightFromBracket,
} from "@fortawesome/free-solid-svg-icons";
import { Container } from "react-bootstrap";
import styles from "./Sidebar.module.css";
import { Link, useNavigate } from "react-router-dom";
import { DarkColors, LightColors } from "../../Utils/Colors";
import { DarkContext } from "../../Context/DarkContext";
import { useContext } from "react";
import { NotificationAlert } from "../NotificationAlert/NotificationAlert";

function Sidebar() {
  const adminRoutes = [
    {
      path: "/",
      name: "News Feed",
      icon: faHome,
    },
    {
      path: "/dashboard",
      name: "Dashboard",
      icon: faDiceFour,
    },
    {
      path: "/Courses",
      name: "Courses",
      icon: faBookOpen,
    },
    {
      path: "/schedule",
      name: "Schedule",
      icon: faCalendar,
    },
    {
      path: "/students",
      name: "Students",
      icon: faUser,
    },
    {
      path: "/instructor",
      name: "Instructors",
      icon: faUserFriends,
    },
    {
      path: "/profile",
      name: "Profile",
      icon: faUser,
    },
    {
      path: "/notification",
      name: "Notification",
      icon: faBell,
    },
  ];

  const studentRoutes = [
    {
      path: "/",
      name: "News Feed",
      icon: faHome,
    },
    {
      path: "/dashboard",
      name: "Dashboard",
      icon: faDiceFour,
    },
    {
      path: "/Courses",
      name: "Courses",
      icon: faBookOpen,
    },
    {
      path: "/schedule",
      name: "Schedule",
      icon: faCalendar,
    },

    {
      path: "/profile",
      name: "Profile",
      icon: faUser,
    },
    {
      path: "/notification",
      name: "Notification",
      icon: faBell,
    },
  ];

  const instructrRoutes = [
    {
      path: "/",
      name: "News Feed",
      icon: faHome,
    },
    {
      path: "/dashboard",
      name: "Dashboard",
      icon: faDiceFour,
    },
    {
      path: "/Courses",
      name: "Courses",
      icon: faDiceFour,
    },

    {
      path: "/schedule",
      name: "Schedule",
      icon: faCalendar,
    },
    {
      path: "/students",
      name: "Students",
      icon: faUser,
    },

    {
      path: "/profile",
      name: "Profile",
      icon: faUser,
    },
    {
      path: "/notification",
      name: "Notification",
      icon: faBell,
    },
  ];

  const navigate = useNavigate();
  // eslint-disable-next-line
  const { themeMode, setThemeMode } = useContext(DarkContext);
  let sideBarRoutes = [];

  const userData = JSON.parse(localStorage.getItem("user"));

  if (userData.user.role?.[0] === "Admin") {
    sideBarRoutes = adminRoutes;
  } else if (userData.user.role?.[0] === "Student") {
    sideBarRoutes = studentRoutes;
  } else if (userData.user.role?.[0] === "Instructor") {
    sideBarRoutes = instructrRoutes;
  }

  const logout = () => {
    try {
      localStorage.removeItem("user");
      navigate("/");
    } catch (error) {
      NotificationAlert("Error While Logging Out");
    }
  };

  return (
    <>
      <Container
        className={styles.HomeLeftWrapper}
        style={
          themeMode
            ? { background: DarkColors.bgsecondarycolordark }
            : { background: LightColors.bgsecondarycolorlight }
        }
      >
        {sideBarRoutes.map((item, index) => (
          <React.Fragment key={index}>
            <Link className={`${styles.sideLinks}`} to={item.path}>
              <div
                className={`${styles.links} d-flex align-items-center gap-3 `}
              >
                <FontAwesomeIcon icon={item.icon} />
                <h5
                  className="m-0"
                  style={
                    themeMode
                      ? { color: DarkColors.fonttextcolordark }
                      : { color: LightColors.fonttextcolorlight }
                  }
                >
                  {item.name}
                </h5>
              </div>
            </Link>
          </React.Fragment>
        ))}
        <Link className={styles.logout} onClick={() => navigate("/")}>
          <div className={`${styles.links} d-flex align-items-center gap-3 `}>
            <FontAwesomeIcon icon={faRightFromBracket} />
            <h5 className="m-0" onClick={logout}>
              Log-out
            </h5>
          </div>
        </Link>
      </Container>
    </>
  );
}

export default Sidebar;
