import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { useUpdateCourseMutation } from "../../../Redux/GlobalSlices/Global";
import { useState } from "react";
import gallery from "../../../assets/gallery.svg";
import style from "./manageCourse.module.css";
import { DarkContext } from "../../../Context/DarkContext";
import { useContext } from "react";
import { useEffect } from "react";
import { DarkColors, LightColors } from "../../../Utils/Colors";
import ListLoader from "../../Loader/ListLoader";
import { NotificationAlert } from "../../NotificationAlert/NotificationAlert";

const ManageCourse = ({
  setManageCourse,
  courseID,
  courseDetail,
  singleCourse,
}) => {
  const [courseImages, setCourseImages] = useState("");
  const [courseData, setCourseData] = useState({
    title: courseDetail?.title,
    desc: courseDetail?.desc,
  });

  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  const handleCourseData = (e) => {
    setCourseData({ ...courseData, [e.target.name]: e.target.value });
  };

  const user = JSON.parse(localStorage.getItem("user"));
  const instructorID = user?.user?._id;

  const [updateCourse, { isError, isLoading }] = useUpdateCourseMutation();

  const onChangeCourseImg = (e) => {
    const files = e.target.files[0];
    setCourseImages(files);
  };

  const handleCourseUpdate = async () => {
    try {
      const formData = new FormData();
      formData.append("title", courseData.title);
      formData.append("desc", courseData.desc);
      formData.append("courseThumbnail", courseImages);
      const res = await updateCourse({
        instructorID: instructorID,
        courseID: courseID,
        data: formData,
      });
      if (!res.error) {
        NotificationAlert("Course updated successfully", "success");

        singleCourse.refetch();
        setManageCourse(false);
      } else {
        NotificationAlert("Error While Updating Course");
      }
    } catch (error) {}
  };

  return (
    <div
      className="modal show"
      style={{ display: "block", position: "initial" }}
    >
      <Modal.Dialog>
        <Modal.Header
          style={
            darkmode
              ? { background: DarkColors.bgsecondarycolordark }
              : { background: LightColors.bgsecondarycolorlight }
          }
        >
          <Modal.Title
            style={
              darkmode
                ? { color: DarkColors.headingcolor }
                : { color: LightColors.headingcolor }
            }
          >
            Manage Course
          </Modal.Title>
        </Modal.Header>

        <Modal.Body
          style={
            darkmode
              ? { background: DarkColors.bgsecondarycolordark }
              : { background: LightColors.bgsecondarycolorlight }
          }
        >
          {/* <p>Modal body text goes here.</p> */}
          <div className="d-flex flex-column gap-2">
            <span className={`${style.inputFields} d-flex flex-column gap-2`}>
              <div className="d-flex flex-column gap-1">
                <p>Title</p>
                <input
                  type="text"
                  name="title"
                  value={courseData.title}
                  onChange={handleCourseData}
                  style={
                    darkmode
                      ? { background: DarkColors.bgsecondarycolordark }
                      : { background: LightColors.bgsecondarycolorlight }
                  }
                  // placeholder="Title"
                />
              </div>
              <div className="d-flex flex-column gap-1">
                <p>Description</p>
                <input
                  type="text"
                  name="desc"
                  value={courseData.desc}
                  onChange={handleCourseData}
                  // placeholder="Description"
                  style={
                    darkmode
                      ? { background: DarkColors.bgsecondarycolordark }
                      : { background: LightColors.bgsecondarycolorlight }
                  }
                />
              </div>
            </span>
            <label htmlFor="manageCourse" style={{ width: "fit-content" }}>
              <div
                className={`
                
                 d-flex justify-content-center align-items-center`}
                style={{ cursor: "pointer" }}
              >
                <img
                  alt="manage course"
                  src={gallery}
                  style={{ width: "35px" }}
                />
                <h6
                  className={` ps-3 pt-1`}
                  style={
                    darkmode
                      ? { color: DarkColors.headingcolor }
                      : { color: LightColors.headingcolor }
                  }
                >
                  Photos
                </h6>
              </div>
              <input
                type="file"
                name="courseThumbnail"
                onChange={onChangeCourseImg}
                style={{ display: "none" }}
                id="manageCourse"
                accept="image/png, image/gif, image/jpeg"
              />
            </label>
          </div>
        </Modal.Body>

        <Modal.Footer
          style={
            darkmode
              ? { background: DarkColors.bgsecondarycolordark }
              : { background: LightColors.bgsecondarycolorlight }
          }
        >
          <Button variant="secondary" onClick={() => setManageCourse(false)}>
            Close
          </Button>
          {isLoading ? (
            <ListLoader />
          ) : isError ? (
            <Button variant="danger">Error</Button>
          ) : (
            <Button variant="primary" onClick={handleCourseUpdate}>
              Save changes
            </Button>
          )}
        </Modal.Footer>
      </Modal.Dialog>
    </div>
  );
};

export default ManageCourse;
