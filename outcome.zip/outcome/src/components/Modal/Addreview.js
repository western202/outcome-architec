import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { useAddRatingMutation } from "../../Redux/GlobalSlices/Global";
import { useContext, useState } from "react";
import { Rating } from "react-simple-star-rating";
import { DarkContext } from "../../Context/DarkContext";
import { DarkColors, LightColors } from "../../Utils/Colors";
import { NotificationAlert } from "../NotificationAlert/NotificationAlert";

function Addreview({ setOpenReviewModal, revirewData }) {
  const [rating, setRating] = useState(0);
  const { themeMode } = useContext(DarkContext);
  const handleRatingChange = (value) => {
    setRating(value);
  };

  const [addReview] = useAddRatingMutation();
  const handleGiveReview = async () => {
    try {
      const res = await addReview({
        studentID: revirewData?.studentID,
        courseID: revirewData?.courseID,
        reviewID: revirewData?._id,
        data: rating,
      });
      if (!res.error) {
        NotificationAlert("Rating Added Successfully", "success");
        setOpenReviewModal(false);
      } else {
        NotificationAlert("Error While Adding Rating");
      }
    } catch (error) {
      NotificationAlert("Error While Giving Rating");
    }
  };

  return (
    <>
      <div
        className="modal show"
        style={{ display: "block", position: "fixed", background: "#80808070" }}
      >
        <Modal.Dialog
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: "100%",
          }}
        >
          <Modal.Header
            // closeButton

            style={
              themeMode
                ? { background: DarkColors.bgsecondarycolordark }
                : { background: LightColors.bgsecondarycolorlight }
            }
          >
            <Modal.Title
              style={
                themeMode
                  ? { color: DarkColors.fonttextcolordark }
                  : { color: LightColors.fonttextcolorlight }
              }
            >
              Give Rating
            </Modal.Title>
          </Modal.Header>

          <Modal.Body
            className="d-flex justify-content-center"
            style={
              themeMode
                ? { background: DarkColors.bgsecondarycolordark }
                : { background: LightColors.bgsecondarycolorlight }
            }
          >
            <Rating onClick={handleRatingChange} size={35} />
          </Modal.Body>

          <Modal.Footer
            style={
              themeMode
                ? { background: DarkColors.bgsecondarycolordark }
                : { background: LightColors.bgsecondarycolorlight }
            }
          >
            {rating !== 0 && (
              <Button variant="primary" onClick={handleGiveReview}>
                Give Review
              </Button>
            )}
            <Button
              variant="danger"
              onClick={() => {
                setOpenReviewModal(false);
              }}
            >
              Close
            </Button>
          </Modal.Footer>
        </Modal.Dialog>
      </div>
    </>
  );
}

export default Addreview;
