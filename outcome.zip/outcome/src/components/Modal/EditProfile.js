import { Container } from "react-bootstrap";
import style from "./editprofile.module.css";
import { useContext, useEffect, useState } from "react";
import { DarkContext } from "../../Context/DarkContext";
import { DarkColors, LightColors } from "../../Utils/Colors";
import { useUpdateProfileMutation } from "../../Redux/Profile/Profile";
import gallery from "../../assets/gallery.svg";
import { NotificationAlert } from "../NotificationAlert/NotificationAlert";

const EditProfile = ({ setEditProfile }) => {
  const [ProfileImages, setProfileImages] = useState("");
  const data = JSON.parse(localStorage.getItem("user"));
  const [isUpdateprofile, setIsupdateProfile] = useState({
    firstName: data?.user?.username.split(" ")[0],
    lastName: data?.user?.username.split(" ")[1],
    city: data?.user?.city,
    state: data?.user?.state,
    bio: data?.user?.bio,
  });
  const { firstName, lastName, city, state, bio } = isUpdateprofile;

  const handleOnChange = (e) => {
    setIsupdateProfile({ ...isUpdateprofile, [e.target.name]: e.target.value });
  };

  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  const userID = data?.user?._id;
  const [updateProfile, { isLoading }] = useUpdateProfileMutation();

  const onChangeProfileImg = (e) => {
    const files = e.target.files[0];
    setProfileImages(files);
  };

  const handleUpdateProfile = async () => {
    try {
      const formData = new FormData();
      formData.append("username", firstName + " " + lastName);
      formData.append("city", city);
      formData.append("state", state);
      formData.append("profileImg", ProfileImages);
      formData.append("bio", bio);
      const res = await updateProfile({
        userID: userID,
        data: formData,
      });

      if (!res.error) {
        NotificationAlert("User profile updated successfully", "success");

        localStorage.setItem("user", JSON.stringify(res.data));
      } else {
        NotificationAlert("Error While Updating Profile");
      }
      setTimeout(() => {
        window.location.reload(false);
      }, 2000);
    } catch (error) {
      NotificationAlert("Error While Updating Profile");
    }
  };

  return (
    <>
      <div
        style={{
          width: "100%",
        }}
      >
        <Container
          fluid
          className={`${style.editProfile} d-flex gap-3 flex-column`}
        >
          <button
            onClick={() => setEditProfile(false)}
            style={{
              width: "fit-content",
            }}
            className={style.editProfileBackBTN}
          >
            Go Back
          </button>
          <div className={`${style.editProfileWrapper} d-flex`}>
            <div
              style={
                darkmode
                  ? {
                      // borderRight: "1px solid black",
                      display: "flex",
                      justifyContent: "center",
                    }
                  : {
                      // borderRight: "1px solid",
                      display: "flex",
                      justifyContent: "center",
                    }
              }
            >
              <div className="d-flex flex-column justify-content-center align-items-center gap-3">
                <img
                  src={data?.user?.profileImg}
                  alt={data?.user?.profileImg}
                  style={{
                    width: "10rem",
                    height: "10rem",
                    borderRadius: "50%",
                  }}
                  className={style.editProfileImg}
                />
                <h3
                  style={
                    darkmode
                      ? {
                          fontWeight: "700",
                          color: DarkColors.headingcolor,
                        }
                      : { color: LightColors.headingcolor, fontWeight: "700" }
                  }
                  className={style.editProfileName}
                >
                  {data?.user?.username}
                </h3>
              </div>
            </div>
            <div className={style.line}></div>
            <div className="d-flex flex-column gap-3">
              <h2
                style={
                  darkmode
                    ? {
                        color: DarkColors.headingcolor,
                      }
                    : { color: LightColors.headingcolor }
                }
                className={style.editProfileSettingHeading}
              >
                Profile Setting
              </h2>
              <div className={`${style.inputFields} d-flex flex-column gap-3`}>
                <span className="d-flex gap-2">
                  <span>
                    <p
                      className="m-0"
                      style={
                        darkmode
                          ? {
                              color: DarkColors.fonttextcolordark,
                              fontWeight: "600",
                            }
                          : {
                              color: LightColors.headingcolor,
                              fontWeight: "600",
                            }
                      }
                    >
                      Firstname
                    </p>
                    <input
                      type="text"
                      placeholder="Firstname"
                      name="firstName"
                      value={firstName}
                      onChange={handleOnChange}
                      style={
                        darkmode
                          ? {
                              background: "transparent",
                            }
                          : {}
                      }
                      required
                    />
                  </span>
                  <span>
                    <p
                      className="m-0"
                      style={
                        darkmode
                          ? {
                              color: DarkColors.fonttextcolordark,
                              fontWeight: "600",
                            }
                          : {
                              color: LightColors.headingcolor,
                              fontWeight: "600",
                            }
                      }
                    >
                      Lastname
                    </p>
                    <input
                      type="text"
                      placeholder="Lastname"
                      value={lastName}
                      name="lastName"
                      onChange={handleOnChange}
                      style={
                        darkmode
                          ? {
                              background: "transparent",
                            }
                          : {}
                      }
                    />
                  </span>
                </span>
                <span className="d-flex gap-2">
                  <span>
                    <p
                      className="m-0"
                      style={
                        darkmode
                          ? {
                              color: DarkColors.fonttextcolordark,
                              fontWeight: "600",
                            }
                          : {
                              color: LightColors.headingcolor,
                              fontWeight: "600",
                            }
                      }
                    >
                      City
                    </p>
                    <input
                      type="text"
                      placeholder="Country"
                      value={city}
                      name="city"
                      onChange={handleOnChange}
                      style={
                        darkmode
                          ? {
                              background: "transparent",
                            }
                          : {}
                      }
                    />
                  </span>
                  <span>
                    <p
                      className="m-0"
                      style={
                        darkmode
                          ? {
                              color: DarkColors.fonttextcolordark,
                              fontWeight: "600",
                            }
                          : {
                              color: LightColors.headingcolor,
                              fontWeight: "600",
                            }
                      }
                    >
                      State/Region
                    </p>
                    <input
                      type="text"
                      placeholder="State"
                      value={state}
                      name="state"
                      onChange={handleOnChange}
                      style={
                        darkmode
                          ? {
                              background: "transparent",
                            }
                          : {}
                      }
                    />
                  </span>
                </span>
                <span>
                  <label
                    htmlFor="imageUpload"
                    style={{ color: "var(--btn-color)" }}
                  >
                    <div
                      className={`${style.addfield} d-flex justify-content-center align-items-center`}
                      style={{ cursor: "pointer", gap: "0.5rem" }}
                    >
                      <img
                        alt="home page"
                        src={gallery}
                        style={{ width: "35px" }}
                        className={style.addfieldicon}
                        accept="image/*"
                      />
                      <p
                        className="m-0"
                        style={
                          darkmode
                            ? {
                                color: DarkColors.fonttextcolordark,
                                fontWeight: "600",
                                margin: "0",
                              }
                            : {
                                color: LightColors.headingcolor,
                                fontWeight: "600",
                                margin: "0",
                              }
                        }
                      >
                        ProfilePic
                      </p>
                    </div>
                  </label>
                  <input
                    type="file"
                    id="imageUpload"
                    name="profilePic"
                    accept="image/png, image/gif, image/jpeg"
                    onChange={onChangeProfileImg}
                    style={{
                      border: "none",
                      padding: "0rem",
                      color: "#A098AE",
                      display: "none",
                    }}
                  />
                </span>

                <span>
                  <p
                    className="m-0"
                    style={
                      darkmode
                        ? {
                            color: DarkColors.fonttextcolordark,
                            fontWeight: "600",
                          }
                        : {
                            color: LightColors.headingcolor,
                            fontWeight: "600",
                          }
                    }
                  >
                    Bio
                  </p>
                  <textarea
                    type="text"
                    placeholder="Enter your Bio here..."
                    value={bio}
                    name="bio"
                    onChange={handleOnChange}
                    // rows={50}
                    // cols={50}
                    style={
                      darkmode
                        ? {
                            background: "transparent",
                            width: "100%",
                            paddingLeft: "0.5rem",
                          }
                        : {
                            width: "100%",
                            paddingLeft: "0.5rem",
                          }
                    }
                  />
                </span>
                <button
                  onClick={handleUpdateProfile}
                  className={style.updateProfileBTN}
                >
                  {isLoading ? "Updating..." : "Update Profile"}
                </button>
              </div>
            </div>
          </div>
        </Container>
      </div>
    </>
  );
};

export default EditProfile;
