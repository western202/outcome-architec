import React, { useState } from "react";
// import style from "./addcourse.module.css";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { useCreateCourseMutation } from "../../Redux/GlobalSlices/Global";
import gallery from "../../assets/gallery.svg";
import video from "../../assets/pdf.png";
import ListLoader from "../Loader/ListLoader";
import { DarkColors, LightColors } from "../../Utils/Colors";
import { NotificationAlert } from "../NotificationAlert/NotificationAlert";

function AddCourse({ setIsOpen, updater, setUpdater }) {
  const userData = JSON.parse(localStorage.getItem("user"));
  const [createCourse, { isLoading }] = useCreateCourseMutation();
  const themeMode = JSON.parse(localStorage.getItem("isdarkmode"));
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  // eslint-disable-next-line
  const [files, setFiles] = useState([]);
  // eslint-disable-next-line
  const [courseThumbnail, setCourseThumbnail] = useState("");

  const onChangeFiles = (e) => {
    const files = e.target.files;
    const fileArray = Array.from(files); // Convert FileList to an array

    if (fileArray.length <= 1) {
      setFiles(fileArray);
    }
  };

  const onChangeThumbnail = (e) => {
    setCourseThumbnail(e.target.files[0]);
  };

  const onSubmit = async () => {
    try {
      const formData = new FormData();

      formData.append("title", title);
      formData.append("desc", desc);
      formData.append("courseThumbnail", courseThumbnail);

      files.forEach((file) => {
        formData.append("files", file, file.name); // Use a different variable name 'file' for individual files
      });

      const res = await createCourse({
        id: userData.user._id,
        formData, // Pass the formData object instead of individual fields
      });
      if (!res.error) {
        NotificationAlert("Course Upload successfully", "success");

        setIsOpen(false);
        setUpdater(!updater);
      }
    } catch (error) {
      NotificationAlert("Error While Uploading Course");
    }
  };

  const emptyFields = () => {
    NotificationAlert("All fields are required");
  };

  return (
    <div
      className="modal show"
      style={{ display: "block", position: "fixed", background: "#80808070" }}
    >
      <Modal.Dialog
        style={
          themeMode
            ? {
                background: DarkColors.bgsecondarycolordark,
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                width: "78vmin",
                borderRadius: "10px",
              }
            : {
                background: LightColors.bgsecondarycolorlight,
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                width: "78vmin",
                borderRadius: "10px",
              }
        }
      >
        <Modal.Header
          style={
            themeMode
              ? { background: DarkColors.bgsecondarycolordark }
              : { background: LightColors.bgsecondarycolorlight }
          }
        >
          <Modal.Title
            style={
              themeMode
                ? { color: DarkColors.headingcolor }
                : { color: LightColors.headingcolor }
            }
          >
            Add Course
          </Modal.Title>
        </Modal.Header>

        <Modal.Body
          className="d-flex flex-column gap-3"
          style={
            themeMode
              ? { background: DarkColors.bgsecondarycolordark }
              : { background: LightColors.bgsecondarycolorlight }
          }
        >
          <input
            type="text"
            placeholder="Title..."
            value={title}
            name="title"
            onChange={(e) => setTitle(e.target.value)}
            style={
              themeMode
                ? {
                    background: DarkColors.fonttextcolordark,
                    // border: "none",
                    width: "100%",
                    outline: "none",
                    borderRadius: "10px",
                    border: "1px solid grey",
                    padding: "0.5rem 1rem",
                  }
                : {
                    backgroundColor: "transparent",
                    width: "100%",
                    outline: "none",
                    borderRadius: "10px",
                    border: "1px solid grey",
                    padding: "0.5rem 1rem",
                  }
            }
          />
          <input
            type="text"
            placeholder="Description..."
            value={desc}
            name="desc"
            onChange={(e) => setDesc(e.target.value)}
            // style={{
            //   width: "100%",
            //   outline: "none",
            //   borderRadius: "10px",
            //   border: "1px solid grey",
            //   padding: "0.5rem 1rem",
            // }}
            style={
              themeMode
                ? {
                    background: DarkColors.fonttextcolordark,
                    // border: "none",
                    width: "100%",
                    outline: "none",
                    borderRadius: "10px",
                    border: "1px solid grey",
                    padding: "0.5rem 1rem",
                  }
                : {
                    backgroundColor: "transparent",
                    width: "100%",
                    outline: "none",
                    borderRadius: "10px",
                    border: "1px solid grey",
                    padding: "0.5rem 1rem",
                  }
            }
          />
          <div className="d-flex justify-content-around">
            <label
              className=" mt-2 d-flex gap-2"
              // style={{
              //   fontWeight: "bold",
              //   cursor: "pointer",
              //   width: "fit-content",
              // }}
              style={
                themeMode
                  ? {
                      color: DarkColors.fonttextcolordark,
                      fontWeight: "bold",
                      cursor: "pointer",
                      width: "fit-content",
                    }
                  : {
                      color: LightColors.fonttextcolorlight,
                      fontWeight: "bold",
                      cursor: "pointer",
                      width: "fit-content",
                    }
              }
            >
              <img alt="home page" src={gallery} style={{ width: "35px" }} />
              <input
                type="file"
                name="courseThumbnail"
                onChange={onChangeThumbnail}
                placeholder="thumbnail"
                style={{ display: "none" }}
                accept="image/*"
              />
              Thumbnail
            </label>
            <label
              className=" mt-2 d-flex gap-2"
              style={
                themeMode
                  ? {
                      color: DarkColors.fonttextcolordark,
                      fontWeight: "bold",
                      cursor: "pointer",
                      width: "fit-content",
                    }
                  : {
                      color: LightColors.fonttextcolorlight,
                      fontWeight: "bold",
                      cursor: "pointer",
                      width: "fit-content",
                    }
              }
            >
              <img alt="home page" src={video} style={{ width: "35px" }} />
              <input
                type="file"
                id="files"
                name="files"
                multiple="multiple" // Enable multiple file selection
                onChange={onChangeFiles}
                style={{ display: "none" }}
                accept=".pdf"
              />
              Files
            </label>
          </div>
        </Modal.Body>

        <Modal.Footer
          style={
            themeMode
              ? { background: DarkColors.bgsecondarycolordark }
              : { background: LightColors.bgsecondarycolorlight }
          }
        >
          {title !== "" && desc !== "" && courseThumbnail !== "" ? (
            isLoading ? (
              <ListLoader />
            ) : (
              <Button
                style={{ background: "#6AA22C", borderColor: "#6AA22C" }}
                onClick={onSubmit}
              >
                Upload Course
              </Button>
            )
          ) : (
            <Button
              style={{ background: "#6AA22C", borderColor: "#6AA22C" }}
              onClick={emptyFields}
            >
              Upload Course
            </Button>
          )}
          <Button variant="danger" onClick={() => setIsOpen(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal.Dialog>
    </div>
  );
}

export default AddCourse;
