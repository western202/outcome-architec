import Swal from "sweetalert2";
import { useDeleteCommentMutation } from "../../../Redux/Post/Post";
import { NotificationAlert } from "../../NotificationAlert/NotificationAlert";

const DeleteComments = ({ postId, setIsDeleteComment, commentID }) => {
  const userData = JSON.parse(localStorage.getItem("user"));
  const [deleteComment] = useDeleteCommentMutation();

  const handleDeleteComment = async () => {
    try {
      // eslint-disable-next-line
      const res = await deleteComment({
        postId,
        userId: userData.user._id,
        commentId: commentID,
      });
      if (!res.error) {
        NotificationAlert("Comment deleted successfully", "success");
      } else {
        NotificationAlert("Error While Deleting Comment");
      }
    } catch (error) {
      NotificationAlert("Error While Deleting Comment");
    }
  };

  Swal.fire({
    title: "Are you sure?",
    text: "You won't be able to revert this!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    // confirmButtonText: "Yes, delete it!",
  }).then((result) => {
    if (result.isConfirmed) {
      handleDeleteComment().then(() => {
        setIsDeleteComment(false);
      });

      // If the user confirms deletion
    } else if (result.isDismissed) {
      // If the user cancels the deletion
      setIsDeleteComment(false);
    }
  });
};

export default DeleteComments;
