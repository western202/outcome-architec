import { Col, Container, Row } from "react-bootstrap";
import style from "./addeventmodal.module.css";
import { useContext, useEffect, useState } from "react";
import { DarkContext } from "../../Context/DarkContext";
import { DarkColors, LightColors } from "../../Utils/Colors";
import { useCreateEventMutation } from "../../Redux/ScheduleEventSlice/ScheduleEvent";
import { NotificationAlert } from "../NotificationAlert/NotificationAlert";
import ListLoader from "../Loader/ListLoader";

const AddEventModal = ({ setShowModal }) => {
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  const [createEvent, { isLoading }] = useCreateEventMutation();

  //   get instructor Id
  const data = JSON.parse(localStorage.getItem("user"));
  const userID = data?.user?._id;
  const [eventField, setEventField] = useState({
    instructorID: userID,
    title: "",
    date: "",
    startTime: "",
    endTime: "",
  });

  const handleOnChange = (e) => {
    setEventField({ ...eventField, [e.target.name]: e.target.value });
  };

  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  const handleSheduleEvent = async (e) => {
    e.preventDefault();
    if (
      eventField.instructorID &&
      eventField.title &&
      eventField.date &&
      eventField.startTime &&
      eventField.endTime
    ) {
      try {
        const res = await createEvent({
          data: eventField,
          instructorId: userID,
        });
        if (res?.data) {
          NotificationAlert("Create Event Successfully", "success");
          setShowModal(false);
        }
      } catch (error) {
        NotificationAlert("Unable to Create Evenet Try Again!", "warning");
        setShowModal(false);
      }
    } else {
      NotificationAlert("All Field Required!", "warning");
    }
  };

  return (
    <>
      <div
        style={{
          width: "100%",
        }}
      >
        <Container fluid className="d-flex gap-3 flex-column">
          <button
            onClick={() => setShowModal(false)}
            style={{
              width: "fit-content",
            }}
          >
            Go Back
          </button>
          <Row className="d-flex">
            <Col className="d-flex flex-column">
              <h2
                style={
                  darkmode
                    ? {
                        color: DarkColors.headingcolor,
                      }
                    : { color: LightColors.headingcolor }
                }
                className="text-center fw-bold mb-3"
              >
                Shedule Event
              </h2>
              <div className={`${style.inputFields} d-flex flex-column gap-3`}>
                <form className="mx-3">
                  <div className="mb-3">
                    <label
                      style={
                        darkmode
                          ? {
                              color: DarkColors.fonttextcolordark,
                            }
                          : { color: LightColors.fonttextcolorlight }
                      }
                      htmlFor="exampleInputEmail1"
                      className="form-label"
                    >
                      Event Title
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="exampleInputEmail1"
                      name="title"
                      value={eventField.title}
                      onChange={handleOnChange}
                    />
                  </div>
                  <div className="mb-3">
                    <label
                      style={
                        darkmode
                          ? {
                              color: DarkColors.fonttextcolordark,
                            }
                          : { color: LightColors.fonttextcolorlight }
                      }
                      htmlFor="exampleInputEmail1"
                      className="form-label"
                    >
                      Event Date
                    </label>
                    <input
                      type="date"
                      className="form-control"
                      id="exampleInputEmail1"
                      name="date"
                      value={eventField.date}
                      onChange={handleOnChange}
                    />
                  </div>
                  <div className="mb-3">
                    <label
                      style={
                        darkmode
                          ? {
                              color: DarkColors.fonttextcolordark,
                            }
                          : { color: LightColors.fonttextcolorlight }
                      }
                      htmlFor="exampleInputEmail1"
                      className="form-label"
                    >
                      Event Start
                    </label>
                    <input
                      type="time"
                      className="form-control"
                      id="exampleInputEmail1"
                      name="startTime"
                      value={eventField.startTime}
                      onChange={handleOnChange}
                    />
                  </div>
                  <div className="mb-3">
                    <label
                      style={
                        darkmode
                          ? {
                              color: DarkColors.fonttextcolordark,
                            }
                          : { color: LightColors.fonttextcolorlight }
                      }
                      htmlFor="exampleInputEmail1"
                      className="form-label"
                    >
                      Event End
                    </label>
                    <input
                      type="time"
                      className="form-control"
                      id="exampleInputEmail1"
                      name="endTime"
                      value={eventField.endTime}
                      onChange={handleOnChange}
                    />
                  </div>

                  <div className="text-center">
                    {isLoading ? (
                      <ListLoader />
                    ) : (
                      <button
                        onClick={handleSheduleEvent}
                        className="px-3 modal_btn"
                      >
                        Add Event
                      </button>
                    )}
                  </div>
                </form>
              </div>
            </Col>
          </Row>
        </Container>
      </div>
    </>
  );
};

export default AddEventModal;
