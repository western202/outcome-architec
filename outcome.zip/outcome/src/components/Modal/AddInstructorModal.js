import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { useState, useEffect, useContext } from "react";
import styles from "./addInstructor.module.css";
import { useInviteStudentMutation } from "../../Redux/StudentSlices/Student";
import { useInviteInstructorMutation } from "../../Redux/InstructorSlices/Instructor";
import { DarkContext } from "../../Context/DarkContext";
import { DarkColors, LightColors } from "../../Utils/Colors";
import { NotificationAlert } from "../NotificationAlert/NotificationAlert";

function AddInstructorModal({ title, setIsOpen, setAddStudent, addStudnt }) {
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");

  const userData = JSON.parse(localStorage.getItem("user"));
  const { themeMode } = useContext(DarkContext);

  const id = userData?.user?._id;
  const invitedByEmail = userData?.user?.email;
  const role = userData?.user?.role?.[0];

  const generateRandomPassword = (length) => {
    const charset =
      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let password = "";
    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * charset.length);
      password += charset[randomIndex];
    }
    return password;
  };

  const handleGeneratePassword = () => {
    if (email) {
      const randomPassword = generateRandomPassword(12);

      if (randomPassword) {
        NotificationAlert("Password generated", "success");
      }
      setPassword(randomPassword);
    } else {
      NotificationAlert("Email Are Required");
    }
  };

  useEffect(() => {}, []);

  const [inviteStudent] = useInviteStudentMutation();

  const [inviteInstructor] = useInviteInstructorMutation();

  const submitInviteStudent = async () => {
    try {
      const res = await inviteStudent({
        email,
        password,
        invitedByID: id,
        invitedByEmail: invitedByEmail,
      });
      if (!res.error) {
        NotificationAlert("Invitation sent successfully", "success");

        setIsOpen(false);
      } else {
        NotificationAlert("This Email Already Exists");
      }
    } catch (error) {
      NotificationAlert("This Email Already Exists");
    }
  };

  const submitInviteInstructor = async () => {
    try {
      const res = await inviteInstructor({
        email,
        password,
      });
      if (!res.error) {
        NotificationAlert("Invitation sent successfully", "success");
      } else {
        NotificationAlert("This Email Already Exists");
      }
      setIsOpen(false);
    } catch (error) {
      NotificationAlert("This Email Already Exists");
    }
  };

  return (
    <>
      <div
        className="modal show"
        style={{ display: "block", position: "initial" }}
      >
        <Modal.Dialog>
          <Modal.Header
            style={
              themeMode
                ? { background: DarkColors.bgcolordark }
                : { background: LightColors.bgcolorlight }
            }
          >
            <Modal.Title
              style={
                themeMode
                  ? { color: DarkColors.fonttextcolordark }
                  : { color: LightColors.fonttextcolorlight }
              }
            >
              {title}
            </Modal.Title>
          </Modal.Header>

          <Modal.Body
            style={
              themeMode
                ? { background: DarkColors.bgcolordark, textAlign: "center" }
                : { background: LightColors.bgcolorlight, textAlign: "center" }
            }
          >
            <div className="py-2">
              <input
                type="email"
                onChange={(e) => setEmail(e.target.value)}
                value={email}
                placeholder="Enter Email..."
                // style={{  }}
                style={
                  themeMode
                    ? {
                        background: DarkColors.fonttextcolordark,
                        width: "80%",
                        borderRadius: "10px",
                        padding: "1rem",
                      }
                    : {
                        background: LightColors.fonttextcolorlight,
                        width: "80%",
                        borderRadius: "10px",
                        padding: "1rem",
                      }
                }
              />
            </div>

            <div className="py-2">
              <button
                className={styles.generatePass}
                style={
                  themeMode
                    ? { background: DarkColors.fonttextcolordark }
                    : { background: LightColors.fonttextcolorlight }
                }
                onClick={handleGeneratePassword}
              >
                Generate Password
              </button>
            </div>
            <div className="py-2 d-flex gap-4 justify-content-center align-items-center">
              <Button
                onClick={
                  role === "Admin"
                    ? submitInviteInstructor
                    : submitInviteStudent
                }
                variant="primary"
              >
                Invite
              </Button>

              {addStudnt === true ? (
                <Button onClick={() => setAddStudent(false)} variant="danger">
                  Close
                </Button>
              ) : (
                <Button onClick={() => setIsOpen(false)} variant="danger">
                  Close
                </Button>
              )}
            </div>
          </Modal.Body>
        </Modal.Dialog>
      </div>
    </>
  );
}

export default AddInstructorModal;
