import React, { useEffect } from "react";
import { useState } from "react";
import { Row } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { Swiper, SwiperSlide } from "swiper/react";
import gallery from "../../../assets/gallery.svg";
import video from "../../../assets/video.svg";
import { useUpdatePostMutation } from "../../../Redux/GlobalSlices/Global";
import { DefaultPlayer as Video } from "react-html5video";
import "react-html5video/dist/styles.css";
import { useContext } from "react";
import { DarkContext } from "../../../Context/DarkContext";
import { DarkColors, LightColors } from "../../../Utils/Colors";
import { NotificationAlert } from "../../NotificationAlert/NotificationAlert";

const EditPostModal = ({ setIsEditPost, setIsOpoup, item, getPost }) => {
  const [isEditContent, setIsEditContent] = useState(item.content);
  const [darkmode, setDarkMode] = useState();

  // eslint-disable-next-line
  const [galleryImages, setGalleryImages] = useState([]);
  // eslint-disable-next-line
  const [postVideo, setPostVideo] = useState("");
  const [updatePost, { isLoading }] = useUpdatePostMutation();
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  const postId = item?._id;

  const user = JSON.parse(localStorage.getItem("user"));
  const userID = user?.user?._id;

  const handlePost = async () => {
    try {
      const formData = new FormData();
      formData.append("content", isEditContent);
      formData.append("videoUrls", postVideo);
      for (const img of galleryImages) {
        formData.append("imageUrls", img);
      }
      // eslint-disable-next-line
      const res = await updatePost({
        postId: postId,
        userID: userID,
        data: formData,
      });
      if (!res.error) {
        NotificationAlert("post Updated successfully", "success");

        // getPost.refetch();
        setIsEditPost(false);
        setIsOpoup(false);
      }
    } catch (error) {
      NotificationAlert("Error While Updating post");
    }
  };

  const onChangeGalleryImage = (e) => {
    const files = e.target.files;
    const fileArray = Array.from(files); // Convert FileList to an array

    if (fileArray?.length <= 3) {
      setPostVideo("");
      setGalleryImages(fileArray);
    } else {
      NotificationAlert("You can't select more than 3 images");
    }
  };

  const onChangeVideo = (e) => {
    setGalleryImages([]);
    setPostVideo(e.target.files[0]);
  };

  const breakpoints = {
    320: {
      slidesPerView: 1,
      spaceBetween: 10,
    },
    480: {
      slidesPerView: 1,
      spaceBetween: 20,
    },
    768: {
      slidesPerView: 1,
      spaceBetween: 30,
    },
    1024: {
      slidesPerView: 1,
      spaceBetween: 20,
    },
  };
  return (
    <div
      className="modal show"
      style={{ display: "block", position: "initial" }}
    >
      <Modal.Dialog>
        <Modal.Header
          closeButton
          onClick={() => {
            setIsEditPost(false);
            setIsOpoup(false);
          }}
          style={
            darkmode
              ? {
                  width: "auto",
                  background: DarkColors.bgsecondarycolordark,
                  color: DarkColors.fonttextcolordark,
                }
              : {
                  width: "auto",
                  background: LightColors.bgsecondarycolorlight,
                  color: LightColors.fonttextcolorlight,
                }
          }
        >
          <Modal.Title>Edit Post</Modal.Title>
        </Modal.Header>

        <Modal.Body
          style={
            darkmode
              ? {
                  width: "auto",
                  background: DarkColors.bgsecondarycolordark,
                  color: DarkColors.fonttextcolordark,
                }
              : {
                  width: "auto",
                  background: LightColors.bgsecondarycolorlight,
                  color: LightColors.fonttextcolorlight,
                }
          }
        >
          <h4 className="m-0" style={{ fontWeight: "bolder" }}>
            Edit content
          </h4>
          <div className="w-100 mt-3">
            <input
              type="text"
              style={
                darkmode
                  ? {
                      border: "none",
                      outline: "none",
                      borderRadius: "10px",
                      width: "100%",
                      background: DarkColors.bgsecondarycolordark,
                      color: DarkColors.fonttextcolordark,
                      marginBottom: "1rem",
                    }
                  : {
                      border: "none",
                      outline: "none",
                      borderRadius: "10px",
                      width: "100%",
                      background: LightColors.bgsecondarycolorlight,
                      color: LightColors.fonttextcolordark,
                      marginBottom: "1rem",
                    }
              }
              value={isEditContent}
              onChange={(e) => setIsEditContent(e.target.value)}
            />
          </div>
          {item?.imageUrls.length !== 0 && !item.videoUrls ? (
            <Swiper breakpoints={breakpoints} className="mt-3">
              {item?.imageUrls?.map((img, index) => (
                <React.Fragment key={index + 1}>
                  <Row>
                    <SwiperSlide>
                      <div>
                        <img
                          alt="home page"
                          style={{
                            height: "20rem",
                            width: "100%",
                            objectFit: "cover",
                          }}
                          src={img}
                          className="py-1"
                        />
                      </div>
                    </SwiperSlide>
                  </Row>
                </React.Fragment>
              ))}
            </Swiper>
          ) : item.videoUrls ? (
            <Video
              controls={["PlayPause", "Seek", "Time", "Volume", "Fullscreen"]}
              style={{
                height: "30rem",
              }}
            >
              <source src={item.videoUrls} type="video/mp4" />
              <track
                label="English"
                kind="subtitles"
                srcLang="en"
                src={item.videoUrls}
                default
              />
            </Video>
          ) : (
            ""
          )}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              padding: "0rem 1rem",
            }}
          >
            <label
              className="ps-3 mt-2 d-flex gap-2 align-items-center w-auto"
              style={{
                fontWeight: "bold",
                cursor: "pointer",
              }}
            >
              <img alt="home page" src={gallery} style={{ width: "35px" }} />
              <input
                type="file"
                onChange={onChangeGalleryImage}
                name="imageUrls"
                id="imageUpload"
                multiple="multiple"
                accept="video/png/jpeg*"
                style={{ display: "none" }}
              />
              Edit Image
            </label>
            {galleryImages.length > 0 && (
              <h6 style={{ display: "flex", alignItems: "end" }}>
                ({galleryImages.length} Image Selected)
              </h6>
            )}
            {postVideo && (
              <h6 style={{ display: "flex", alignItems: "end" }}>
                (Video Selected)
              </h6>
            )}
            <label
              className="ps-3 mt-2 d-flex gap-2 align-items-center w-auto"
              style={{
                fontWeight: "bold",
                cursor: "pointer",
              }}
            >
              <img alt="home page" src={video} style={{ width: "35px" }} />
              <input
                type="file"
                onChange={onChangeVideo}
                id="videoUpload"
                accept="video/*"
                style={{ display: "none" }}
              />
              Edit Video
            </label>
          </div>
        </Modal.Body>

        <Modal.Footer
          style={
            darkmode
              ? {
                  background: DarkColors.bgsecondarycolordark,
                  color: DarkColors.fonttextcolordark,
                }
              : {
                  background: LightColors.bgsecondarycolorlight,
                  color: LightColors.fonttextcolorlight,
                }
          }
        >
          {isLoading ? (
            <Button variant="primary">Saving</Button>
          ) : (
            <Button variant="primary" onClick={handlePost}>
              Save changes
            </Button>
          )}
        </Modal.Footer>
      </Modal.Dialog>
    </div>
  );
};

export default EditPostModal;
