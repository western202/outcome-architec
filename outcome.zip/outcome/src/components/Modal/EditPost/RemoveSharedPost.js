// import React from "react";
import Swal from "sweetalert2";
import { useDeleteSharePostMutation } from "../../../Redux/GlobalSlices/Global";
import { NotificationAlert } from "../../NotificationAlert/NotificationAlert";

const RemoveSharedPost = ({ setIsOpoup, postID }) => {
  const [removeSharedPost] = useDeleteSharePostMutation();
  const user = JSON.parse(localStorage.getItem("user"));
  const userId = user?.user?._id;
  const handleRemoveSharedPost = async () => {
    try {
      const res = await removeSharedPost({
        userId: userId,
        postId: postID,
      });
      if (!res.error) {
        NotificationAlert("Shared post deleted successfully", "success");
      } else {
        NotificationAlert("Error While Sharing post");
      }
    } catch (error) {
      NotificationAlert("Error While Sharing post");
    }
  };
  Swal.fire({
    title: "Are you sure?",
    text: "You won't be able to revert this!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes, delete it!",
  }).then((result) => {
    if (result.isConfirmed) {
      // If the user confirms deletion
      handleRemoveSharedPost().then(() => {
        Swal.fire("Deleted!", "Your post has been deleted.", "success");
        setIsOpoup(false);
      });
    } else if (result.isDismissed) {
      // If the user cancels the deletion
      setIsOpoup(false);
    }
  });
};

export default RemoveSharedPost;
