import { faEllipsis } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useState } from "react";
import ThreeDotModal from "./ThreeDotModal";

const EditIcon = ({
  item,
  isSharedPost = true,
  setIsUpdatePost,
  isUpdatePost,
}) => {
  const [isPopUp, setIsOpoup] = useState(false);
  const handlePopupUpadate = () => {
    setIsOpoup(!isPopUp);
    // setIsUpdatePost(!isUpdatePost);
  };
  return (
    <>
      <FontAwesomeIcon
        icon={faEllipsis}
        className="fa-lg w-auto"
        onClick={handlePopupUpadate}
        style={{
          cursor: "pointer",
          color: "rgb(160, 152, 174)",
        }}
      />
      {isPopUp && (
        <>
          <ThreeDotModal
            postID={item?._id}
            item={item}
            setIsOpoup={setIsOpoup}
            isSharedPost={isSharedPost}
          />
        </>
      )}
    </>
  );
};

export default EditIcon;
