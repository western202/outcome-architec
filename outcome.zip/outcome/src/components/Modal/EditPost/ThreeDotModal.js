import React, { useContext, useEffect } from "react";
// import style from "./editprofile.module.css";
import { useState } from "react";
import style from "./editprofile.module.css";
import EditPostModal from "./EditPostModal";
// import DeleteProfile from "./DeleteProfile";
// import RemoveSharedPost from "./RemoveSharedPost";
import DeletePopup from "../../DeletePopup/DeletePopup";
import { useDeletePostMutation } from "../../../Redux/GlobalSlices/Global";
import { useDeleteSharePostMutation } from "../../../Redux/GlobalSlices/Global";
import { DarkContext } from "../../../Context/DarkContext";
import { DarkColors, LightColors } from "../../../Utils/Colors";
import { NotificationAlert } from "../../NotificationAlert/NotificationAlert";

const ThreeDotModal = ({ item, setIsOpoup, postID, isSharedPost }) => {
  const [isEditPost, setIsEditPost] = useState(false);
  const [isDeletePost, setIsDeletePost] = useState(false);
  const [isRemoveShared, setIsRemoveShared] = useState(false);
  const [darkmode, setDarkMode] = useState();
  const user = JSON.parse(localStorage.getItem("user"));
  const userID = user?.user?._id;
  const autherID = item?.authorID[0]._id;
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  //  for delete post

  const [deletePost] = useDeletePostMutation();

  const handlePostDelete = async () => {
    try {
      const res = await deletePost({ postId: postID, userID: userID });
      if (!res.error) {
        NotificationAlert("post Deleted successfully", "success");
      } else {
        NotificationAlert("Error While Deleting post");
      }
    } catch (error) {
      NotificationAlert("Error While Deleting post");
    }
  };

  // for remove shared post

  const [removeSharedPost] = useDeleteSharePostMutation();
  const handleRemoveSharedPost = async () => {
    try {
      const res = await removeSharedPost({
        userId: userID,
        postId: postID,
      });
      if (!res.error) {
        NotificationAlert("Post Removed From Shared", "success");
      } else {
        NotificationAlert("Error While Removing post");
      }
    } catch (error) {
      NotificationAlert("Error While Removing post");
    }
  };

  return (
    <div>
      <div
        style={
          darkmode
            ? { width: "auto", background: DarkColors.bgsecondarycolordark }
            : { width: "auto", background: LightColors.bgsecondarycolorlight }
        }
        className={style.EditProfileWrapper}
      >
        {userID === autherID ? (
          <>
            <p
              className={style.EditProfileButton}
              onClick={() => {
                setIsEditPost(true);
              }}
              style={
                darkmode
                  ? {
                      textTransform: "capitalize",
                      color: DarkColors.fonttextcolordark,
                    }
                  : {
                      textTransform: "capitalize",
                      color: LightColors.fonttextcolorlight,
                    }
              }
            >
              <span>Edit</span> Post
            </p>

            <p
              className={style.EditProfileButton}
              onClick={() => setIsDeletePost(true)}
              style={
                darkmode
                  ? {
                      textTransform: "capitalize",
                      color: DarkColors.fonttextcolordark,
                    }
                  : {
                      textTransform: "capitalize",
                      color: LightColors.fonttextcolorlight,
                    }
              }
            >
              <span>Delete</span> Post
            </p>
          </>
        ) : null}
        {isSharedPost && (
          <p
            className={style.EditProfileButton}
            onClick={() => setIsRemoveShared(true)}
            style={
              darkmode
                ? {
                    textTransform: "capitalize",
                    color: DarkColors.fonttextcolordark,
                  }
                : {
                    textTransform: "capitalize",
                    color: LightColors.fonttextcolorlight,
                  }
            }
          >
            <span>Remove</span> Shared Post
          </p>
        )}
      </div>

      {isEditPost && (
        <div className={style.modalDiv}>
          <span className={style.modalSpan}>
            <EditPostModal
              setIsEditPost={setIsEditPost}
              item={item}
              setIsOpoup={setIsOpoup}
            />
          </span>
        </div>
      )}

      {isDeletePost && (
        <DeletePopup
          deleteFun={handlePostDelete}
          setDeletePopup={setIsDeletePost}
          setIsOpoup={setIsOpoup}
        />
      )}
      {isRemoveShared && (
        <DeletePopup
          deleteFun={handleRemoveSharedPost}
          setDeletePopup={setIsRemoveShared}
        />
      )}
    </div>
  );
};

export default ThreeDotModal;
