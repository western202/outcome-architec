// import React from "react";
import Swal from "sweetalert2";
import { useDeleteInstructorsMutation } from "../../../Redux/InstructorSlices/Instructor";
import { NotificationAlert } from "../../NotificationAlert/NotificationAlert";

const DeleteInstructor = ({ setDeleteInstructor, instrctorID }) => {
  const [deleteInstructor] = useDeleteInstructorsMutation();
  const handleDeleteInstructor = async () => {
    try {
      const res = await deleteInstructor({
        id: instrctorID,
      });
      if (!res.error) {
        NotificationAlert("instructor deleted successfully", "success");
      } else {
        NotificationAlert("Error While Deleting instructor");
      }
    } catch (error) {
      NotificationAlert("Error While Deleting instructor");
    }
  };
  Swal.fire({
    title: "Are you sure?",
    text: "You won't be able to revert this!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes, delete it!",
  }).then((result) => {
    if (result.isConfirmed) {
      // If the user confirms deletion
      handleDeleteInstructor().then(() => {
        Swal.fire("Deleted!", "Student has been deleted.", "success");
        setDeleteInstructor(false);
      });
    } else if (result.isDismissed) {
      // If the user cancels the deletion
      setDeleteInstructor(false);
    }
  });
};

export default DeleteInstructor;
