import React, { useState } from "react";
import Calendar from "react-calendar";
import "./Celender.css";

function getDatesInRange(startDate, endDate) {
  const dates = [];
  const currentDate = new Date(startDate);

  while (currentDate <= new Date(endDate)) {
    dates.push(currentDate.toISOString().split("T")[0]);
    currentDate.setDate(currentDate.getDate() + 1);
  }

  return dates;
}

function Celender() {
  const [value, onChange] = useState(new Date());

  const events = ["2023-07-31", "2023-08-15", "2023-08-03"];
  return (
    <>
      <Calendar
        onChange={onChange}
        value={value}
        tileClassName={({ activeStartDate, date }) => {
          const startDate = activeStartDate.toISOString().split("T")[0];
          const endDate = date.toISOString().split("T")[0];
          const allDates = getDatesInRange(startDate, endDate);
          for (const singleDate of allDates) {
            if (events.includes(singleDate)) {
              return "highlightDate";
            } else {
              return "date_not";
            }
          }
        }}
      />
    </>
  );
}

export default Celender;
