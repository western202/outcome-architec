import React, { useEffect, useState } from "react";
import { Col } from "react-bootstrap";
import { Form, InputGroup } from "react-bootstrap";
import styles from "./search.module.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSearch } from "@fortawesome/free-solid-svg-icons";
import { DarkContext } from "../../Context/DarkContext";
import { DarkColors } from "../../Utils/Colors";
import { useContext } from "react";

function Search({ setIsSearch }) {
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  const handleSearch = (e) => {
    setIsSearch(e.target.value);
  };

  return (
    <>
      <Col xs={12} sm={8} md={5} lg={5} className={styles.btn}>
        <Form>
          <Form.Group
            className={` ${styles.inputFieldsWrap}`}
            style={
              darkmode
                ? { background: DarkColors.fonttextcolordark, border: "none" }
                : { border: "1px solid #ebe6e6" }
            }
            controlId="formBasicEmail"
          >
            <InputGroup style={{ gap: "0.5rem" }}>
              <InputGroup.Text
                className={styles.fieldIcon}
                style={
                  darkmode ? { background: DarkColors.fonttextcolordark } : {}
                }
              >
                <FontAwesomeIcon
                  icon={faSearch}
                  className={styles.searchIcon}
                  style={
                    darkmode ? { background: DarkColors.fonttextcolordark } : {}
                  }
                />
              </InputGroup.Text>
              <input
                className={styles.fields}
                type="text"
                name="to"
                placeholder="Search"
                onChange={(e) => handleSearch(e)}
                style={
                  darkmode
                    ? {
                        background: DarkColors.fonttextcolordark,
                        border: "none",
                      }
                    : { backgroundColor: "transparent" }
                }
              />
            </InputGroup>
          </Form.Group>
        </Form>
      </Col>
    </>
  );
}

export default Search;
