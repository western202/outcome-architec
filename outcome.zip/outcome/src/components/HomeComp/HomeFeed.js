import React, { useState } from "react";
import { Container, Row, Col } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faHeart,
  faComment,
  faShareFromSquare,
} from "@fortawesome/free-regular-svg-icons";
import solidheart from "../../assets/solidheart.svg";
import style from "./homefeed.module.css";
import Form from "react-bootstrap/Form";
import gallery from "../../assets/gallery.svg";
import { faPaperPlane } from "@fortawesome/free-solid-svg-icons";
import video from "../../assets/video.svg";
import {
  useGetPostQuery,
  useGetPostsForAdminQuery,
  useLikesMutation,
  useSharePostMutation,
} from "../../Redux/GlobalSlices/Global";
import { useInstructorPostsQuery } from "../../Redux/StudentSlices/Student";
import { DarkColors, LightColors } from "../../Utils/Colors";
import { useNavigate } from "react-router-dom";
import EditIcon from "../Modal/EditPost/EditIcon";
import { useAddPostMutation } from "../../Redux/Post/Post";
import { Swiper, SwiperSlide } from "swiper/react";
import ListLoader from "../Loader/ListLoader";
import { DefaultPlayer as Video } from "react-html5video";
import "react-html5video/dist/styles.css";
import { NotificationAlert } from "../NotificationAlert/NotificationAlert";

const HomeFeed = () => {
  // const [postId, setPostId] = useState();
  const [isUpdatePost, setIsUpdatePost] = useState(false);
  const userData = JSON.parse(localStorage.getItem("user"));
  const id = userData.user._id;
  // const userRole = userData.user.role?.[0];
  const invitedByID = userData?.user?.invitedByID;
  const navigate = useNavigate();
  const themeMode = JSON.parse(localStorage.getItem("isdarkmode"));
  const [postShare] = useSharePostMutation();

  const handlePostShare = async (postId) => {
    try {
      const res = await postShare({
        postId: postId,
        userId: id,
      });
      if (!res.error) {
        NotificationAlert("post Shared successfully", "success");
      }
      if (res.error) {
        NotificationAlert("Error While Sharing Post");
      }
    } catch (error) {
      NotificationAlert("Error While Sharing Post");
    }
  };

  const postsForAdmin = useGetPostsForAdminQuery();

  const getPost = useGetPostQuery(id, {
    skip: !id,
  });
  const instructorPosts = useInstructorPostsQuery(invitedByID, {
    skip: !invitedByID,
  });

  const [postContent, setPostContent] = useState();

  const [galleryImages, setGalleryImages] = useState([]);
  const [postVideo, setPostVideo] = useState("");

  const onChangeGalleryImage = (e) => {
    const files = e.target.files;
    const fileArray = Array.from(files); // Convert FileList to an array

    if (fileArray?.length <= 3) {
      setPostVideo("");
      setGalleryImages(fileArray);
    } else {
      NotificationAlert("You can't select more than 3 images");
    }
  };

  const onChangeVideo = (e) => {
    setGalleryImages([]);
    setPostVideo(e.target.files[0]);
  };

  const [likes] = useLikesMutation();

  const [post, { isLoading }] = useAddPostMutation();

  const handlePost = async () => {
    if (postContent) {
      try {
        const id = userData?.user?._id;
        const formData = new FormData();
        if (galleryImages.length > 0 && postVideo === "") {
          formData.append("content", postContent);
          galleryImages.forEach((image, index) => {
            formData.append("imageUrls", image, image.name);
          });
          setPostVideo("");
        } else if (galleryImages.length === 0 && postVideo !== "") {
          formData.append("content", postContent);
          formData.append("videoUrls", postVideo);
        } else {
          formData.append("content", postContent);
          setPostVideo("");
          setGalleryImages([]);
        }

        const res = await post({ userid: id, data: formData });

        if (!res.error) {
          NotificationAlert("post Created successfully", "success");

          setPostContent("");
          setGalleryImages([]);
          setPostVideo("");
        }
        getPost.refetch();
      } catch (error) {
        NotificationAlert("Error While Creating post");
      }
    } else {
      NotificationAlert("Add Some Content");
    }
  };

  const onLike = async (postID) => {
    try {
      const res = await likes({ userID: id, postID });
      if (!res.error) {
        if (res.data.likes.some((likes) => likes._id === id)) {
          NotificationAlert("Post Liked", "success");
        } else {
          NotificationAlert("Post Unliked", "success");
        }
        postsForAdmin.refetch();
        getPost.refetch();
        instructorPosts.refetch();
      }
      if (res.error) {
        NotificationAlert("Error");
      }
    } catch (error) {}
  };

  const breakpoints = {
    320: {
      slidesPerView: 1,
      spaceBetween: 10,
    },
    480: {
      slidesPerView: 1,
      spaceBetween: 20,
    },
    768: {
      slidesPerView: 1,
      spaceBetween: 30,
    },
    1024: {
      slidesPerView: 1,
      spaceBetween: 20,
    },
  };

  return (
    <>
      <div>
        <Container className={style.HomeFeedwrapper}>
          {userData.user.role?.[0] === "Instructor" ? (
            <Container
              className={`${style.homefeedinput}`}
              style={
                themeMode
                  ? { background: DarkColors.bgsecondarycolordark }
                  : { background: LightColors.bgsecondarycolorlight }
              }
            >
              <Row>
                <Col xs="12" className="d-flex justify-content-center">
                  <div
                    className={`${style.Homeinput} d-flex align-items-center`}
                  >
                    <Form.Control
                      className={style.postField}
                      name="postContent"
                      value={postContent}
                      onChange={(e) => setPostContent(e.target.value)}
                      size="lg"
                      type="text"
                      placeholder="What's On Your Mind?"
                      style={themeMode ? { background: "none" } : {}}
                    />
                    {isLoading ? (
                      <ListLoader />
                    ) : postContent !== undefined ? (
                      <FontAwesomeIcon
                        icon={faPaperPlane}
                        onClick={handlePost}
                        className={`fa-lg px-4 ${style.postComment}`}
                        style={
                          themeMode
                            ? { color: "#6aa22c", cursor: "pointer" }
                            : { color: "#6aa22c", cursor: "pointer" }
                        }
                      />
                    ) : (
                      <FontAwesomeIcon
                        icon={faPaperPlane}
                        className={`fa-lg px-4 ${style.postComment}`}
                        style={
                          themeMode
                            ? { color: "#6aa22c", cursor: "pointer" }
                            : { color: "#6aa22c", cursor: "pointer" }
                        }
                      />
                      // ""
                    )}
                  </div>
                </Col>
              </Row>
              <Row className=" d-flex align-items-center justify-content-around">
                <Col xs="4" className="text-center">
                  <label
                    htmlFor="imageUpload"
                    style={{ color: "var(--btn-color)" }}
                  >
                    <div
                      className={`${style.addfield} d-flex justify-content-center align-items-center`}
                      style={{ cursor: "pointer" }}
                    >
                      <img
                        alt="home page"
                        src={gallery}
                        style={{ width: "35px" }}
                        className={style.addfieldicon}
                      />
                      <h6
                        className={`${style.addfieldname} ps-3 pt-1`}
                        style={
                          themeMode
                            ? { color: DarkColors.btntextcolordark }
                            : { color: LightColors.headingcolor }
                        }
                      >
                        Photos
                      </h6>
                      {galleryImages.length > 0 && (
                        <p
                          className="m-0 ms-3 d-flex gap-1"
                          style={
                            themeMode
                              ? {
                                  color: DarkColors.btntextcolordark,
                                  fontWeight: "bolder",
                                }
                              : {
                                  color: LightColors.headingcolor,
                                  fontWeight: "bolder",
                                }
                          }
                        >
                          (
                          <p
                            className="m-0"
                            style={
                              themeMode
                                ? {
                                    color: DarkColors.btntextcolordark,
                                    fontWeight: "bolder",
                                  }
                                : {
                                    color: LightColors.headingcolor,
                                    fontWeight: "bolder",
                                  }
                            }
                          >
                            {galleryImages.length}
                          </p>{" "}
                          Image Selected)
                        </p>
                      )}
                    </div>
                  </label>
                  <input
                    type="file"
                    onChange={onChangeGalleryImage}
                    name="imageUrls"
                    id="imageUpload"
                    multiple="multiple"
                    // accept="video/png/jpeg*"
                    accept="image/png, image/gif, image/jpeg"
                    style={{ display: "none" }}
                  />
                </Col>
                <Col xs="4" className="text-center">
                  <label
                    htmlFor="videoUpload"
                    style={{ color: "var(--btn-color)" }}
                  >
                    <div
                      className="d-flex justify-content-start align-items-center"
                      style={{ cursor: "pointer" }}
                    >
                      <img
                        alt="home page"
                        src={video}
                        style={{ width: "35px" }}
                        className={style.addfieldicon}
                      />
                      <h6
                        className={`${style.addfieldname} ps-3 pt-1`}
                        style={
                          themeMode
                            ? { color: DarkColors.btntextcolordark }
                            : { color: LightColors.headingcolor }
                        }
                      >
                        Video
                      </h6>
                      {postVideo !== "" && (
                        <p
                          className="m-0 ms-3 d-flex gap-1"
                          style={
                            themeMode
                              ? {
                                  color: DarkColors.btntextcolordark,
                                  fontWeight: "bolder",
                                }
                              : {
                                  color: LightColors.headingcolor,
                                  fontWeight: "bolder",
                                }
                          }
                        >
                          <p
                            className="m-0"
                            style={
                              themeMode
                                ? {
                                    color: DarkColors.btntextcolordark,
                                    fontWeight: "bolder",
                                  }
                                : {
                                    color: LightColors.headingcolor,
                                    fontWeight: "bolder",
                                  }
                            }
                          ></p>
                          (Video Selected)
                        </p>
                      )}
                    </div>
                  </label>
                  <input
                    type="file"
                    onChange={onChangeVideo}
                    id="videoUpload"
                    accept="video/*"
                    style={{ display: "none" }}
                  />
                </Col>
              </Row>
            </Container>
          ) : (
            ""
          )}
          {userData?.user?.role?.[0] === "Admin"
            ? postsForAdmin?.data?.allPosts &&
              postsForAdmin?.data?.allPosts?.map((post, index) => (
                <div
                  key={index}
                  className={style.homefeedmain}
                  style={
                    themeMode
                      ? { background: DarkColors.bgsecondarycolordark }
                      : { background: LightColors.bgsecondarycolorlight }
                  }
                >
                  <div className={style.Postprofile}>
                    <div
                      className="d-flex gap-2"
                      onClick={() =>
                        navigate(`/instructorprofile/${post?._id}`)
                      }
                      style={{ cursor: "pointer" }}
                    >
                      <span className="d-flex justify-content-center p-0">
                        <img
                          src={post?.author?.profileImg}
                          className={style.profilePic}
                          alt={post?.author?.profileImg}
                        />
                      </span>
                      <span className="p-0 d-flex flex-column justify-content-center align-items-start">
                        <p
                          className={`${style.HomefeedDesc} pb-1 m-0`}
                          style={
                            themeMode
                              ? { color: DarkColors.btntextcolordark }
                              : { color: LightColors.headingcolor }
                          }
                        >
                          {post?.author?.username}
                        </p>
                      </span>
                    </div>
                    {id === post?.author?._id ? (
                      <span className="pe-4">
                        <EditIcon
                          item={post}
                          isSharedPost={false}
                          isUpdatePost={isUpdatePost}
                          setIsUpdatePost={setIsUpdatePost}
                        />
                      </span>
                    ) : null}
                  </div>

                  <Row className="justify-content-center w-100">
                    {post.imageUrls.length !== 0 && !post.videoUrls ? (
                      <div>
                        <p
                          className="mt-3 mb-4"
                          style={
                            themeMode
                              ? { color: DarkColors.btntextcolordark }
                              : { color: LightColors.headingcolor }
                          }
                        >
                          {post.content}
                        </p>
                        <Swiper breakpoints={breakpoints}>
                          {post.imageUrls.map((img, index) => (
                            <React.Fragment key={index + 1}>
                              <Row>
                                <SwiperSlide>
                                  <div>
                                    <img
                                      alt="home page"
                                      style={{
                                        height: "40rem",
                                        width: "100%",
                                        objectFit: "cover",
                                      }}
                                      src={img}
                                      className="py-1"
                                    />
                                  </div>
                                </SwiperSlide>
                              </Row>
                            </React.Fragment>
                          ))}
                        </Swiper>
                      </div>
                    ) : post?.videoUrls ? (
                      <div>
                        <p
                          className="mt-3 mb-4"
                          style={
                            themeMode
                              ? { color: DarkColors.btntextcolordark }
                              : { color: LightColors.headingcolor }
                          }
                        >
                          {post.content}
                        </p>

                        <Video
                          controls={[
                            "PlayPause",
                            "Seek",
                            "Time",
                            "Volume",
                            "Fullscreen",
                          ]}
                          style={{
                            height: "30rem",
                          }}
                        >
                          <source src={post.videoUrls} type="video/mp4" />
                          <track
                            label="English"
                            kind="subtitles"
                            srcLang="en"
                            src={post.videoUrls}
                            default
                          />
                        </Video>
                      </div>
                    ) : (
                      <Row>
                        <p
                          className="mt-3 mb-4"
                          style={
                            themeMode
                              ? { color: DarkColors.fonttextcolordark }
                              : { color: LightColors.fonttextcolorlight }
                          }
                        >
                          {post.content}
                        </p>
                      </Row>
                    )}
                  </Row>
                  <Row className="mt-2" sm="6">
                    {post?.likes?.some((like) => like._id === id) ? (
                      <Col
                        xs="1"
                        className="w-auto"
                        style={{ cursor: "pointer" }}
                      >
                        <div
                          role="button"
                          onClick={() => onLike(post._id)}
                          className={`${style.homeFeedHeart} d-flex gap-1 align-items-center`}
                        >
                          <img
                            src={solidheart}
                            alt={solidheart}
                            style={{ color: "red" }}
                          />
                          <p
                            className="m-0"
                            style={
                              themeMode
                                ? { color: DarkColors.btntextcolordark }
                                : { color: LightColors.headingcolor }
                            }
                          >
                            {post.likes.length}
                          </p>
                        </div>
                      </Col>
                    ) : (
                      <Col
                        xs="1"
                        className="w-auto "
                        style={{ cursor: "pointer" }}
                      >
                        <div
                          role="button"
                          onClick={() => onLike(post._id)}
                          className={`${style.homeFeedHeart} d-flex gap-1 align-items-center`}
                        >
                          <FontAwesomeIcon
                            icon={faHeart}
                            className={style.homeFeedHeartIcon}
                            style={
                              themeMode
                                ? { color: DarkColors.btntextcolordark }
                                : { color: LightColors.headingcolor }
                            }
                          />
                          <p
                            className="m-0"
                            style={
                              themeMode
                                ? { color: DarkColors.btntextcolordark }
                                : { color: LightColors.headingcolor }
                            }
                          >
                            {post.likes.length}
                          </p>
                        </div>
                      </Col>
                    )}
                    <Col
                      xs="1"
                      className="w-auto"
                      style={{ cursor: "pointer" }}
                    >
                      <div
                        className={`${style.homeFeedHeart} d-flex gap-1 align-items-center`}
                        onClick={() => navigate(`/homecomments/${post._id}`)}
                      >
                        <FontAwesomeIcon
                          icon={faComment}
                          className={style.homeFeedHeartIcon}
                          style={
                            themeMode
                              ? { color: DarkColors.btntextcolordark }
                              : { color: LightColors.headingcolor }
                          }
                        />
                        <p
                          className="m-0"
                          style={
                            themeMode
                              ? { color: DarkColors.btntextcolordark }
                              : { color: LightColors.headingcolor }
                          }
                        >
                          {post.comments.length}
                        </p>
                      </div>
                    </Col>
                  </Row>
                </div>
              ))
            : userData.user.role?.[0] === "Instructor"
            ? getPost.data &&
              getPost.data.posts &&
              getPost.data.posts.map((post, index) => (
                <div
                  key={index}
                  className={style.homefeedmain}
                  style={
                    themeMode
                      ? { background: DarkColors.bgsecondarycolordark }
                      : { background: LightColors.bgsecondarycolorlight }
                  }
                >
                  <div className={style.Postprofile}>
                    <div
                      className="d-flex gap-2"
                      onClick={() =>
                        navigate(`/instructorprofile/${post?.authorID[0]?._id}`)
                      }
                      style={{ cursor: "pointer" }}
                    >
                      <span className="d-flex justify-content-center p-0">
                        <img
                          src={post.authorID[0].profileImg}
                          className={style.profilePic}
                          alt={post.authorID[0].profileImg}
                        />
                      </span>
                      <span className="p-0 d-flex align-items-center">
                        <p
                          className={`${style.HomefeedDesc} pb-1 m-0`}
                          style={
                            themeMode
                              ? { color: DarkColors.btntextcolordark }
                              : { color: LightColors.headingcolor }
                          }
                        >
                          {post.authorID[0].username}
                        </p>
                      </span>
                    </div>
                    {id === post?.authorID[0]._id ? (
                      <span className="pe-4">
                        <EditIcon
                          item={post}
                          isSharedPost={false}
                          isUpdatePost={isUpdatePost}
                          setIsUpdatePost={setIsUpdatePost}
                          getPost={getPost}
                        />
                      </span>
                    ) : null}
                  </div>

                  <Row
                    className="d-flex justify-content-center align-items-center"
                    style={{ width: "99%" }}
                  >
                    {post.imageUrls.length !== 0 && !post.videoUrls ? (
                      <div>
                        <p
                          className="mt-3 mb-4"
                          style={
                            themeMode
                              ? { color: DarkColors.btntextcolordark }
                              : { color: LightColors.headingcolor }
                          }
                        >
                          {post.content}
                        </p>
                        <Swiper breakpoints={breakpoints}>
                          {post.imageUrls.map((img, index) => (
                            <React.Fragment key={index + 1}>
                              <Row>
                                <SwiperSlide>
                                  <div>
                                    <img
                                      alt="home page"
                                      style={{
                                        height: "40rem",
                                        width: "100%",
                                        objectFit: "cover",
                                      }}
                                      src={img}
                                      className={` ${style.images} py-1`}
                                    />
                                  </div>
                                </SwiperSlide>
                              </Row>
                            </React.Fragment>
                          ))}
                        </Swiper>
                      </div>
                    ) : post?.videoUrls ? (
                      <div>
                        <p
                          className="mt-3 mb-4"
                          style={
                            themeMode
                              ? { color: DarkColors.btntextcolordark }
                              : { color: LightColors.headingcolor }
                          }
                        >
                          {post.content}
                        </p>

                        <Video
                          // muted
                          controls={[
                            "PlayPause",
                            "Seek",
                            "Time",
                            "Volume",
                            "Fullscreen",
                          ]}
                          style={{
                            height: "30rem",
                            width: "100%",
                          }}
                        >
                          <source src={post.videoUrls} type="video/mp4" />
                          <track
                            label="English"
                            kind="subtitles"
                            srcLang="en"
                            src={post.videoUrls}
                            default
                          />
                        </Video>
                      </div>
                    ) : (
                      <Row>
                        <p
                          className="mt-3 mb-4"
                          style={
                            themeMode
                              ? { color: DarkColors.fonttextcolordark }
                              : { color: LightColors.fonttextcolorlight }
                          }
                        >
                          {post.content}
                        </p>
                      </Row>
                    )}
                  </Row>

                  <Row className="mt-2" sm="6">
                    <>
                      {post?.likes?.some((like) => like._id === id) ? (
                        <Col
                          xs="1"
                          className="w-auto"
                          style={{ cursor: "pointer" }}
                        >
                          <div
                            role="button"
                            onClick={() => onLike(post._id)}
                            className={`${style.homeFeedHeart} d-flex gap-1 align-items-center`}
                          >
                            <img
                              src={solidheart}
                              alt={solidheart}
                              style={{ color: "red" }}
                            />
                            <p
                              className="m-0"
                              style={
                                themeMode
                                  ? { color: DarkColors.btntextcolordark }
                                  : { color: LightColors.headingcolor }
                              }
                            >
                              {post.likes.length}
                            </p>
                          </div>
                        </Col>
                      ) : (
                        <Col
                          xs="1"
                          className="w-auto "
                          style={{ cursor: "pointer" }}
                        >
                          <div
                            role="button"
                            onClick={() => onLike(post._id)}
                            className={`${style.homeFeedHeart} d-flex gap-1 align-items-center`}
                          >
                            <FontAwesomeIcon
                              icon={faHeart}
                              className={style.homeFeedHeartIcon}
                              style={
                                themeMode
                                  ? { color: DarkColors.btntextcolordark }
                                  : { color: LightColors.headingcolor }
                              }
                            />
                            <p
                              className="m-0"
                              style={
                                themeMode
                                  ? { color: DarkColors.btntextcolordark }
                                  : { color: LightColors.headingcolor }
                              }
                            >
                              {post.likes.length}
                            </p>
                          </div>
                        </Col>
                      )}

                      <Col
                        xs="1"
                        className="w-auto"
                        style={{ cursor: "pointer" }}
                      >
                        <div
                          className={`${style.homeFeedHeart} d-flex gap-1 align-items-center`}
                          onClick={() => navigate(`/homecomments/${post._id}`)}
                        >
                          <FontAwesomeIcon
                            icon={faComment}
                            className={style.homeFeedHeartIcon}
                            style={
                              themeMode
                                ? { color: DarkColors.btntextcolordark }
                                : { color: LightColors.headingcolor }
                            }
                          />
                          <p
                            className="m-0"
                            style={
                              themeMode
                                ? { color: DarkColors.btntextcolordark }
                                : { color: LightColors.headingcolor }
                            }
                          >
                            {post.comments.length}
                          </p>
                        </div>
                      </Col>
                      <Col
                        xs="1"
                        className="w-auto d-flex"
                        style={{ cursor: "pointer" }}
                      >
                        <div
                          className={`${style.homeFeedHeart} d-flex align-items-center`}
                        >
                          <FontAwesomeIcon
                            icon={faShareFromSquare}
                            className={style.homeFeedHeartIcon}
                            onClick={() => handlePostShare(post._id)}
                            style={
                              themeMode
                                ? { color: DarkColors.btntextcolordark }
                                : { color: LightColors.headingcolor }
                            }
                          />
                        </div>
                      </Col>
                    </>
                  </Row>
                </div>
              ))
            : userData.user.role?.[0] === "Student"
            ? instructorPosts?.data &&
              instructorPosts?.data?.posts &&
              instructorPosts?.data?.posts?.map((post, index) => (
                <div
                  key={index}
                  className={style.homefeedmain}
                  style={
                    themeMode
                      ? { background: DarkColors.bgsecondarycolordark }
                      : { background: LightColors.bgsecondarycolorlight }
                  }
                >
                  <div className={style.Postprofile}>
                    <div
                      className="d-flex gap-2"
                      onClick={() =>
                        navigate(`/instructorprofile/${post?._id}`)
                      }
                      style={{ cursor: "pointer" }}
                    >
                      <span className="d-flex justify-content-center p-0">
                        <img
                          src={post.authorID[0].profileImg}
                          className={style.profilePic}
                          alt={post.authorID[0].profileImg}
                        />
                      </span>
                      <span className="p-0 d-flex align-items-center">
                        <p
                          className={`${style.HomefeedDesc} pb-1 m-0`}
                          style={
                            themeMode
                              ? { color: DarkColors.btntextcolordark }
                              : { color: LightColors.headingcolor }
                          }
                        >
                          {post.authorID[0].username}
                        </p>
                      </span>
                    </div>
                    {id === post?.authorID[0]._id ? (
                      <span className="pe-4">
                        <EditIcon
                          item={post}
                          isSharedPost={false}
                          isUpdatePost={isUpdatePost}
                          setIsUpdatePost={setIsUpdatePost}
                        />
                      </span>
                    ) : null}
                  </div>
                  <Row
                    className="justify-content-center "
                    style={{
                      width: "100%",
                    }}
                  >
                    {post.imageUrls.length !== 0 && !post.videoUrls ? (
                      <div>
                        <p
                          style={
                            themeMode
                              ? { color: DarkColors.btntextcolordark }
                              : { color: LightColors.headingcolor }
                          }
                        >
                          {post.content}
                        </p>
                        <Swiper breakpoints={breakpoints}>
                          {post.imageUrls.map((img, index) => (
                            <React.Fragment key={index + 1}>
                              <Row>
                                <SwiperSlide>
                                  <div>
                                    <img
                                      alt="home page"
                                      style={{
                                        height: "40rem",
                                        width: "100%",
                                        objectFit: "cover",
                                      }}
                                      src={img}
                                      className="py-1"
                                    />
                                  </div>
                                </SwiperSlide>
                              </Row>
                            </React.Fragment>
                          ))}
                        </Swiper>
                      </div>
                    ) : post?.videoUrls ? (
                      <div>
                        <p
                          className="mt-3 mb-4"
                          style={
                            themeMode
                              ? { color: DarkColors.btntextcolordark }
                              : { color: LightColors.headingcolor }
                          }
                        >
                          {post.content}
                        </p>

                        <Video
                          // muted
                          controls={[
                            "PlayPause",
                            "Seek",
                            "Time",
                            "Volume",
                            "Fullscreen",
                          ]}
                          style={{
                            height: "30rem",
                          }}
                        >
                          <source src={post.videoUrls} type="video/mp4" />
                          <track
                            label="English"
                            kind="subtitles"
                            srcLang="en"
                            src={post.videoUrls}
                            default
                          />
                        </Video>
                      </div>
                    ) : (
                      <Row>
                        <p
                          className="mt-3 mb-4"
                          style={
                            themeMode
                              ? { color: DarkColors.fonttextcolordark }
                              : { color: LightColors.fonttextcolorlight }
                          }
                        >
                          {post.content}
                        </p>
                      </Row>
                    )}
                  </Row>
                  <Row className="mt-2" sm="6">
                    {post?.likes?.some((like) => like._id === id) ? (
                      <Col
                        xs="1"
                        className="w-auto"
                        style={{ cursor: "pointer" }}
                      >
                        <div
                          role="button"
                          onClick={() => onLike(post._id)}
                          className={`${style.homeFeedHeart} d-flex gap-1 align-items-center`}
                        >
                          <img
                            src={solidheart}
                            alt={solidheart}
                            style={{ color: "red" }}
                          />
                          <p
                            className="m-0"
                            style={
                              themeMode
                                ? { color: DarkColors.btntextcolordark }
                                : { color: LightColors.headingcolor }
                            }
                          >
                            {post.likes.length}
                          </p>
                        </div>
                      </Col>
                    ) : (
                      <Col
                        xs="1"
                        className="w-auto "
                        style={{ cursor: "pointer" }}
                      >
                        <div
                          role="button"
                          onClick={() => onLike(post._id)}
                          className={`${style.homeFeedHeart} d-flex gap-1 align-items-center`}
                        >
                          <FontAwesomeIcon
                            icon={faHeart}
                            className={style.homeFeedHeartIcon}
                            style={
                              themeMode
                                ? { color: DarkColors.btntextcolordark }
                                : { color: LightColors.headingcolor }
                            }
                          />
                          <p
                            className="m-0"
                            style={
                              themeMode
                                ? { color: DarkColors.btntextcolordark }
                                : { color: LightColors.headingcolor }
                            }
                          >
                            {post.likes.length}
                          </p>
                        </div>
                      </Col>
                    )}

                    <Col
                      xs="1"
                      className="w-auto"
                      style={{ cursor: "pointer" }}
                    >
                      <div
                        className={`${style.homeFeedHeart} d-flex gap-1 align-items-center`}
                        onClick={() => navigate(`/homecomments/${post._id}`)}
                      >
                        <FontAwesomeIcon
                          icon={faComment}
                          className={style.homeFeedHeartIcon}
                          style={
                            themeMode
                              ? { color: DarkColors.btntextcolordark }
                              : { color: LightColors.headingcolor }
                          }
                        />
                        <p
                          className="m-0"
                          style={
                            themeMode
                              ? { color: DarkColors.btntextcolordark }
                              : { color: LightColors.headingcolor }
                          }
                        >
                          {post.comments.length}
                        </p>
                      </div>
                    </Col>
                    <Col
                      xs="1"
                      className="w-auto d-flex"
                      style={{ cursor: "pointer" }}
                    >
                      <div
                        className={`${style.homeFeedHeart} d-flex align-items-center`}
                      >
                        <FontAwesomeIcon
                          icon={faShareFromSquare}
                          className={style.homeFeedHeartIcon}
                          onClick={() => handlePostShare(post._id)}
                          style={
                            themeMode
                              ? { color: DarkColors.btntextcolordark }
                              : { color: LightColors.headingcolor }
                          }
                        />
                      </div>
                    </Col>
                  </Row>
                </div>
              ))
            : ""}
        </Container>
      </div>
    </>
  );
};

export default HomeFeed;
