import React, { useEffect, useState } from "react";
import { Container, Col, Row } from "react-bootstrap";
import style from "./homeright.module.css";
import mainPic from "../../assets/homefeedgallery.png";
import { Swiper, SwiperSlide } from "swiper/react";
import { DarkContext } from "../../Context/DarkContext";
import { DarkColors, LightColors } from "../../Utils/Colors";

// Import Swiper styles
import "swiper/css";
import { useContext } from "react";
import { useAllStudentQuery } from "../../Redux/GlobalSlices/Global";
import { useAllInstructorsQuery } from "../../Redux/InstructorSlices/Instructor";

function HomeRight() {
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);
  const user = JSON.parse(localStorage.getItem("user"));

  const adminAllStudentsAPI = useAllStudentQuery();
  const allInstructors = useAllInstructorsQuery();
  return (
    <>
      <Container
        className={style.homeRightWrapper}
        style={
          darkmode
            ? { background: DarkColors.bgsecondarycolordark }
            : { background: LightColors.bgsecondarycolorlight }
        }
      >
        <div className="d-flex flex-column gap-5">
          <div
            className="d-flex flex-column
          justify-content-center
          align-items-center"
          >
            <div className={style.homeRightMain}>
              <img src={mainPic} alt={mainPic} />
            </div>
            <Row className={style.profilePic}>
              <img src={user.user.profileImg} alt={user.user.profileImg} />
            </Row>
            <div className={style.profileNames}>
              <Row>
                <h4
                  className={style.visitorName}
                  style={
                    darkmode
                      ? { color: DarkColors.btntextcolordark }
                      : { color: LightColors.headingcolor }
                  }
                >
                  {user.user.username}
                  {/* Alea Candau */}
                </h4>
              </Row>
              <Row>
                <Col
                  style={
                    darkmode
                      ? {
                          color: DarkColors.fonttextcolordark,
                          fontSize: "0.8rem",
                          fontWeight: "600",
                        }
                      : {
                          color: LightColors.fonttextcolorlight,
                          fontSize: "0.8rem",
                          fontWeight: "600",
                        }
                  }
                >
                  <p className={`${style.name} m-0`}>
                    {" "}
                    {user?.user?.role?.[0] === "Student"
                      ? "Learner"
                      : user?.user?.role?.[0] === "Instructor"
                      ? "Coach"
                      : "Admin"}{" "}
                  </p>
                </Col>
                <Col
                  style={
                    darkmode
                      ? {
                          color: DarkColors.fonttextcolordark,
                          fontSize: "0.8rem",
                          fontWeight: "600",
                        }
                      : {
                          color: LightColors.fonttextcolorlight,
                          fontSize: "0.8rem",
                          fontWeight: "600",
                        }
                  }
                >
                  {/* <p className={`${style.name} m-0`}> 12,80 </p> */}
                </Col>
              </Row>
            </div>
            <div className={` ${style.membersMain} d-flex flex-column gap-2`}>
              <h5
                style={
                  darkmode
                    ? {
                        color: DarkColors.btntextcolordark,
                        zIndex: "100",
                        fontWeight: "700",
                      }
                    : {
                        color: LightColors.headingcolor,
                        zIndex: "100",
                        fontWeight: "700",
                      }
                }
              >
                Coach
              </h5>
              <Swiper
                spaceBetween={1}
                slidesPerView={5}
                style={{
                  width: "20rem",
                  overflow: "hidden",
                }}
                className={style.homeRightSlider}
              >
                <span className={style.members}>
                  {allInstructors?.data?.instructors.map((pic, index) => (
                    <SwiperSlide key={index}>
                      <img
                        style={{
                          borderRadius: "50%",
                          width: "3rem",
                          height: "3rem",
                        }}
                        src={pic.profileImg}
                        alt={`Person ${index + 1}`}
                      />
                    </SwiperSlide>
                  ))}
                </span>
              </Swiper>
              <h5
                style={
                  darkmode
                    ? {
                        color: DarkColors.btntextcolordark,
                        zIndex: "100",
                        fontWeight: "700",
                      }
                    : {
                        color: LightColors.headingcolor,
                        zIndex: "100",
                        fontWeight: "700",
                      }
                }
              >
                Learner
              </h5>
              <Swiper
                spaceBetween={1}
                slidesPerView={5}
                style={{
                  width: "20rem",
                  overflow: "hidden",
                }}
                className={style.homeRightSlider}
              >
                {/* <span className={style.members}> */}
                {adminAllStudentsAPI?.data?.students.map((cur, index) => (
                  // <div key={index + 1}>
                  <SwiperSlide key={index}>
                    <img
                      style={{
                        borderRadius: "50%",
                        width: "3rem",
                        height: "3rem",
                      }}
                      src={cur.profileImg}
                      alt={`Person ${index + 1}`}
                    />
                  </SwiperSlide>
                  // {/* </div> */}
                ))}
                {/* </span> */}
              </Swiper>
            </div>
          </div>
        </div>
      </Container>
    </>
  );
}

export default HomeRight;
