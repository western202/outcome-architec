import { Line } from "rc-progress";

function Loading({ barcolor, percent = 10 }) {
  return (
    <>
      <Line
        percent={percent}
        strokeWidth={4}
        strokeColor={barcolor}
        style={{ width: "100%", height: "1rem" }}
      />
    </>
  );
}

export default Loading;
