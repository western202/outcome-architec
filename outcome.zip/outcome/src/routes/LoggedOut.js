import React from "react";
import Login from "../Pages/login/Login";
import { Navigate } from "react-router-dom";

const LoggedOut = [
  {
    path: "/",
    element: <Login />,
  },
  {
    path: "*",
    element: <Navigate to="/" />,
  },
];

export default LoggedOut;
