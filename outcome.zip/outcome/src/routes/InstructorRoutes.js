import React from "react";
import Home from "../Pages/home/Home";
import Instruction from "../Pages/Instructor/Instruction";
import DashBoard from "../Pages/DashBoard/DashBoard";
import Activity from "../Pages/Activity/Activity";
import Schedule from "../Pages/Schedule/Schedule";
import Profile from "../Pages/Profile/Profile";
import Notification from "../Pages/Notification/Notification";
import Students from "../Pages/Students/Students";
import Details from "../Pages/Details/Details";
import { Navigate } from "react-router-dom";
import ActivitySinglePage from "../Pages/Activity/ActivitySinglePage/ActivitySinglePage";
import Studentprofile from "../Pages/Students/StudentProfile/Studentprofile";
import Instructorprofile from "../Pages/Instructor/InstructorProfile/Instructorprofile";
import Homecomments from "../Pages/home/HomeComments/Homecomments";

const InstructorRoutes = [
  {
    path: "/details",
    element: <Details />,
  },
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/coursedetail/:id",
    element: <ActivitySinglePage />,
  },
  {
    path: "/dashboard",
    element: <DashBoard />,
  },
  {
    path: "/Courses",
    element: <Activity />,
  },
  {
    path: "/schedule",
    element: <Schedule />,
  },
  {
    path: "/students",
    element: <Students />,
  },
  {
    path: "/instructor",
    element: <Instruction />,
  },
  {
    path: "/profile",
    element: <Profile />,
  },
  {
    path: "/notification",
    element: <Notification />,
  },
  {
    path: "/studentprofile/:id",
    element: <Studentprofile />,
  },
  {
    path: "/instructorprofile/:id",
    element: <Instructorprofile />,
  },
  {
    path: "/homecomments/:id",
    element: <Homecomments />,
  },
  {
    path: "*",
    element: <Navigate to="/" />,
  },
];

export default InstructorRoutes;
