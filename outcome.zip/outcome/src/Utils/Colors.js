export const LightColors = {
  primarycolorlight: "#6aa22c",
  bgcolorlight: "#f3f3f396",
  btntextcolorlight: "white",
  fonttextcolorlight: "#A098AE",
  bgsecondarycolorlight: "white",
  headingcolor: "black",
};

export const DarkColors = {
  primarycolordark: "#6aa22c",
  bgcolordark: "#0E0E0E",
  btntextcolordark: "white",
  fonttextcolordark: "#A098AE",
  bgsecondarycolordark: "#212121",
  headingcolor: "white",
};
