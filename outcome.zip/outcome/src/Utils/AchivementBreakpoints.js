const achievementsbreakpoints = {
  280: {
    slidesPerView: 3,
    spaceBetween: 10,
  },
  320: {
    slidesPerView: 3,
    spaceBetween: 10,
  },
  480: {
    slidesPerView: 4,
    spaceBetween: 20,
  },
  768: {
    slidesPerView: 6,
    spaceBetween: 30,
  },
  1024: {
    slidesPerView: 8,
    spaceBetween: 20,
  },
};

export default achievementsbreakpoints;
