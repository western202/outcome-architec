import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import style from "./instructor.module.css";
import InstructorMid from "./instructorComp/InstructorMid";
import HomeLeft from "../../components/HomeComp/HomeLeft";
import Header from "../../components/Others/Header";
import Search from "../../components/Search/Search";
import { useState } from "react";
import AddInstructorModal from "../../components/Modal/AddInstructorModal";
import { useContext } from "react";
import { DarkContext } from "../../Context/DarkContext";
import { useEffect } from "react";
import { DarkColors, LightColors } from "../../Utils/Colors";

function Instruction() {
  const [isSearchInstructor, setIsSearchInstructor] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);


  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  const closeModal = () => {
    setIsOpen(false);
  };

  return (
    <>
      <div
        className={style.instructorWrapper}
        style={
          darkmode
            ? { background: DarkColors.bgcolordark }
            : { background: LightColors.bgcolorlight }
        }
      >
        <Header pageName={"Coaches"} />
        <Container
          fluid
          style={{
            padding: "0rem",
          }}
        >
          <Row>
            <Col
              lg="3"
              style={
                darkmode
                  ? {
                      borderTop: "1px solid black",
                      padding: "0rem",
                    }
                  : {
                      backgroundColor: "white",
                      borderTop: "1px solid #0000001a",
                      padding: "0rem",
                    }
              }
            >
              <HomeLeft />
            </Col>
            <Col lg="9" className={style.instructorMid}>
              <div className="d-flex justify-content-center align-items-center mt-5 w-100 gap-1">
                <Search setIsSearch={setIsSearchInstructor} />
                <button
                  className={style.instructorModalBtn}
                  onClick={() => setIsOpen(true)}
                >
                  Add Instructor
                </button>
              </div>
              <InstructorMid isSearchInstructor={isSearchInstructor} />
            </Col>
          </Row>
          {isOpen && (
            <div className={style.modalDiv}>
              <span className={style.modalSpan}>
                <AddInstructorModal
                  closeModal={closeModal}
                  setIsOpen={setIsOpen}
                  title="Invite Instructors"
                />
              </span>
            </div>
          )}
        </Container>
      </div>
    </>
  );
}

export default Instruction;
