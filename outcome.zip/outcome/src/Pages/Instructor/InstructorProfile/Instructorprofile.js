import React, { useContext, useEffect, useState } from "react";
import style from "./instructorprofile.module.css";
import Header from "../../../components/Others/Header";
import { Col, Container, Row } from "react-bootstrap";
import HomeLeft from "../../../components/HomeComp/HomeLeft";
import InstructorProfileMid from "./InstructorProfileMid/InstructorProfileMid";
import { DarkContext } from "../../../Context/DarkContext";
import { DarkColors, LightColors } from "../../../Utils/Colors";

function Instructorprofile() {
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);
  return (
    <div
      className={style.studentProfileWrapper}
      style={
        darkmode
          ? { background: DarkColors.bgcolordark }
          : { background: LightColors.bgcolorlight }
      }
    >
      <Header pageName={"StudentProfile"} />
      <Container fluid className="p-0">
        <Row>
          <Col
            lg="3"
            style={
              darkmode
                ? {
                    borderTop: "1px solid black",
                    padding: "0rem",
                  }
                : {
                    backgroundColor: "white",
                    borderTop: "1px solid #0000001a",
                    padding: "0rem",
                  }
            }
          >
            <HomeLeft />
          </Col>
          <Col
            lg="9"
            style={{
              height: "85vh",
              overflowY: "scroll",
            }}
          >
            <InstructorProfileMid />
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default Instructorprofile;
