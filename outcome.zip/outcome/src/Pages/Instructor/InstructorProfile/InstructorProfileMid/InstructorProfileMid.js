import React from "react";
import ProfilePic from "../../../../assets/ProfilePic.png";
import cup from "../../../../assets/AchievementsMedals/Cup.png";
import Planet from "../../../../assets/AchievementsMedals/Planet.png";
import Skill from "../../../../assets/AchievementsMedals/Skill.png";
import Puzzle from "../../../../assets/AchievementsMedals/Puzzle.png";
import Reading from "../../../../assets/AchievementsMedals/Reading Time.png";
import { Col, Container, Row } from "react-bootstrap";
import style from "./instructorprofilemid.module.css";
// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";
import { DarkColors, LightColors } from "../../../../Utils/Colors";
// Import Swiper styles
import "swiper/css";
import { useNavigate, useParams } from "react-router-dom";
import { useState } from "react";
import { DarkContext } from "../../../../Context/DarkContext";
import { useContext } from "react";
import { useEffect } from "react";
import breakpoints from "../../../../Utils/AchivementBreakpoints";
import { useStudentSingleProfileQuery } from "../../../../Redux/StudentSlices/Student";

const medals = [cup, Planet, Skill, Puzzle, Reading, cup, Planet];

function InstructorProfileMid() {
  const [darkmode, setDarkMode] = useState();
  const navigate = useNavigate();
  const { themeMode } = useContext(DarkContext);
  const { id } = useParams();
  const singleProfile = useStudentSingleProfileQuery(id);
  const userData = singleProfile?.data;
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);
  return (
    <>
      <Container
        className={style.ProfileWrapper}
        style={
          darkmode
            ? { background: DarkColors.bgsecondarycolordark }
            : { background: LightColors.bgsecondarycolorlight }
        }
      >
        <button
          style={{
            position: "absolute",
            top: "1rem",
            left: "1rem",
            boxShadow: "none",
          }}
          onClick={() => navigate("/instructor")}
        >
          Back
        </button>
        <img
          src={userData?.profileImg}
          className={style.ProfileImg}
          alt={ProfilePic}
        />
        <div className={style.ProfileNames}>
          <h3
            style={
              darkmode
                ? { color: DarkColors.headingcolor }
                : { color: LightColors.headingcolor }
            }
          >
            {userData?.username}
          </h3>
          <p>Member Since 2020</p>
        </div>
        <div className={style.ProfileDetail}>
          <span style={darkmode ? { background: "#4d4a4a" } : {}}>
            <p>Lectures</p>
            <h3>2300</h3>
          </span>
          <span style={darkmode ? { background: "#4d4a4a" } : {}}>
            <p>Hours</p>
            <h3>5600</h3>
          </span>
          <span style={darkmode ? { background: "#4d4a4a" } : {}}>
            <p>Hours</p>
            <h3>5600</h3>
          </span>
        </div>
        <div className={style.achievements}>
          <Swiper
            spaceBetween={3}
            slidesPerView={8}
            className={style.achievementsSwiper}
            breakpoints={breakpoints}
            style={{ marginTop: "1.5rem", width: "33rem", overflow: "hidden" }}
          >
            <Row className={style.span}>
              {medals.map((items, index) => (
                <SwiperSlide key={index}>
                  <Col key={index}>
                    <img src={items} alt={items} />
                  </Col>
                </SwiperSlide>
              ))}
            </Row>
          </Swiper>
        </div>
        <div className={style.bio}>
          <h3
            style={
              darkmode
                ? { color: DarkColors.headingcolor, fontWeight: "700" }
                : { color: LightColors.headingcolor, fontWeight: "700" }
            }
          >
            Bio
          </h3>
          <span style={darkmode ? { background: "#4d4a4a" } : {}}>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
            ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
            aliquip ex ea commodo consequat.Lorem ipsum dolor sit amet,
            consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
            labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
            exercitation ullamco laboris nisi ut aliquip ex ea commodo
            consequat.Lorem ipsum dolor sit amet, consectetur adipiscing elit,
            sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
            nisi ut aliquip ex ea commodo consequat.Lorem ipsum dolor sit amet,
            consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
            labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
            exercitation ullamco laboris nisi ut aliquip ex ea commodo
            consequat.
          </span>
        </div>
      </Container>
    </>
  );
}

export default InstructorProfileMid;
