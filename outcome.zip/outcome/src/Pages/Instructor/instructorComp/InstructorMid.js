import React, { useContext, useEffect, useState } from "react";
import style from "./instructorMid.module.css";
import { Col, Row } from "react-bootstrap";
import { useAllInstructorsQuery } from "../../../Redux/InstructorSlices/Instructor";
import Alpha_Profile from "../../../assets/user_profile.png";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faEnvelope,
  faCity,
  faPhoneVolume,
} from "@fortawesome/free-solid-svg-icons";
import { DarkContext } from "../../../Context/DarkContext";
import { DarkColors, LightColors } from "../../../Utils/Colors";
import DeleteInstructor from "../../../components/Modal/DeleteInstructor/DeleteInstructor";

function InstructorMid({ isSearchInstructor }) {
  const [instrctorID, setInstructorID] = useState();
  const [deleteInstructor, setDeleteInstructor] = useState(false);
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  const navigate = useNavigate();
  const allInstructors = useAllInstructorsQuery();

  useEffect(() =>{
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  const getInstructorID = (id) => {
    setInstructorID(id);
    setDeleteInstructor(true);
  };

  return (
    <>
      <Row
        className="d-flex justify-content-center mt-5"
        style={{ gap: "2rem", paddingLeft: "1rem", paddingRight: "1rem" }}
      >
        {allInstructors?.data?.instructors
          ?.filter((item) =>
            item.username
              .toLowerCase()
              .includes(isSearchInstructor.toLowerCase())
          )
          .map((card, index) => (
            <Col
              lg="6"
              key={index + 1}
              className={style.main}
              style={
                darkmode
                  ? { background: DarkColors.bgsecondarycolordark }
                  : { background: LightColors.bgsecondarycolorlight }
              }
            >
              <div className={`${style.card} p-3`}>
                <div
                  className={`${style.imgRow} d-flex justify-content-center`}
                >
                  {card?.profileImg ? (
                    <img
                      src={card?.profileImg }
                      alt={index}
                    />
                  ) : (
                    <img src={Alpha_Profile} alt={index} />
                  )}
                </div>
                <Row
                  className="d-flex justify-content-center mt-2"
                  style={
                    darkmode
                      ? { fontWeight: "bold", color: DarkColors.headingcolor }
                      : { fontWeight: "bold", color: LightColors.headingcolor }
                  }
                >
                  {card?.username}
                </Row>
                <Row
                  className={`d-flex gap-2 justify-content-center align-items-center mt-1 mb-2 ${style.professionRow}`}
                  style={
                    darkmode
                      ? { color: DarkColors.fonttextcolordark }
                      : { color: LightColors.fonttextcolorlight }
                  }
                >
                  <Col
                    className={`${style.profession} w-auto gap-2 d-flex justify-content-center align-items-center`}
                  >
                    <FontAwesomeIcon icon={faEnvelope} />
                    {card?.email}
                  </Col>
                  <div className="d-flex gap-2 p-0">
                    <Col
                      className={`${style.profession} w-auto gap-2 d-flex justify-content-center align-items-center`}
                    >
                      <FontAwesomeIcon icon={faCity} />
                      {card?.city}
                    </Col>
                    <Col
                      className={`${style.profession} w-auto gap-2 d-flex justify-content-center align-items-center`}
                    >
                      <FontAwesomeIcon icon={faPhoneVolume} />
                      {card?.phone}
                    </Col>
                  </div>
                </Row>
                <Row
                  className={`d-flex gap-2 justify-content-center align-items-center ${style.achievementRow}`}
                  style={{ marginBottom: "2rem", marginTop: "2rem" }}
                >
                  <div className={style.achievement}>
                    <p> Achievement</p>
                    <p>100</p>
                  </div>
                  <div className={`${style.achievement} `}>
                    <p>Certificate</p>
                    <p>50</p>
                  </div>
                </Row>
                <Row className={style.instructorAssign}>
                  <button
                    onClick={() => navigate(`/studentprofile/${card._id}`)}
                  >
                    View Profile
                  </button>
                  <button onClick={() => getInstructorID(card._id)}>
                    Delete Instructor
                  </button>
                </Row>
              </div>
            </Col>
          ))}
        {deleteInstructor && (
          <div className={style.modalDiv}>
            <span className={style.modalSpan}>
              <DeleteInstructor
                // closeModal={closeModal}
                setDeleteInstructor={setDeleteInstructor}
                title="Invite Students"
                instrctorID={instrctorID}
              />
            </span>
          </div>
        )}
      </Row>
    </>
  );
}

export default InstructorMid;
