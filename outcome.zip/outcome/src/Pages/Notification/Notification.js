import React from "react";
import HomeLeft from "../../components/HomeComp/HomeLeft";
import Header from "../../components/Others/Header";
import { Col, Container, Row } from "react-bootstrap";
import style from "./notification.module.css";
// import Search from "../../components/Search/Search";
import NotificationMid from "./NotificationMid/NotificationMid";
import { useState } from "react";
import { DarkContext } from "../../Context/DarkContext";
import { useContext } from "react";
import { useEffect } from "react";
import { DarkColors, LightColors } from "../../Utils/Colors";

function Notification() {
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);

  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);
  return (
    <>
      <div
        className={style.NotificationWrapper}
        style={
          darkmode
            ? { background: DarkColors.bgcolordark }
            : { background: LightColors.bgcolorlight }
        }
      >
        <Header pageName={"Notification"} />
        <Container fluid className="p-0">
          <Row>
            <Col
              lg="3"
              style={
                darkmode
                  ? {
                      borderTop: "1px solid black",
                      padding: "0rem",
                    }
                  : {
                      backgroundColor: "white",
                      borderTop: "1px solid #0000001a",
                      padding: "0rem",
                    }
              }
            >
              <HomeLeft />
            </Col>
            <Col
              // lg="5"
              style={{
                marginTop: "2rem",
                height: "87vh",
                overflowY: "scroll",
                paddingBottom: "6rem",
              }}
            >
              <NotificationMid />
            </Col>
          </Row>
        </Container>
      </div>
    </>
  );
}

export default Notification;
