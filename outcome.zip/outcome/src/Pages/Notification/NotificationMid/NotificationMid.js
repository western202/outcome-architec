import React from "react";
import style from "./notificationmid.module.css";
import { useState } from "react";
import { useGetNotificationsQuery } from "../../../Redux/StudentSlices/Student";
import { DarkContext } from "../../../Context/DarkContext";
import { useContext } from "react";
import { useEffect } from "react";
import { DarkColors, LightColors } from "../../../Utils/Colors";
import socket from "../../../Utils/Socket";


function NotificationMid() {
  const [darkmode, setDarkMode] = useState();
  // eslint-disable-next-line
  const [notification, setNotification] = useState();
  const { themeMode } = useContext(DarkContext);
  const userData = JSON.parse(localStorage.getItem("user"));
  const role = userData.user.role?.[0];
  const id = userData.user._id;
  const invitedID = userData?.user?.invitedByID;

  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  useEffect(() => {
    socket.on("connection", () => {
      socket.emit("userConnected", userData.user._id);
      socket.on("notificationEvent", (data) => {
        setNotification(data.length);
      });
    });
    // eslint-disable-next-line
  }, []);

  const apiId = role === "Instructor" ? id : invitedID;
  const getNotifications = useGetNotificationsQuery(apiId, {
    skip: !apiId,
  });
  const Notification = getNotifications?.data?.notifications;

  return (
    <>
      <main
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <div
          className="d-flex "
          style={{
            paddingLeft: "2rem",
            paddingRight: "2rem",
            alignItems: "baseline",
          }}
        ></div>
        <h2
          style={
            darkmode
              ? { fontWeight: "700", color: DarkColors.headingcolor }
              : { fontWeight: "700", color: LightColors.headingcolor }
          }
          className={style.noti_today}
        >
          Notifications
        </h2>

        {role === "Instructor" ? (
          getNotifications?.isError ? (
            <div>
              <h4 className="text-center text-light mt-5">
                Unable to load notifications
              </h4>
            </div>
          ) : getNotifications?.isLoading ? (
            <div>
              <h4 className="text-center text-light mt-5">Loading...</h4>
            </div>
          ) : getNotifications?.data?.notifications?.length === 0 ? (
            <div>
              <h4 className="text-center text-light mt-5">
                No notification to show
              </h4>
            </div>
          ) : (
            Notification?.map((items, index) => (
              <div
                className={`${style.scheduleCard} d-flex gap-1 py-2 mt-4`}
                style={{
                  borderRadius: "10px",
                  width: "fit-content",
                }}
                key={index}
              >
                <div className="d-flex flex-column gap-2">
                  <span
                    className={`${style.noti_namesSpan} d-flex align-items-center justify-centent-start gap-2 `}
                  >
                    <h2 className={style.name}>
                      <img
                        src={items?.userID?.profileImg}
                        alt="no img"
                        width={50}
                      />
                    </h2>
                  </span>
                </div>
                <div className={style.noti_mid}>
                  <div
                    className="m-0 "
                    style={{ color: "#A098AE" }}
                    // dangerouslySetInnerHTML={{ __html: items.notifications }}
                  >
                    <h2>{items?.title}</h2>
                    <p>{items?.message}</p>
                  </div>
                </div>

                <div
                  className={`${style.scheduleRightSide} d-flex justify-content-center align-items-center gap-3`}
                >
                  <span
                    className={`${style.noti_TimeSpan} d-flex align-items-center gap-1 `}
                  >
                    <p
                      style={{ color: "#A098AE", width: "max-content" }}
                      className={`${style.scheduleTimes} m-0 `}
                    >
                      {new Date(items?.createdAt).toLocaleTimeString("en-US", {
                        hour: "numeric",
                        minute: "numeric",
                        hour12: true,
                      })}
                    </p>
                  </span>
                </div>
              </div>
            ))
          )
        ) : null}

        {role === "Student" ? (
          getNotifications?.isError ? (
            <div>
              <h4 className="text-center text-light">
                Unable to load notifications
              </h4>
            </div>
          ) : getNotifications?.isLoading ? (
            <div>
              <h4 className="text-center text-light">Loading...</h4>
            </div>
          ) : getNotifications?.data?.notifications?.length === 0 ? (
            <div>
              <h4 className="text-center text-light">
                No notification to show
              </h4>
            </div>
          ) : (
            Notification?.map((items, index) => (
              <div
                className={`${style.scheduleCard} d-flex gap-1 py-2 mt-4`}
                style={{
                  borderRadius: "10px",
                  width: "fit-content",
                }}
                key={index}
              >
                <div className="d-flex flex-column gap-2">
                  <span
                    className={`${style.noti_namesSpan} d-flex align-items-center justify-centent-start gap-2 `}
                  >
                    <h2 className={style.name}>
                      <img
                        src={items?.userID?.profileImg}
                        alt="no img"
                        width={50}
                      />
                    </h2>
                  </span>
                </div>
                <div className={style.noti_mid}>
                  <div
                    className="m-0 "
                    style={{ color: "#A098AE" }}
                    // dangerouslySetInnerHTML={{ __html: items.notifications }}
                  >
                    <h2>{items?.title}</h2>
                    <p>{items?.message}</p>
                  </div>
                </div>

                <div
                  className={`${style.scheduleRightSide} d-flex justify-content-center align-items-center gap-3`}
                >
                  <span
                    className={`${style.noti_TimeSpan} d-flex align-items-center gap-1 `}
                  >
                    <p
                      style={{ color: "#A098AE", width: "max-content" }}
                      className={`${style.scheduleTimes} m-0 `}
                    >
                      {new Date(items?.createdAt).toLocaleTimeString("en-US", {
                        hour: "numeric",
                        minute: "numeric",
                        hour12: true,
                      })}
                    </p>
                  </span>
                </div>
              </div>
            ))
          )
        ) : null}

        <div
          style={{
            width: "57rem",
            position: "relative",
            marginTop: "1rem",
          }}
          className={style.AllNotificationBtn}
        ></div>
      </main>
    </>
  );
}

export default NotificationMid;
