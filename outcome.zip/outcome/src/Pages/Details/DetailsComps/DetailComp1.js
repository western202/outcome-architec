import React, { useEffect } from "react";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Container from "react-bootstrap/Container";
import styles from "../details.module.css";

function DetailComp1({ onChange, userFields, setStep }) {
  const { username, phone, state } = userFields;

  useEffect(() => {
    setStep(0);
    //eslint-disable-next-line
  }, []);

  return (
    <>
      {" "}
      <Container className="d-flex justify-content-center align-items-center flex-column">
        <Row>
          <div className="d-flex align-items-center flex-column mt-3">
            <h2 className={styles.detailsHeading}>Tell us about yourself</h2>
            <p className={styles.headingPara}>
              A few cliks away from creating your account
            </p>
          </div>
        </Row>
        <Col className={` ${styles.formwrapper} mt-3 mb-5`}>
          <form action="input" className={styles.CompForm}>
            <Row>
              <input
                type="text"
                value={username}
                onChange={onChange}
                name="username"
                placeholder="Enter Your Username..."
                className={styles.CompFormInput}
              />
            </Row>
            <Row>
              <input
                type="text"
                value={phone}
                onChange={onChange}
                name="phone"
                placeholder="Enter your Phone..."
                className={styles.CompFormInput}
              />
            </Row>
            <Row>
              <input
                type="text"
                value={state}
                onChange={onChange}
                name="state"
                placeholder="state"
                className={styles.CompFormInput}
              />
            </Row>
          </form>
          <Row className="mt-3">
            <span
              className={`${styles.alreadyAcc} d-flex justify-content-between`}
            >
              <p>Already have account?</p>
              <p>Login</p>
            </span>
          </Row>
        </Col>
      </Container>
    </>
  );
}

export default DetailComp1;
