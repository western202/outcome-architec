import React, { useEffect } from "react";
import styles from "../details.module.css";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Container from "react-bootstrap/Container";

function DetailComp2({ onChange, userFields, setStep, onSubmit }) {
  const { zipCode, city, dob } = userFields;

  useEffect(() => {
    setStep(1);
    //eslint-disable-next-line
  }, []);

  return (
    <>
      <Container className="d-flex justify-content-center align-items-center flex-column">
        <Row>
          <div className="d-flex align-items-center flex-column mt-3">
            <h2 className={styles.detailsHeading}>Tell us about yourself</h2>
            <p className={styles.headingPara}>
              A few cliks away from creating your account
            </p>
          </div>
        </Row>
        <Col className={` ${styles.formwrapper} mt-3 mb-5`}>
          <form action="input" className={styles.CompForm}>
            <Row className="d-flex justify-content-center align-items-center">
              <input
                type="text"
                name="city"
                value={city}
                onChange={onChange}
                placeholder="city"
                className={styles.CompFormInput}
              />
            </Row>
            <Row className="d-flex justify-content-center align-items-center">
              <input
                type="text"
                name="zipCode"
                value={zipCode}
                onChange={onChange}
                placeholder="Zip code"
                className={styles.CompFormInput}
              />
            </Row>
            <Row className="d-flex justify-content-center align-items-center">
              <input
                type="date"
                name="dob"
                value={dob}
                onChange={onChange}
                placeholder="dob"
                className={styles.CompFormInput}
              />
            </Row>
            <Row className={`${styles.alreadyAcc} mt-3`}>
              <span className="d-flex justify-content-between">
                <p>Already have account?</p>
                <p>Login</p>
              </span>
            </Row>
          </form>
          <Row className={`text-center py-4 ${styles.b}`}>
            <button onClick={onSubmit} className={styles.sumbitBTN}>
              SUBMIT
            </button>
          </Row>
        </Col>
      </Container>
    </>
  );
}

export default DetailComp2;
