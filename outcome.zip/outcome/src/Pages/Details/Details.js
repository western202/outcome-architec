import MultiStep from "react-multistep";
import DetailComp1 from "./DetailsComps/DetailComp1";
import DetailComp2 from "./DetailsComps/DetailComp2";
import { useState } from "react";
import styles from "./details.module.css";
import { Container, Col, Row } from "react-bootstrap";
import { useCompleteInfoMutation } from "../../Redux/GlobalSlices/Global";
import { Navigate, useNavigate } from "react-router-dom";
import { NotificationAlert } from "../../components/NotificationAlert/NotificationAlert";

function SignUp() {
  const navigate = useNavigate();

  const [userFields, setUserFields] = useState({
    username: "",
    phone: Number,
    state: "",
    zipCode: "",
    city: "",
    dob: "",
  });

  const userData = JSON.parse(localStorage.getItem("user"));
  const id = userData?.user?._id;

  const handleOnchange = (e) => {
    setUserFields({ ...userFields, [e.target.name]: e.target.value });
  };

  const [completeInfo] = useCompleteInfoMutation();

  const onSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await completeInfo({
        id: id,
        data: {
          username: userFields.username,
          phone: userFields.phone,
          state: userFields.state,
          city: userFields.city,
          zipCode: userFields.zipCode,
          dob: userFields.dob,
        },
      });
      if (!res.error) {
        navigate("/home");
        NotificationAlert("Form Sumbits Successfully", "success");
      }
    } catch (error) {
      NotificationAlert("All Fields Required");
    }
  };

  const [step, setStep] = useState(0);
  return (
    <>
      {userData?.user?.username &&
      userData?.user?.phone &&
      userData?.user?.state &&
      userData?.user?.zipCode &&
      userData?.user?.city &&
      userData?.user?.dob ? (
        <Navigate to="/home" />
      ) : (
        <Container className={`${styles.wrapper} py-5`} fluid>
          <div className={styles.overlay}></div>
          <Row>
            <Col className={`text-center ${styles.MultiStep}`}>
              <MultiStep
                activeStep={step}
                showNavigation={step === 1 ? false : true}
              >
                <DetailComp1
                  setStep={setStep}
                  userFields={userFields}
                  onChange={handleOnchange}
                />
                <DetailComp2
                  setStep={setStep}
                  userFields={userFields}
                  onChange={handleOnchange}
                  onSubmit={onSubmit}
                />
              </MultiStep>
            </Col>
          </Row>
        </Container>
      )}
    </>
  );
}

export default SignUp;
