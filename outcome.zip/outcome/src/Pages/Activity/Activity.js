import React, { useEffect } from "react";
import HomeLeft from "../../components/HomeComp/HomeLeft";
import Header from "../../components/Others/Header";
import { Col, Container, Row } from "react-bootstrap";
import style from "./activity.module.css";
import Search from "../../components/Search/Search";
import ActivityMid from "./ActivityComp/ActivityMid";
import { useState } from "react";
import ActivitySinglePage from "./ActivitySinglePage/ActivitySinglePage";
import { DarkColors, LightColors } from "../../Utils/Colors";
import { DarkContext } from "../../Context/DarkContext";
import { useContext } from "react";
import AddCourse from "../../components/Modal/AddCourse";
import socket from "../../Utils/Socket";

function Activity() {
  const [isSearchCourse, setIsSearchCourse] = useState("");
  const [isOpen, setIsopen] = useState(false);
  const [updater, setUpdater] = useState(false);
  const [uploadCourse, setuploadCourse] = useState(false);
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  const userData = JSON.parse(localStorage.getItem("user"));
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  useEffect(() => {
    // eslint-disable-next-line
  }, []);
  socket.on("connection", () => {
    socket.emit("userConnected", userData.user._id);
    socket.on("notificationEvent", (data) => {
      console.log(data);
    });
  });

  return (
    <>
      <div
        className={style.ActivityWrapper}
        style={
          darkmode
            ? { background: DarkColors.bgcolordark }
            : { background: LightColors.bgcolorlight }
        }
      >
        <Header pageName={"Activity"} />
        <Container fluid className="p-0">
          <Row>
            <Col
              lg="3"
              style={
                darkmode
                  ? {
                      borderTop: "1px solid black",
                      padding: "0rem",
                    }
                  : {
                      backgroundColor: "white",
                      borderTop: "1px solid #0000001a",
                      padding: "0rem",
                    }
              }
            >
              <HomeLeft />
            </Col>
            <Col lg="9" className={style.activityMid}>
              <div className="d-flex justify-content-center align-items-center mt-5 w-100 gap-1">
                <Search setIsSearch={setIsSearchCourse} />
                {userData.user.role?.[0] === "Instructor" && (
                  <button
                    className={style.instructorModalBtn}
                    onClick={() => setuploadCourse(true)}
                  >
                    Upload Course
                  </button>
                )}
              </div>
              {isOpen ? (
                <ActivitySinglePage setIsopen={setIsopen} />
              ) : (
                <ActivityMid
                  setIsopen={setIsopen}
                  isSearchCourse={isSearchCourse}
                />
              )}
            </Col>
          </Row>
          {uploadCourse && (
            <AddCourse
              setIsOpen={setuploadCourse}
              setUpdater={setUpdater}
              updater={updater}
            />
          )}
        </Container>
      </div>
    </>
  );
}

export default Activity;
