import React from "react";
import style from "./singlepageright.module.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlay, faDownload, faTrash } from "@fortawesome/free-solid-svg-icons";
import { useParams } from "react-router-dom";
import {
  useDeleteCourseMutation,
  useSingleCourseQuery,
  useUploadCourseMutation,
} from "../../../../Redux/GlobalSlices/Global";
import { useState } from "react";
import { DarkContext } from "../../../../Context/DarkContext";
import { DarkColors, LightColors } from "../../../../Utils/Colors";
import { useContext } from "react";
import { useEffect } from "react";
import DeletePopup from "../../../../components/DeletePopup/DeletePopup";
import { NotificationAlert } from "../../../../components/NotificationAlert/NotificationAlert";
// const chapters = [];

function SinglePageRight() {
  const [files, setFiles] = useState([]);
  const [deletePopup, setDeletePopup] = useState(false);
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  const { id } = useParams();
  const singleCourse = useSingleCourseQuery(id);
  const [uploadCourse] = useUploadCourseMutation();
  const [deleteCourse] = useDeleteCourseMutation();
  const course = singleCourse?.data?.course;
  const user = JSON.parse(localStorage.getItem("user"));
  const instructorID = user?.user?._id;

  const courseInstructorID = singleCourse?.data?.course?.instructorID;
  const handleFileUpload = async (e) => {
    const formData = new FormData();
    formData.append("files", e.target.files[0]);
    try {
      const res = await uploadCourse({
        instructorID: instructorID,
        courseID: id,
        data: formData,
      });
      if (!res.error) {
        NotificationAlert("Course successfully uploaded", "success");
      } else {
        NotificationAlert("Error While Uploading Course");
      }
    } catch (error) {
      NotificationAlert("Error While Uploading Course");
    }
  };

  const handleDeleteFile = async () => {
    try {
      const res = await deleteCourse({
        userID: instructorID,
        courseID: id,
        data: [files],
      });
      if (!res.error) {
        NotificationAlert("Course successfully deleted", "success");
      } else {
        NotificationAlert("Error While Deleting Course");
      }
    } catch (error) {
      NotificationAlert("Error While Deleting Course");
    }
  };

  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  return (
    <>
      <div
        className={style.SinglePageRightWrapper}
        style={
          darkmode
            ? { background: DarkColors.bgsecondarycolordark }
            : { background: LightColors.bgsecondarycolorlight }
        }
      >
        <span className="d-flex justify-content-between align-items-center">
          <h3
            style={
              darkmode
                ? { color: DarkColors.headingcolor }
                : { color: LightColors.headingcolor }
            }
          >
            Download PDFs
          </h3>

          <label htmlFor="courseUpload">
            <span>
              {courseInstructorID === instructorID ? (
                <p
                  style={{
                    color: "white",
                    padding: "1rem",
                    margin: 0,
                    background: "#6aa22c",
                    fontWeight: 700,
                    borderRadius: "10px",
                    cursor: "pointer",
                  }}
                >
                  Upload courses
                </p>
              ) : (
                ""
              )}
            </span>
            <input
              type="file"
              id="courseUpload"
              className="d-none"
              onChange={handleFileUpload}
              accept=".pdf"
            />
          </label>
        </span>
        {course?.files?.map((course, index) => (
          <div className={style.SinglePageRightDiv} key={index}>
            <span className={style.SinglePageRightSpan}>
              <div>
                <FontAwesomeIcon
                  icon={faPlay}
                  style={{ color: "green" }}
                  className={style.SinglePageRightplay}
                />
              </div>
              <p>Chapters {index + 1}</p>
            </span>
            <span>
              {courseInstructorID === instructorID ? (
                <FontAwesomeIcon
                  icon={faTrash}
                  style={{ color: "white", marginRight: "0.5rem" }}
                  className={style.SinglePageRightDownload}
                  onClick={() => {
                    setDeletePopup(true);
                    setFiles(course);
                  }}
                />
              ) : (
                ""
              )}

              <FontAwesomeIcon
                icon={faDownload}
                style={{ color: "white" }}
                className={style.SinglePageRightDownload}
                onClick={() => window.open(`${course}`, "_blank")}
              />
            </span>
          </div>
        ))}
      </div>
      {deletePopup && (
        <DeletePopup
          setDeletePopup={setDeletePopup}
          deleteFun={handleDeleteFile}
        />
      )}
    </>
  );
}

export default SinglePageRight;
