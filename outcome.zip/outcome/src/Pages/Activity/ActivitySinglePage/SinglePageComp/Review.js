import React, { useState } from "react";
import style from "./review.module.css";
import { useParams } from "react-router-dom";
import {
  useCourseReviewMutation,
  useDeleteReviewMutation,
  useGetReviewsQuery,
} from "../../../../Redux/GlobalSlices/Global";
import { useContext } from "react";
import { DarkContext } from "../../../../Context/DarkContext";
import { useEffect } from "react";
import { DarkColors, LightColors } from "../../../../Utils/Colors";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash } from "@fortawesome/free-solid-svg-icons";
import DeletePopup from "../../../../components/DeletePopup/DeletePopup";
import { NotificationAlert } from "../../../../components/NotificationAlert/NotificationAlert";

function Review({ setOpenReviewModal, setReviewData }) {
  const [deletePop, setDeletePopup] = useState(false);
  const [reviewId, setReviewId] = useState("");
  const [review, setReview] = useState("");
  // const [revirewData, setReviewData] = useState({});
  // eslint-disable-next-line
  // const [rating, setRating] = useState(Number);
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  const userData = JSON.parse(localStorage.getItem("user"));
  const studentID = userData.user._id;
  const { id } = useParams();
  const getReviews = useGetReviewsQuery(id, {
    skip: !id,
  });
  const [courseReview] = useCourseReviewMutation();
  const [deleteReview] = useDeleteReviewMutation();

  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  const onSubmit = async () => {
    try {
      const res = await courseReview({
        courseID: id,
        studentID: studentID,
        review: review,
        // rating: rating,
      });
      setReviewData(res.data);

      if (!res.error) {
        NotificationAlert("Review Posted", "success");

        setReview("");
        setOpenReviewModal(true);
      } else {
        NotificationAlert("Error While Posting Review");
      }
    } catch (error) {
      NotificationAlert("Error While Posting Review");
    }
  };

  const handleGiveReview = () => {
    if (review !== "") {
      onSubmit();
    }
  };

  const handleDeletePopupModal = (id) => {
    setReviewId(id);
    setDeletePopup(true);
  };

  const deleteReviews = async () => {
    try {
      const res = await deleteReview({
        reviewID: reviewId,
      });
      if (!res.error) {
        NotificationAlert("Review Deleted successfully", "success");
      } else {
        NotificationAlert("Error While Deleting Review");
      }
    } catch (error) {
      NotificationAlert("Error While Deleting Review");
    }
  };

  return (
    <>
      <div className={style.reviewWrapper}>
        {userData.user.role?.[0] === "Student" && (
          <div
            className={`${style.giveReviewFields} d-flex gap-2 align-items-center mb-2`}
          >
            <span>
              <input
                type="text"
                required
                value={review}
                name="review..."
                onChange={(e) => setReview(e.target.value)}
                placeholder="Review"
                style={{
                  borderRadius: "10px",
                  padding: "0.5rem",
                  border: "1px solid grey",
                  outline: "none",
                }}
              />
            </span>
            {getReviews?.data?.reviews !== "" && (
              <div>
                {review !== "" && (
                  <button
                    onClick={handleGiveReview}
                    style={{
                      boxShadow: "none",
                      border: "1px solid grey",
                      outline: "none",
                    }}
                  >
                    Give Review
                  </button>
                )}
              </div>
            )}
          </div>
        )}
        {getReviews?.data?.reviews.map((item, index) => (
          <React.Fragment key={index}>
            <div className={style.reviewdetail} key={index}>
              <div className="d-flex align-items-center gap-2">
                <img
                  src={item.studentID.profileImg}
                  alt="tags"
                  style={{ borderRadius: "50%" }}
                />
                <span className={style.reviewdetailSpan}>
                  <p>
                    <b
                      style={
                        darkmode
                          ? { color: DarkColors.headingcolor }
                          : { color: LightColors.headingcolor }
                      }
                    >
                      {item.studentID.username}
                    </b>
                  </p>
                </span>
              </div>
              {item.studentID?._id === studentID ? (
                <FontAwesomeIcon
                  icon={faTrash}
                  style={{
                    color: "#A098AE",
                    marginRight: "1rem",
                    cursor: "pointer",
                  }}
                  onClick={() => handleDeletePopupModal(item._id)}
                />
              ) : null}
            </div>
            <p
              className={style.reviewWrapperPara}
              style={
                darkmode
                  ? { color: DarkColors.fonttextcolordark }
                  : { color: LightColors.fonttextcolorlight }
              }
            >
              {item.review}
            </p>
          </React.Fragment>
        ))}
      </div>
      {deletePop && (
        <DeletePopup
          deleteFun={deleteReviews}
          setDeletePopup={setDeletePopup}
        />
      )}
    </>
  );
}

export default Review;
