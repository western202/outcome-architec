import React, { useState } from "react";
import style from "./coursedetail.module.css";
import profilePic from "../../../../assets/profile_img.png";
import {
  useGetRatingQuery,
  useGetReviewsQuery,
  useSingleCourseQuery,
} from "../../../../Redux/GlobalSlices/Global";
import { useParams } from "react-router-dom";
// import Addreview from "../../../../components/Modal/Addreview";
import { useContext } from "react";
import { DarkContext } from "../../../../Context/DarkContext";
import { useEffect } from "react";
import { DarkColors, LightColors } from "../../../../Utils/Colors";
import ManageCourse from "../../../../components/Modal/ManageCourse/ManageCourse";
import { Rating } from "react-simple-star-rating";

function CourseDetail({ openReview, setOpenReview }) {
  // const [instructorCourse, setInstructorCourse] = useState();
  const [manageCourse, setManageCourse] = useState(false);
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  const { id } = useParams();

  const getReviews = useGetReviewsQuery(id);

  const singleCourse = useSingleCourseQuery(id);
  const course = singleCourse?.data?.course;
  const Names = singleCourse?.data?.instructor;

  const user = JSON.parse(localStorage.getItem("user"));
  const instructorID = user?.user?._id;

  const courseID = course?._id;
  const getReview = useGetRatingQuery(courseID, {
    skip: !courseID,
  });
  const globalRating = Math.ceil(getReview?.data?.averageRating);
  const courseInstructorID = singleCourse?.data?.course?.instructorID;

  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  return (
    <div
      className={style.coursedetailwrapper}
      style={
        darkmode
          ? { background: DarkColors.bgsecondarycolordark }
          : { background: LightColors.bgsecondarycolorlight }
      }
    >
      <div className="d-flex justify-content-between">
        <h2
          style={
            darkmode
              ? { color: DarkColors.headingcolor }
              : { color: LightColors.headingcolor }
          }
        >
          {course?.title}
        </h2>
        {instructorID === courseInstructorID ? (
          <button
            style={{
              background: "#6aa22c",
              color: "white",
              boxShadow: "none",
            }}
            onClick={() => setManageCourse(true)}
          >
            Manage Course
          </button>
        ) : (
          ""
        )}
      </div>
      <p>{course?.desc}</p>
      <span className={style.averageReview}>
        <p className="d-flex align-items-end gap-1">
          {getReview?.data?.averageRating === undefined
            ? 0 + "." + 0
            : globalRating + "." + 0}
          <span
            style={{
              marginBottom: "0.1rem",
            }}
          >
            <Rating
              size={15}
              initialValue={
                getReview?.data?.averageRating === undefined ? 0 : globalRating
              }
              readonly
            />
          </span>
        </p>
        <p className="d-flex align-items-end gap-1">
          Review ({getReviews?.data?.reviews?.length})
        </p>
        <p className="d-flex align-items-end gap-1">10K students</p>
      </span>
      <span className={style.profileDetail}>
        <img
          src={Names?.profileImg ? Names?.profileImg : profilePic}
          alt="tags"
        />
        <p>{Names?.username}</p>
      </span>
      <div className={`${style.CourseDetailButtons} d-flex gap-3`}>
        <p
          style={openReview ? { fontWeight: 700 } : {}}
          onClick={() => setOpenReview(true)}
        >
          Review
        </p>
        <p
          style={openReview === false ? { fontWeight: 700 } : {}}
          onClick={() => setOpenReview(false)}
        >
          About
        </p>
      </div>
      {/* {isOpenReview && <Addreview setIsOpenReview={setIsOpenReview} />} */}
      {manageCourse && (
        <div className={style.modalDiv}>
          <span className={style.modalSpan}>
            <ManageCourse
              courseID={course._id}
              setManageCourse={setManageCourse}
              courseDetail={course}
              title="Invite Students"
              singleCourse={singleCourse}
            />
          </span>
        </div>
      )}
    </div>
  );
}

export default CourseDetail;
