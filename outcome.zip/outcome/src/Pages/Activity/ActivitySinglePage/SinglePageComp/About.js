import React, { useContext, useEffect, useState } from "react";
import img from "../../../../assets/profile_img.png";
import { useSingleCourseQuery } from "../../../../Redux/GlobalSlices/Global";
import { useParams } from "react-router-dom";
import { DarkContext } from "../../../../Context/DarkContext";
import { DarkColors, LightColors } from "../../../../Utils/Colors";

function About() {
  const { id } = useParams();
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);
  const singleCourse = useSingleCourseQuery(id);

  const course = singleCourse?.data?.course;

  return (
    <>
      <div
        style={
          darkmode
            ? {
                borderTop: "1px solid black",
                borderTopColor: "black",
                padding: "2rem 0rem 2rem 3rem",
              }
            : { borderTopColor: "#bfbfbf" }
        }
        className="d-flex flex-column gap-3"
      >
        <span className="d-flex align-items-center gap-3">
          <img src={img} alt="alpha" />
          <p
            className="m-0"
            style={
              darkmode
                ? { color: DarkColors.headingcolor, fontWeight: "700" }
                : { color: LightColors.headingcolor }
            }
          >
            {course?.title}
          </p>
        </span>
        <p
          style={
            darkmode
              ? {
                  margin: "0",
                  width: "66rem",
                  color: DarkColors.fonttextcolordark,
                }
              : { color: LightColors.fonttextcolorlight }
          }
        >
          {course?.desc}
        </p>
      </div>
    </>
  );
}

export default About;
