import React, { useEffect, useState } from "react";
import style from "./activitysinglepage.module.css";
import CourseDetail from "./SinglePageComp/CourseDetail";
import Review from "./SinglePageComp/Review";
import About from "./SinglePageComp/About";
import { useNavigate } from "react-router-dom";
import Header from "../../../components/Others/Header";
import { Container, Row, Col } from "react-bootstrap";
import HomeLeft from "../../../components/HomeComp/HomeLeft";
import { DarkContext } from "../../../Context/DarkContext";
import { DarkColors, LightColors } from "../../../Utils/Colors";
import { useContext } from "react";
import SinglePageRight from "./SinglePageComp/SinglePageRight";
import Addreview from "../../../components/Modal/Addreview";

function ActivitySinglePage() {
  const [revirewData, setReviewData] = useState({});
  const [darkmode, setDarkMode] = useState();
  const [openReview, setOpenReview] = useState(true);
  const [openReviewModal, setOpenReviewModal] = useState(false);
  const { themeMode } = useContext(DarkContext);
  const navigate = useNavigate();

  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  return (
    <>
      <div
        className={style.ActivitySinglePageWrapper}
        style={
          darkmode
            ? { background: DarkColors.bgcolordark }
            : { background: LightColors.bgcolorlight }
        }
      >
        <Header />
        <Container fluid>
          <Row className={style.ActivitySinglePageRow}>
            <Col
              lg="3"
              style={
                darkmode
                  ? {
                      borderTop: "1px solid black",
                      padding: "0rem",
                    }
                  : {
                      backgroundColor: "white",
                      borderTop: "1px solid #0000001a",
                      padding: "0rem",
                    }
              }
            >
              <HomeLeft />
            </Col>
            <Col
              lg="6"
              style={{
                height: "88vh",
                // overflowY: "scroll",
              }}
              className={style.ActivitySinglePageMid}
            >
              <button
                onClick={() => navigate("/Courses")}
                className={style.closeCourse}
              >
                BACK
              </button>

              <div
                className={style.singlepagewrapper}
                style={
                  darkmode
                    ? {
                        background: DarkColors.bgsecondarycolordark,
                      }
                    : { background: LightColors.bgsecondarycolorlight }
                }
              >
                <CourseDetail
                  openReview={openReview}
                  setOpenReview={setOpenReview}
                />
                {openReview ? (
                  <Review
                    setReviewData={setReviewData}
                    setOpenReviewModal={setOpenReviewModal}
                  />
                ) : (
                  <About />
                )}
              </div>
            </Col>
            <Col
              lg="3"
              // style={{
              //   height: "80vh",
              //   overflowY: "scroll",
              // }}
              style={
                darkmode
                  ? {
                      background: DarkColors.bgsecondarycolordark,
                      height: "80vh",
                    }
                  : {
                      background: LightColors.bgsecondarycolorlight,
                      overflowY: "scroll",
                    }
              }
              className={style.singlepageRightwrapper}
            >
              <SinglePageRight />
            </Col>
          </Row>
          {openReviewModal && (
            <Addreview
              setOpenReviewModal={setOpenReviewModal}
              revirewData={revirewData}
            />
          )}
        </Container>
      </div>
    </>
  );
}

export default ActivitySinglePage;
