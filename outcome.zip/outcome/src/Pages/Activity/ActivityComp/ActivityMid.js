import React, { useEffect, useState } from "react";
import style from "./activityMid.module.css";
import { Col, Row } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBookOpen, faTrash } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";
import {
  useCoursesByInstructorQuery,
  useDeleteInstructorCourseMutation,
} from "../../../Redux/GlobalSlices/Global";
import { DarkColors, LightColors } from "../../../Utils/Colors";
import { DarkContext } from "../../../Context/DarkContext";
import { useContext } from "react";
import { useAllCoursesQuery } from "../../../Redux/GlobalSlices/Global";
import DeletePopup from "../../../components/DeletePopup/DeletePopup";
import ListLoader from "../../../components/Loader/ListLoader";
import { NotificationAlert } from "../../../components/NotificationAlert/NotificationAlert";

function ActivityMid({ isSearchCourse }) {
  // const [instructorCourse, setInstructorCourse] = useState();
  const [isDeleteCourse, setIsDeleteCourse] = useState(false);
  const [courseId, setCourseId] = useState("");
  const navigate = useNavigate();
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);
  const userData = JSON.parse(localStorage.getItem("user"));

  let id;

  const [deleteCourse] = useDeleteInstructorCourseMutation();

  const instructorData = JSON.parse(localStorage.getItem("user"));

  const handleDeleteCourse = async () => {
    try {
      const res = await deleteCourse({
        userId: instructorData?.user?._id,
        courseId,
      });
      if (!res.error) {
        NotificationAlert("Course deleted successfully", "success");
      } else {
        NotificationAlert("unable to delete course..");
      }
    } catch (error) {
      NotificationAlert("unable to delete course..");
    }
  };

  if (userData.user.role?.[0] === "Instructor") {
    id = userData.user._id;
  } else if (userData.user.role?.[0] === "Student") {
    id = userData.user.invitedByID;
  } else if (userData.user.role?.[0] === "Admin") {
    id = userData.user._id;
  }
  const coursesByInstructor = useCoursesByInstructorQuery(id, {
    skip: !id,
  });
  const instructorCourseLoading = coursesByInstructor.isLoading;

  const allCourses = useAllCoursesQuery();

  const handleDeleteCourseModal = (course) => {
    setCourseId(course?._id);
    setIsDeleteCourse(true);
  };

  return (
    <>
      <Row
        className="d-flex justify-content-center mt-1"
        style={{ gap: "2rem" }}
      >
        <Row>
          <Col className={style.activityHeadingCol}>
            <h2
              className={style.activityHeading}
              style={
                darkmode
                  ? { color: DarkColors.headingcolor }
                  : { color: LightColors.headingcolor }
              }
            >
              All Courses
            </h2>
          </Col>
        </Row>
        {userData.user.role?.[0] === "Admin" ? (
          allCourses.isError ? (
            <span className="text-danger text-center">
              Something went wrong loading events
            </span>
          ) : allCourses.isLoading ? (
            <ListLoader />
          ) : (
            allCourses?.data?.courses
              ?.filter((item) =>
                item?.title
                  ?.toLowerCase()
                  ?.includes(isSearchCourse?.toLowerCase())
              )
              .map((card, index) => (
                <Col
                  lg="6"
                  key={index + 1}
                  style={
                    darkmode
                      ? { background: DarkColors.bgsecondarycolordark }
                      : { background: LightColors.bgsecondarycolorlight }
                  }
                  className={style.main}
                >
                  <div className={`${style.card} `}>
                    <div
                      className={`${style.imgRow} d-flex justify-content-center`}
                    >
                      <img
                        src={card?.courseThumbnail}
                        alt={card?.courseThumbnail}
                      />
                    </div>
                    <Row
                      className={`${style.activityHeading} d-flex justify-content-between mt-3 align-items-center`}
                      style={{ fontWeight: "bold" }}
                    >
                      <h4
                        style={
                          darkmode
                            ? { color: DarkColors.headingcolor }
                            : { color: LightColors.headingcolor }
                        }
                      >
                        {card?.title}
                      </h4>
                    </Row>
                    <Row
                      className={`${style.activityName} mt-2 d-flex align-items-center justify-content-between`}
                    >
                      <div className={style.title}>
                        <p>{card?.instructorID?.username}</p>
                        <div></div>
                        <p>
                          <FontAwesomeIcon icon={faBookOpen} />
                        </p>
                      </div>
                    </Row>
                    <p
                      style={{
                        position: "absolute",
                        bottom: "1rem",
                        color: "green",
                        fontWeight: "700",
                      }}
                      onClick={() => navigate(`/coursedetail/${card?._id}`)}
                    >
                      view Detail
                    </p>
                  </div>
                </Col>
              ))
          )
        ) : null}

        {userData.user.role?.[0] === "Instructor" ||
        userData.user.role?.[0] === "Student" ? (
          instructorCourseLoading ? (
            <ListLoader />
          ) : coursesByInstructor.isError ? (
            <span className="text-danger text-center">
              Something went wrong load events{" "}
            </span>
          ) : (
            coursesByInstructor?.data?.courses
              ?.filter((item) =>
                item?.title
                  ?.toLowerCase()
                  ?.includes(isSearchCourse?.toLowerCase())
              )
              .map((card, index) => (
                <Col
                  lg="6"
                  key={index + 1}
                  style={
                    darkmode
                      ? { background: DarkColors.bgsecondarycolordark }
                      : { background: LightColors.bgsecondarycolorlight }
                  }
                  className={style.main}
                >
                  <div className={`${style.card} `}>
                    <div
                      className={`${style.imgRow} d-flex justify-content-center`}
                    >
                      <img
                        src={card?.courseThumbnail}
                        alt={card?.courseThumbnail}
                      />
                    </div>
                    <Row
                      className={`${style.activityHeading} d-flex justify-content-between mt-3 align-items-center`}
                      style={{ fontWeight: "bold" }}
                    >
                      <h4
                        style={
                          darkmode
                            ? { color: DarkColors.headingcolor }
                            : { color: LightColors.headingcolor }
                        }
                      >
                        {card?.title}
                      </h4>
                    </Row>
                    <Row
                      className={`${style.activityName} mt-2 d-flex align-items-center justify-content-between`}
                    >
                      <div className={style.title}>
                        <p>{card?.instructorID?.username}</p>
                        <div></div>
                        <p>
                          {" "}
                          <FontAwesomeIcon icon={faBookOpen} />
                        </p>
                      </div>
                      {userData?.user?.role?.[0] === "Instructor" && (
                        <FontAwesomeIcon
                          icon={faTrash}
                          className="w-auto "
                          style={{ color: "#a098ae", paddingRight: "1.8rem" }}
                          onClick={() => handleDeleteCourseModal(card)}
                        />
                      )}
                    </Row>
                    <p
                      style={{
                        position: "absolute",
                        bottom: "1rem",
                        color: "green",
                        fontWeight: "700",
                      }}
                      onClick={() => {
                        navigate(`/coursedetail/${card?._id}`);
                      }}
                    >
                      view Detail
                    </p>
                  </div>
                </Col>
              ))
          )
        ) : null}
      </Row>
      {isDeleteCourse && (
        <DeletePopup
          deleteFun={handleDeleteCourse}
          setDeletePopup={setIsDeleteCourse}
        />
      )}
    </>
  );
}

export default ActivityMid;
