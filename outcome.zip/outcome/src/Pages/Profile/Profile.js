import style from "./profile.module.css";
import Header from "../../components/Others/Header";
import { Col, Container, Row } from "react-bootstrap";
import { DarkContext } from "../../Context/DarkContext";
import { useContext, useState, useEffect } from "react";
import HomeLeft from "../../components/HomeComp/HomeLeft";
import ProfileMid from "./ProfileComp/ProfileMid/ProfileMid";
import { DarkColors, LightColors } from "../../Utils/Colors";
import EditProfile from "../../components/Modal/EditProfile";
import SharedProfile from "./ProfileComp/ProfileMid/SharedProfile";

function Profile() {
  const [editProfile, setEditProfile] = useState(false);
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  const user = JSON.parse(localStorage.getItem("user"));
  const role = user?.user?.role?.[0];
  return (
    <>
      <div
        className={style.ProfileWrapper}
        style={
          darkmode
            ? { background: DarkColors.bgcolordark }
            : { background: LightColors.bgcolorlight }
        }
      >
        <Header pageName={"Profile"} />
        <Container fluid className="p-0">
          <Row>
            <Col
              lg="3"
              style={
                darkmode
                  ? {
                      borderTop: "1px solid black",
                      padding: "0rem",
                    }
                  : {
                      backgroundColor: "white",
                      borderTop: "1px solid #0000001a",
                      padding: "0rem",
                    }
              }
            >
              <HomeLeft />
            </Col>
            <Col
              lg="9"
              style={{
                height: "85vh",
                overflowY: "scroll",
              }}
            >
              <ProfileMid setEditProfile={setEditProfile} />
              {role === "Admin" ? null : (
                <h1
                  style={
                    darkmode
                      ? {
                          color: DarkColors.headingcolor,
                          padding: "3rem 0rem 0rem 4rem",
                          margin: "0 !important",
                          fontWeight: "bolder",
                        }
                      : {
                          color: LightColors.headingcolor,
                          padding: "3rem 0rem 0rem 4rem",
                          margin: "0 !important",
                          fontWeight: "bolder",
                        }
                  }
                >
                  Shared Feed
                </h1>
              )}
              <SharedProfile />
            </Col>
          </Row>
          {editProfile && (
            <div className={style.modalDiv}>
              <span
                className={style.modalSpan}
                style={
                  darkmode
                    ? {
                        background: DarkColors.bgsecondarycolordark,
                      }
                    : { background: LightColors.bgsecondarycolorlight }
                }
              >
                <EditProfile setEditProfile={setEditProfile} />
              </span>
            </div>
          )}
        </Container>
      </div>
    </>
  );
}

export default Profile;
