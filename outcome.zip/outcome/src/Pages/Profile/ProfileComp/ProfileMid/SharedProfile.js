import React, { useEffect, useState } from "react";
import { Container, Row, Col } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHeart, faComment } from "@fortawesome/free-regular-svg-icons";
import style from "./sharedprofile.module.css";
import solidheart from "../../../../assets/solidheart.svg";
// import videojs from "video.js";
// import "video.js/dist/video-js.css";
import { useLikesMutation } from "../../../../Redux/GlobalSlices/Global";
import { DarkColors, LightColors } from "../../../../Utils/Colors";
import { DarkContext } from "../../../../Context/DarkContext";
import { useContext } from "react";
import { useNavigate } from "react-router-dom";
import EditIcon from "../../../../components/Modal/EditPost/EditIcon";
import { useGetSharePostQuery } from "../../../../Redux/GlobalSlices/Global";
import { Swiper, SwiperSlide } from "swiper/react";
import { DefaultPlayer as Video } from "react-html5video";
import "react-html5video/dist/styles.css";
import { faDesktop } from "@fortawesome/free-solid-svg-icons";
import { NotificationAlert } from "../../../../components/NotificationAlert/NotificationAlert";

const SharedProfile = () => {
  const [isUpdatePost, setIsUpdatePost] = useState(false);
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);
  const userData = JSON.parse(localStorage.getItem("user"));

  const id = userData?.user?._id;
  const role = userData?.user?.role?.[0];
  const navigate = useNavigate();

  const getSharedPost = useGetSharePostQuery(id, {
    skip: !id,
  });
  const [likes] = useLikesMutation();

  const onLike = async (postID) => {
    try {
      // eslint-disable-next-line
      const res = await likes({ userID: id, postID });
      if (!res.error) {
        if (res.data.likes.some((likes) => likes._id === id)) {
          NotificationAlert("Post Liked", "success");
        } else {
          NotificationAlert("Post Unliked", "success");
        }

        getSharedPost.refetch();
      }
    } catch (error) {
      NotificationAlert("Error While Liking Post");
    }
  };
  const breakpoints = {
    320: {
      slidesPerView: 1,
      spaceBetween: 10,
    },
    480: {
      slidesPerView: 1,
      spaceBetween: 20,
    },
    768: {
      slidesPerView: 1,
      spaceBetween: 30,
    },
    1024: {
      slidesPerView: 1,
      spaceBetween: 20,
    },
  };

  return (
    <>
      <div>
        <Container className={`${style.HomeFeedwrapper} `}>
          {getSharedPost?.data?.sharedPosts.length > 0 ? (
            getSharedPost?.data?.sharedPosts?.map((post, index) => (
              <div
                key={index}
                className={style.homefeedmain}
                style={
                  darkmode
                    ? { background: DarkColors.bgsecondarycolordark }
                    : { background: LightColors.bgsecondarycolorlight }
                }
              >
                <div className={style.Postprofile}>
                  <div className="d-flex gap-2">
                    <span className="d-flex justify-content-center p-0">
                      <img
                        src={post?.authorID[0]?.profileImg}
                        className={style.profilePic}
                        alt={post?.authorID[0]?.profileImg}
                      />
                    </span>
                    <span className="p-0 d-flex flex-column align-items-start">
                      <p
                        className={`${style.HomefeedDesc} pb-1 m-0`}
                        style={
                          darkmode
                            ? { color: DarkColors.btntextcolordark }
                            : { color: LightColors.headingcolor }
                        }
                      >
                        {post?.authorID[0]?.username}
                      </p>
                    </span>
                  </div>
                  <span className="pe-4">
                    <EditIcon
                      item={post}
                      isSharedPost={true}
                      isUpdatePost={isUpdatePost}
                      setIsUpdatePost={setIsUpdatePost}
                    />
                  </span>
                </div>

                <Row className="justify-content-center w-100">
                  {post.imageUrls.length !== 0 && !post.videoUrls ? (
                    <div>
                      <p
                        className="mt-3 mb-4"
                        style={
                          darkmode
                            ? { color: DarkColors.btntextcolordark }
                            : { color: LightColors.headingcolor }
                        }
                      >
                        {post.content}
                      </p>
                      <Swiper breakpoints={breakpoints}>
                        {post.imageUrls.map((img, index) => (
                          <React.Fragment key={index + 1}>
                            <Row>
                              <SwiperSlide>
                                <div>
                                  <img
                                    alt="home page"
                                    style={{ height: "100%", width: "100%" }}
                                    src={img}
                                    className="py-1"
                                  />
                                </div>
                              </SwiperSlide>
                            </Row>
                          </React.Fragment>
                        ))}
                      </Swiper>
                    </div>
                  ) : post.videoUrls ? (
                    <div>
                      <p
                        className="mt-3 mb-4"
                        style={
                          darkmode
                            ? { color: DarkColors.btntextcolordark }
                            : { color: LightColors.headingcolor }
                        }
                      >
                        {post.content}
                      </p>
                      <Video
                        // muted
                        controls={[
                          "PlayPause",
                          "Seek",
                          "Time",
                          "Volume",
                          "Fullscreen",
                        ]}
                        style={{
                          height: "30rem",
                        }}
                      >
                        <source src={post.videoUrls} type="video/mp4" />
                        <track
                          label="English"
                          kind="subtitles"
                          srcLang="en"
                          src={post.videoUrls}
                          default
                        />
                      </Video>
                    </div>
                  ) : (
                    <Row>
                      <p
                        className="mt-3 mb-4"
                        style={
                          darkmode
                            ? { color: DarkColors.fonttextcolordark }
                            : { color: LightColors.fonttextcolorlight }
                        }
                      >
                        {post.content}
                      </p>
                    </Row>
                  )}
                </Row>
                <Row className="mt-2" sm="6">
                  {post?.likes?.some((like) => like._id === id) ? (
                    <Col
                      xs="1"
                      className="w-auto"
                      style={{ cursor: "pointer" }}
                    >
                      <div
                        role="button"
                        onClick={() => onLike(post._id)}
                        className={`${style.homeFeedHeart} d-flex gap-1 align-items-center`}
                      >
                        <img
                          src={solidheart}
                          alt={solidheart}
                          style={{ color: "red" }}
                        />
                        <p
                          className="m-0"
                          style={
                            themeMode
                              ? { color: DarkColors.btntextcolordark }
                              : { color: LightColors.headingcolor }
                          }
                        >
                          {post.likes.length}
                        </p>
                      </div>
                    </Col>
                  ) : (
                    <Col
                      xs="1"
                      className="w-auto "
                      style={{ cursor: "pointer" }}
                    >
                      <div
                        role="button"
                        onClick={() => onLike(post._id)}
                        className={`${style.homeFeedHeart} d-flex gap-1 align-items-center`}
                      >
                        <FontAwesomeIcon
                          icon={faHeart}
                          className={style.homeFeedHeartIcon}
                          style={
                            themeMode
                              ? { color: DarkColors.fonttextcolordark }
                              : { color: LightColors.fonttextcolorlight }
                          }
                        />
                        <p
                          className="m-0"
                          style={
                            themeMode
                              ? { color: DarkColors.fonttextcolordark }
                              : { color: LightColors.fonttextcolorlight }
                          }
                        >
                          {post.likes.length}
                        </p>
                      </div>
                    </Col>
                  )}
                  <Col xs="1" className="w-auto" style={{ cursor: "pointer" }}>
                    <div
                      className={`${style.homeFeedHeart} d-flex gap-1 align-items-center`}
                      onClick={() => navigate(`/homecomments/${post._id}`)}
                    >
                      <FontAwesomeIcon
                        icon={faComment}
                        className={style.homeFeedHeartIcon}
                        style={
                          darkmode
                            ? { color: DarkColors.btntextcolordark }
                            : { color: LightColors.headingcolor }
                        }
                      />
                      <p
                        className="m-0"
                        style={
                          darkmode
                            ? { color: DarkColors.btntextcolordark }
                            : { color: LightColors.headingcolor }
                        }
                      >
                        {post.comments.length}
                      </p>
                    </div>
                  </Col>

                  <Col
                    xs="1"
                    className="w-auto d-flex"
                    style={{ cursor: "pointer" }}
                  ></Col>
                </Row>
              </div>
            ))
          ) : role !== "Admin" ? (
            <div
              className={style.homefeedmain}
              style={
                darkmode
                  ? {
                      background: DarkColors.bgsecondarycolordark,
                      padding: "1rem 0rem 0.5rem 0rem",
                    }
                  : {
                      background: LightColors.bgsecondarycolorlight,
                      padding: "1rem 0rem 0.5rem 0rem",
                    }
              }
            >
              <div className={style.Postprofile}></div>

              <Row className="d-flex justify-content-center">
                <span className="d-flex w-auto align-items-center flex-column gap-3">
                  <FontAwesomeIcon
                    icon={faDesktop}
                    // style={{

                    // }}
                    style={
                      darkmode
                        ? {
                            color: DarkColors.fonttextcolordark,
                            fontSize: "3rem",
                          }
                        : {
                            color: LightColors.fonttextcolorlight,
                            fontSize: "3rem",
                          }
                    }
                  />
                  <p
                    className="m-0"
                    // style={{

                    // }}
                    style={
                      darkmode
                        ? {
                            color: DarkColors.fonttextcolordark,
                            fontWeight: "700",
                          }
                        : {
                            color: LightColors.fonttextcolorlight,
                            fontWeight: "700",
                          }
                    }
                  >
                    No Shared Post Available
                  </p>
                </span>
              </Row>
              <Row className="mt-2" sm="6"></Row>
            </div>
          ) : (
            ""
          )}
        </Container>
      </div>
    </>
  );
};

export default SharedProfile;
