import React from "react";
import cup from "../../../../assets/AchievementsMedals/Cup.png";
import Planet from "../../../../assets/AchievementsMedals/Planet.png";
import Skill from "../../../../assets/AchievementsMedals/Skill.png";
import Puzzle from "../../../../assets/AchievementsMedals/Puzzle.png";
import Reading from "../../../../assets/AchievementsMedals/Reading Time.png";
import { Container, Col } from "react-bootstrap";
import style from "./profilemid.module.css";
import { Swiper, SwiperSlide } from "swiper/react";
import breakpoints from "../../../../Utils/AchivementBreakpoints";
import "swiper/css";
import { useState } from "react";
import { DarkContext } from "../../../../Context/DarkContext";
import { useContext } from "react";
import { useEffect } from "react";
import { DarkColors, LightColors } from "../../../../Utils/Colors";
import { useProfileDataQuery } from "../../../../Redux/Profile/Profile";

const medals = [
  cup,
  Planet,
  Skill,
  Puzzle,
  Reading,
  cup,
  Planet,
  cup,
  Planet,
  Skill,
  Puzzle,
  Reading,
  cup,
  Planet,
];

function ProfileMid({ setEditProfile }) {
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);

  const userData = JSON.parse(localStorage.getItem("user"));
  const role = userData.user.role?.[0];
  const id = userData.user._id;

  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  const profileData = useProfileDataQuery(id, {
    skip: !id,
  });

  const name = JSON.parse(localStorage.getItem("user"));
  return (
    <Container
      className={style.ProfileWrapper}
      style={
        darkmode
          ? {
              background: DarkColors.bgsecondarycolordark,
              position: "relative",
            }
          : {
              background: LightColors.bgsecondarycolorlight,
              position: "relative",
            }
      }
    >
      <p className={style.editProfileBtn} onClick={() => setEditProfile(true)}>
        Edit Profile
      </p>
      <img
        src={name?.user?.profileImg}
        className={style.ProfileImg}
        alt={name?.user?.profileImg}
      />
      <div className={style.ProfileNames}>
        <h3
          style={
            darkmode
              ? { color: DarkColors.headingcolor }
              : { color: LightColors.headingcolor }
          }
        >
          {name?.user?.username}
        </h3>
        <p>Member Since {name?.user?.dob}</p>
      </div>
      <div className={style.ProfileDetail}>
        {role !== "Student" ? (
          <span style={darkmode ? { background: "#4d4a4a" } : {}}>
            <p>Students</p>
            <h3>
              {profileData?.isLoading ? (
                <p style={{ fontSize: 15 }}>Loading...</p>
              ) : (
                profileData?.data?.students
              )}
            </h3>
          </span>
        ) : null}
        <span style={darkmode ? { background: "#4d4a4a" } : {}}>
          <p>Courses</p>
          <h3>
            {profileData?.isLoading ? (
              <p style={{ fontSize: 15 }}>Loading...</p>
            ) : (
              profileData?.data?.courses
            )}
          </h3>
        </span>
        <span style={darkmode ? { background: "#4d4a4a" } : {}}>
          <p>Posts</p>
          <h3>
            {profileData?.isLoading ? (
              <p style={{ fontSize: 15 }}>Loading...</p>
            ) : (
              profileData?.data?.posts
            )}
          </h3>
        </span>
        <span style={darkmode ? { background: "#4d4a4a" } : {}}>
          <p>Events</p>
          <h3>
            {profileData?.isLoading ? (
              <p style={{ fontSize: 15 }}>Loading...</p>
            ) : (
              profileData?.data?.events
            )}
          </h3>
        </span>
      </div>
      <div className={style.achievements}>
        <Swiper
          spaceBetween={3}
          slidesPerView={8}
          className={style.achievementsSwiper}
          breakpoints={breakpoints}
          style={{ marginTop: "1.5rem", width: "33rem", overflow: "hidden" }}
        >
          {medals.map((items, index) => (
            <SwiperSlide key={index + 1}>
              <Col key={index + 1}>
                <img src={items} alt={items} key={index + 1} />
              </Col>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
      <div className={style.bio}>
        <h3
          style={
            darkmode
              ? { color: DarkColors.headingcolor, fontWeight: "700" }
              : { color: LightColors.headingcolor, fontWeight: "700" }
          }
        >
          Bio
        </h3>
        <span style={darkmode ? { background: "#4d4a4a" } : {}}>
          <p className="m-0 w-100">{name?.user?.bio}</p>
        </span>
      </div>
    </Container>
  );
}

export default ProfileMid;
