import React, { useState } from "react";
import style from "./homecomments.module.css";
import { Container, Col, Row } from "react-bootstrap";
import { DarkColors, LightColors } from "../../../../Utils/Colors";
import { DarkContext } from "../../../../Context/DarkContext";
import { useContext } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useSinglePostQuery } from "../../../../Redux/GlobalSlices/Global";
import { useEffect } from "react";
import { usePostCommentMutation } from "../../../../Redux/GlobalSlices/Global";
import { Swiper, SwiperSlide } from "swiper/react";
import HomeReplies from "./HomeReplies";
import DeletePopup from "../../../../components/DeletePopup/DeletePopup";
import { useSinglePostCommentQuery } from "../../../../Redux/Post/Post";
import { DefaultPlayer as Video } from "react-html5video";
import "react-html5video/dist/styles.css";
import { NotificationAlert } from "../../../../components/NotificationAlert/NotificationAlert";

const HomecommentsMid = () => {
  const [isDeleteComment, setIsDeleteComment] = useState(false);
  const [darkmode, setDarkMode] = useState();
  const navigate = useNavigate();
  const { id } = useParams();
  const userData = JSON.parse(localStorage.getItem("user"));
  const singlePost = useSinglePostQuery(id);
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);
  const singlePostComment = singlePost?.data;
  const PostComment = useSinglePostCommentQuery(id, { skip: !id });
  const [postComment] = usePostCommentMutation();
  const userID = userData.user._id;
  const [comments, setComments] = useState("");

  const commentOnPost = async () => {
    try {
      const res = await postComment({
        postId: id,
        userID: userID,
        comments,
      });
      if (!res.error) {
        setComments("");
        PostComment.refetch();
        NotificationAlert("Comment Post Successfully", "success");
      } else {
        NotificationAlert("Error While Posting Comment");
      }
    } catch (error) {
      NotificationAlert("Error While Posting Comment");
    }
  };

  const breakpoints = {
    320: {
      slidesPerView: 1,
      spaceBetween: 10,
    },
    480: {
      slidesPerView: 1,
      spaceBetween: 20,
    },
    768: {
      slidesPerView: 1,
      spaceBetween: 30,
    },
    1024: {
      slidesPerView: 1,
      spaceBetween: 20,
    },
  };

  return (
    <>
      <Container className={style.HomeFeedwrapper}>
        <div
          className={style.homefeedmain}
          style={
            darkmode
              ? { background: DarkColors.bgsecondarycolordark }
              : { background: LightColors.bgsecondarycolorlight }
          }
        >
          <span>
            <button
              className={`${style.commentbackBTN} w-auto`}
              onClick={() => navigate("/")}
              style={{
                //   width: "fit-content",
                boxShadow: "none",
                margin: "0rem 0rem 1rem 0rem",
              }}
            >
              BACK
            </button>
          </span>
          <Row md="9" className={style.Postprofile}>
            <Col xs="1" className="d-flex justify-content-center p-0">
              <img
                src={singlePostComment?.author?.profileImg}
                className={style.profilePic}
                alt={singlePostComment?.author?.profileImg}
              />
            </Col>
            <Col xs="7" className="p-0 d-flex flex-column align-items-start">
              <p
                className={`${style.HomefeedDesc} pb-1 m-0`}
                style={
                  darkmode
                    ? { color: DarkColors.btntextcolordark }
                    : { color: LightColors.headingcolor }
                }
              >
                {singlePostComment?.author?.username}
              </p>
            </Col>
          </Row>
          {singlePostComment?.imageUrls.length !== 0 &&
          !singlePostComment?.videoUrls ? (
            <>
              <Row>
                <p
                  className="mt-3 mb-4"
                  // style={{

                  // }}
                  style={
                    darkmode
                      ? {
                          color: DarkColors.fonttextcolordark,
                          paddingLeft: "1.5rem",
                        }
                      : {
                          color: LightColors.fonttextcolorlight,
                          paddingLeft: "1.5rem",
                        }
                  }
                >
                  {singlePostComment?.content}
                </p>
              </Row>
              <Row className="justify-content-center w-100">
                <Swiper breakpoints={breakpoints}>
                  {singlePostComment?.imageUrls?.map((img, index) => (
                    <Row key={index}>
                      <SwiperSlide>
                        <div
                          style={{
                            height: "40rem",
                            width: "100%",
                            objectFit: "cover",
                          }}
                        >
                          <img
                            alt="home page"
                            style={{ height: "100%", width: "100%" }}
                            src={img}
                            className="py-1"
                          />
                        </div>
                      </SwiperSlide>
                    </Row>
                  ))}
                </Swiper>
              </Row>
            </>
          ) : singlePostComment?.videoUrls &&
            singlePostComment?.imageUrls.length === 0 ? (
            <>
              <Row>
                <p
                  className="mt-3 mb-4"
                  // style={{

                  // }}
                  style={
                    darkmode
                      ? {
                          color: DarkColors.fonttextcolordark,
                          paddingLeft: "1.5rem",
                        }
                      : {
                          color: LightColors.fonttextcolorlight,
                          paddingLeft: "1.5rem",
                        }
                  }
                >
                  {singlePostComment?.content}
                </p>
              </Row>
              <Row className="justify-content-center w-100">
                <Video
                  // muted
                  controls={[
                    "PlayPause",
                    "Seek",
                    "Time",
                    "Volume",
                    "Fullscreen",
                  ]}
                  style={{
                    height: "30rem",
                  }}
                >
                  <source src={singlePostComment.videoUrls} type="video/mp4" />
                  <track
                    label="English"
                    kind="subtitles"
                    srcLang="en"
                    src={singlePostComment.videoUrls}
                    default
                  />
                </Video>
              </Row>
            </>
          ) : (
            <Row>
              <p
                className="mt-3 mb-4"
                // style={{

                // }}
                style={
                  darkmode
                    ? {
                        color: DarkColors.fonttextcolordark,
                        paddingLeft: "1.5rem",
                      }
                    : {
                        color: LightColors.fonttextcolorlight,
                        paddingLeft: "1.5rem",
                      }
                }
              >
                {singlePostComment?.content}
              </p>
            </Row>
          )}
          <div
            className={style.line}
            style={{
              width: "100%",
              height: "1px",
              backgroundColor: "grey",
              margin: "1rem 0rem",
            }}
          ></div>

          {/**************** Comments ************/}

          <div className="d-flex gap-2 align-items-center">
            <div className="d-flex justify-content-center p-0">
              <img
                src={userData.user.profileImg}
                style={{
                  width: "3rem",
                  height: "3rem",
                  borderRadius: "50%",
                }}
                alt={userData.user.profileImg}
                className={style.commentsProfileImg}
              />
            </div>
            <div
              className={`${style.commentInput} d-flex align-items-center px-1`}
            >
              <input
                type="text"
                value={comments}
                name="comments"
                onChange={(e) => setComments(e.target.value)}
                placeholder="Comments..."
                // className={style.commentInput}
                style={
                  darkmode
                    ? {
                        width: "100%",
                        outline: "none",
                        border: "1px solid grey",
                        padding: "0.5rem 0rem 0.5rem 1rem",
                        borderRadius: "10px",
                        background: "transparent",
                      }
                    : {
                        width: "100%",
                        outline: "none",
                        border: "1px solid grey",
                        padding: "0.5rem 0rem 0.5rem 1rem",
                        borderRadius: "10px",
                      }
                }
                className={style.commentInputField}
              />
              <button
                style={{
                  boxShadow: "none",
                }}
                onClick={commentOnPost}
                className={style.commentInputBtn}
              >
                Post
              </button>
            </div>
          </div>
          <>
            {PostComment?.data?.map((cur, index) => (
              <React.Fragment key={index}>
                <div className="d-flex gap-3" key={cur._id}>
                  <div className="d-flex justify-content-center p-0">
                    <img
                      src={cur.profileImg}
                      style={{
                        width: "3rem",
                        height: "3rem",
                        borderRadius: "50%",
                      }}
                      alt={cur.profileImg}
                      className={style.commentsProfileImg}
                    />
                  </div>
                  <div
                    className="w-100"
                    style={{
                      position: "relative",
                    }}
                  >
                    {/* {cur.userID === userID ? (
                      <FontAwesomeIcon
                        icon={faTrash}
                        style={{
                          position: "absolute",
                          right: "3rem",
                          color: "rgb(160, 152, 174)",
                          cursor: "pointer",
                        }}
                        onClick={() => getCommentID(cur._id)}
                      />
                    ) : null} */}
                    <p
                      className={`${style.HomefeedDesc} pb-1 m-0`}
                      style={
                        darkmode
                          ? { color: DarkColors.headingcolor }
                          : { color: LightColors.headingcolor }
                      }
                    >
                      {cur.username}
                    </p>
                    <p
                      style={
                        darkmode
                          ? {
                              color: DarkColors.fonttextcolordark,
                              width: "80%",
                              wordWrap: "break-word",
                            }
                          : {
                              color: LightColors.fonttextcolorlight,
                              width: "80%",
                              wordWrap: "break-word",
                            }
                      }
                      className={style.commentPara}
                    >
                      {cur.comments}
                    </p>
                  </div>
                  {isDeleteComment && (
                    <div className={style.modalDiv}>
                      <span className={style.modalSpan}>
                        <DeletePopup
                          setDeletePopup={setIsDeleteComment}
                          commentID={cur._id}
                          postId={id}
                        />
                      </span>
                    </div>
                  )}
                </div>
                {/* The following code is for the reply section */}
                <HomeReplies
                  id={id}
                  userID={userID}
                  commentID={cur._id}
                  cur={cur}
                  PostComment={PostComment}
                  commentUSerID={cur.userID}
                />
              </React.Fragment>
            ))}
          </>
        </div>
      </Container>
    </>
  );
};

export default HomecommentsMid;
// isReply && <SubComments cur={cur} darkmode={darkmode} />
