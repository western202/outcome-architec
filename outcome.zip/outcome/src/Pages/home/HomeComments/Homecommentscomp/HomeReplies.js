import React from "react";
import style from "./homecomments.module.css";
import { useState } from "react";
import { DarkContext } from "../../../../Context/DarkContext";
import { useContext } from "react";
import { useEffect } from "react";
import { DarkColors, LightColors } from "../../../../Utils/Colors";
import { useReplyCommentMutation } from "../../../../Redux/Post/Post";
import DeletePopup from "../../../../components/DeletePopup/DeletePopup";
import {
  useDeleteCommentMutation,
  useDeleteRepliesMutation,
} from "../../../../Redux/Post/Post";
import { NotificationAlert } from "../../../../components/NotificationAlert/NotificationAlert";

const HomeReplies = ({
  id,
  userID,
  commentID,
  cur,
  PostComment,
  commentUSerID,
}) => {
  const [darkmode, setDarkMode] = useState();
  const [isDeleteComment, setIsDeleteComment] = useState(false);
  const [isDeleteReply, setIsDeleteReply] = useState(false);
  const [commentReply, setCommentReply] = useState("");
  const [replyID, setReplyID] = useState("");
  const userData = JSON.parse(localStorage.getItem("user"));
  const [isReply, setIsReply] = useState(false);
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  const [deleteComment] = useDeleteCommentMutation();
  const [deleteReply] = useDeleteRepliesMutation();
  const handleDeleteComment = async () => {
    try {
      // eslint-disable-next-line
      const res = await deleteComment({
        postId: id,
        userId: userID,
        commentId: commentID,
      });
      if (!res.error) {
        NotificationAlert("Comment Deleted Successfully", "success");

        PostComment.refetch();
      } else {
        NotificationAlert("Error While Deleting Comment");
      }
    } catch (error) {
      NotificationAlert("Error While Deleting Comment");
    }
  };
  const handleDeleteReply = async () => {
    try {
      const res = await deleteReply({
        userID,
        postID: id,
        commentID,
        replyID,
      });
      if (!res.error) {
        NotificationAlert("Reply Deleted Successfully", "success");
      } else {
        NotificationAlert("Error While Deleting Reply");
      }
    } catch (error) {
      NotificationAlert("Error While Deleting Reply");
    }
  };
  const [reply] = useReplyCommentMutation();

  const replyOnPost = async () => {
    try {
      const res = await reply({
        postId: id,
        userID: userID,
        commentId: commentID,
        reply: commentReply,
      });
      if (!res.error) {
        NotificationAlert("Reply Post Successfully", "success");
        setIsReply(false);
        commentReply("");
        PostComment.refetch();
      } else {
        NotificationAlert("Error While Posting Reply");
      }
    } catch (error) {}
  };

  const getReplyID = (id) => {
    setReplyID(id);
    setIsDeleteReply(true);
  };

  return (
    <>
      <span className="d-flex gap-3">
        <p
          style={
            darkmode
              ? {
                  color: DarkColors.headingcolor,
                  fontWeight: isReply ? "bolder" : "",
                  cursor: "pointer",
                }
              : {
                  color: LightColors.headingcolor,
                  fontWeight: isReply ? "bolder" : "",
                  cursor: "pointer",
                }
          }
          onClick={() => setIsReply(!isReply)}
          className={style.commentReplybtn}
        >
          Reply
        </p>
        {commentUSerID === userID ? (
          <p
            style={
              darkmode
                ? {
                    color: "#e94a4a",
                    //   fontWeight: isReply ? "bolder" : "",
                    cursor: "pointer",
                  }
                : {
                    color: "#e94a4a",
                    //   fontWeight: isReply ? "bolder" : "",
                    cursor: "pointer",
                  }
            }
            onClick={() => setIsDeleteComment(true)}
            className={style.commentReplybtn}
          >
            Delete
          </p>
        ) : (
          ""
        )}
        {isDeleteComment && (
          <DeletePopup
            deleteFun={handleDeleteComment}
            setDeletePopup={setIsDeleteComment}
          />
        )}
      </span>
      {isReply && (
        <>
          <div
            className="d-flex flex-column gap-3"
            style={{
              paddingLeft: "3rem",
            }}
          >
            <div className="d-flex gap-3">
              <div className="d-flex justify-content-center p-0">
                <img
                  src={userData?.user?.profileImg}
                  style={{
                    width: "3rem",
                    height: "3rem",
                    borderRadius: "50%",
                  }}
                  alt={userData?.user?.profileImg}
                  className={style.commentsProfileImg}
                />
              </div>
              <div
                className={`${style.commentInput} d-flex align-items-center px-1`}
              >
                <input
                  type="text"
                  placeholder="Reply..."
                  style={
                    darkmode
                      ? {
                          width: "100%",
                          outline: "none",
                          border: "1px solid grey",
                          padding: "0.5rem 0rem 0.5rem 1rem",
                          borderRadius: "10px",
                          background: "transparent",
                        }
                      : {
                          width: "100%",
                          outline: "none",
                          border: "1px solid grey",
                          padding: "0.5rem 0rem 0.5rem 1rem",
                          borderRadius: "10px",
                        }
                  }
                  className={style.commentInputField}
                  onChange={(e) => setCommentReply(e.target.value)}
                />
                {commentReply !== "" ? (
                  <button
                    style={{
                      boxShadow: "none",
                    }}
                    className={style.commentInputBtn}
                    onClick={replyOnPost}
                  >
                    Post
                  </button>
                ) : (
                  <button
                    style={{
                      boxShadow: "none",
                    }}
                    className={style.commentInputBtn}
                  >
                    Post
                  </button>
                )}
              </div>
            </div>
          </div>
        </>
      )}
      <div
        className={`${style.repliesWrapper} d-flex flex-column gap-3`}
        style={{
          paddingLeft: "3rem",
        }}
      >
        {cur.replies.map((item) => (
          <div className="d-flex flex-column " key={item._id}>
            <div
              className="d-flex gap-3"
              style={{
                paddingLeft: "1rem",
                borderLeft: "2px solid rgb(160, 152, 174)",
              }}
            >
              <div className="d-flex justify-content-center p-0">
                <img
                  src={item?.profileImg}
                  style={{
                    width: "3rem",
                    height: "3rem",
                    borderRadius: "50%",
                  }}
                  alt={item?.profileImg}
                  className={style.commentsProfileImg}
                />
              </div>
              <div className="w-100">
                <p
                  className={`${style.HomefeedDesc} pb-1 m-0`}
                  style={
                    darkmode
                      ? { color: DarkColors.headingcolor }
                      : { color: LightColors.headingcolor }
                  }
                >
                  {item?.username}
                </p>
                <p
                  style={
                    darkmode
                      ? {
                          color: DarkColors.fonttextcolordark,
                          width: "80%",
                          wordWrap: "break-word",
                        }
                      : {
                          color: LightColors.fonttextcolorlight,
                          width: "80%",
                          wordWrap: "break-word",
                        }
                  }
                  className={style.commentPara}
                >
                  {item?.comments}
                </p>
              </div>
            </div>
            {commentUSerID === userID ? (
              <p
                style={{ color: "#e94a4a", margin: "0rem", cursor: "pointer" }}
                onClick={() => getReplyID(item?._id)}
              >
                Delete
              </p>
            ) : (
              ""
            )}
            {isDeleteReply && (
              <DeletePopup
                setDeletePopup={setIsDeleteReply}
                deleteFun={handleDeleteReply}
              />
            )}
          </div>
        ))}
      </div>
    </>
  );
};

export default HomeReplies;
