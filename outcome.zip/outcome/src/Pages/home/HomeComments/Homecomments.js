import React, { useState } from "react";
// import style from "./homecomments.module.css";
import { Container, Col, Row } from "react-bootstrap";
import { DarkColors, LightColors } from "../../../Utils/Colors";
import { DarkContext } from "../../../Context/DarkContext";
import { useContext } from "react";
import Header from "../../../components/Others/Header";
import HomeLeft from "../../../components/HomeComp/HomeLeft";
import HomecommentsMid from "./Homecommentscomp/HomecommentsMid";
import HomeRight from "../../../components/HomeComp/HomeRight";
import { useEffect } from "react";

const Homecomments = () => {
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);
  return (
    <>
      <Container
        fluid
        style={
          darkmode
            ? {
                padding: "0rem",
                background: DarkColors.bgcolordark,
                height: "100vh",
                overflow: "hidden",
              }
            : {
                padding: "0rem",
                background: LightColors.bgcolorlight,
                height: "100vh",
                overflow: "hidden",
              }
        }
      >
        <Header pageName={"Comments"} />
        <Row>
          <Col
            lg="3"
            style={
              darkmode
                ? {
                    borderTop: "1px solid black",
                    padding: "0rem",
                  }
                : {
                    backgroundColor: "white",
                    borderTop: "1px solid #0000001a",
                    padding: "0rem",
                  }
            }
          >
            <HomeLeft />
          </Col>
          <Col lg="6">
            <HomecommentsMid />
          </Col>
          <Col lg="3">
            <HomeRight />
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default Homecomments;
