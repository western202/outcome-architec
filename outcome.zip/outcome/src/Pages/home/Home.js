import React, { useEffect, useState } from "react";
import style from "./home.module.css";
import { Col, Container, Row } from "react-bootstrap";
import Header from "../../components/Others/Header";
import HomeLeft from "../../components/HomeComp/HomeLeft";
import HomeFeed from "../../components/HomeComp/HomeFeed";
import HomeRight from "../../components/HomeComp/HomeRight";
import { DarkContext } from "../../Context/DarkContext";
import { DarkColors, LightColors } from "../../Utils/Colors";
import { useContext } from "react";

function Home() {
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  return (
    <>
      <div
        className={style.homeWrapper}
        style={
          darkmode
            ? { background: DarkColors.bgcolordark }
            : { background: LightColors.bgcolorlight }
        }
      >
        <Header pageName={"News Feed"} />
        <Container fluid className="p-0">
          <Row>
            <Col
              lg="3"
              style={
                darkmode
                  ? {
                      borderTop: "1px solid black",
                      padding: "0rem",
                    }
                  : {
                      backgroundColor: "white",
                      borderTop: "1px solid #0000001a",
                      padding: "0rem",
                    }
              }
            >
              <HomeLeft />
            </Col>
            <Col lg="6">
              <HomeFeed />
            </Col>
            <Col lg="3" className={style.HomeRight}>
              <HomeRight />
            </Col>
          </Row>
        </Container>
      </div>
    </>
  );
}

export default Home;
