import React, { useEffect, useState } from "react";
import HomeLeft from "../../components/HomeComp/HomeLeft";
import Header from "../../components/Others/Header";
import { Col, Container, Row } from "react-bootstrap";
import style from "./dashboard.module.css";
import DashboardMid from "./dashboardComp/DashBoardMid/DashboardMid";
import DashBoardRight from "./dashboardComp/DashBoardRight/DashBoardRight";
import { DarkColors, LightColors } from "../../Utils/Colors";
import { DarkContext } from "../../Context/DarkContext";
import { useContext } from "react";

function DashBoard() {
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);

  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  // Frontend
  // useEffect(() => {
  //   socket.on("connect", () => {
  //     // Emit userConnected event with the user's ID
  //     socket.emit("userConnected", userData.user._id);
  //     socket.on("notificationEvent", (data) => {});
  //   });
  //   // eslint-disable-next-line
  // }, []);

  return (
    <>
      <div
        className={style.DashBoardWrapper}
        style={
          darkmode
            ? { background: DarkColors.bgcolordark }
            : { background: LightColors.bgcolorlight }
        }
      >
        <Header pageName={"Dashboard"} />
        <Container fluid className={`${style.dashboard} p-0`}>
          <Row>
            <Col
              lg="3"
              style={
                darkmode
                  ? {
                      borderTop: "1px solid black",
                      padding: "0rem",
                    }
                  : {
                      backgroundColor: "white",
                      borderTop: "1px solid #0000001a",
                      padding: "0rem",
                    }
              }
            >
              <HomeLeft />
            </Col>
            <Col lg="6">
              <DashboardMid />
            </Col>
            <Col lg="3" className={style.dashRight}>
              <DashBoardRight />
            </Col>
          </Row>
        </Container>
      </div>
    </>
  );
}

export default DashBoard;
