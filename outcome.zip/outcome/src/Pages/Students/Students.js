import React, { useState } from "react";
import HomeLeft from "../../components/HomeComp/HomeLeft";
import Header from "../../components/Others/Header";
import { Col, Container, Row } from "react-bootstrap";
import Search from "../../components/Search/Search";
import style from "./students.module.css";
import StudentMid from "./studentComp/StudentMid";
import AddInstructorModal from "../../components/Modal/AddInstructorModal";
import { DarkContext } from "../../Context/DarkContext";
import { useContext } from "react";
import { useEffect } from "react";
import { DarkColors, LightColors } from "../../Utils/Colors";

function Students() {
  const [addStudnt, setAddStudent] = useState(false);
  const [isSearchStudent, setIsSearchStudent] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  const userData = JSON.parse(localStorage.getItem("user"));
  const student = userData.user.role?.[0];

  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  const closeModal = () => {
    setIsOpen(false);
  };

  return (
    <>
      <>
        <div
          className={style.StudentsWrapper}
          style={
            darkmode
              ? { background: DarkColors.bgcolordark }
              : { background: LightColors.bgcolorlight }
          }
        >
          <Header pageName={"Learners"} />
          <Container fluid style={{ padding: "0rem" }}>
            <Row>
              <Col
                lg="3"
                style={
                  darkmode
                    ? {
                        borderTop: "1px solid black",
                        padding: "0rem",
                      }
                    : {
                        backgroundColor: "white",
                        borderTop: "1px solid #0000001a",
                        padding: "0rem",
                      }
                }
              >
                <HomeLeft />
              </Col>
              <Col
                lg="9"
                style={{
                  height: "100vh",
                  overflowY: "scroll",
                  paddingBottom: "8rem",
                }}
                className={style.studentMidCol}
              >
                <Row
                  className={`${style.studentInputField} d-flex justify-content-center align-items-center mt-5 w-100 gap-1 align-items-center`}
                >
                  <Search setIsSearch={setIsSearchStudent} />
                  {student === "Instructor" && (
                    <button
                      className={`${style.StudentModalBtn}`}
                      onClick={() => setAddStudent(true)}
                    >
                      Add Student
                    </button>
                  )}
                </Row>
                <StudentMid isSearchStudent={isSearchStudent} />
              </Col>
            </Row>
            {isOpen && (
              <div className={style.modalDiv}>
                <span className={style.modalSpan}>
                  <AddInstructorModal
                    closeModal={closeModal}
                    setIsOpen={setIsOpen}
                    title="Invite Students"
                  />
                </span>
              </div>
            )}
          </Container>
          {addStudnt && (
            <div className={style.modalDiv}>
              <span className={style.modalSpan}>
                <AddInstructorModal
                  setAddStudent={setAddStudent}
                  addStudnt={addStudnt}
                  title={"Add Student"}
                />{" "}
              </span>
            </div>
          )}
        </div>
      </>
    </>
  );
}

export default Students;
