import React, { useContext, useEffect, useState } from "react";
import style from "./studentMid.module.css";
import { Col, Row } from "react-bootstrap";
import {
  useAllStudentsQuery,
  useDeleteStudentsMutation,
} from "../../../Redux/StudentSlices/Student";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faEnvelope,
  faCity,
  faPhoneVolume,
} from "@fortawesome/free-solid-svg-icons";
import ListLoader from "../../../components/Loader/ListLoader";
import { DarkContext } from "../../../Context/DarkContext";
import { DarkColors, LightColors } from "../../../Utils/Colors";
import DeletePopup from "../../../components/DeletePopup/DeletePopup";
import { useAllStudentQuery } from "../../../Redux/GlobalSlices/Global";
import { NotificationAlert } from "../../../components/NotificationAlert/NotificationAlert";

function StudentMid({ isSearchStudent }) {
  const [studentID, setStudentID] = useState("");
  const [deleteStudentModal, setDeleteStudentModal] = useState(false);
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  const userData = JSON.parse(localStorage.getItem("user"));
  const role = userData.user.role?.[0];
  const id = userData.user._id;
  const allStudents = useAllStudentsQuery(id);
  const adminAllStudentsAPI = useAllStudentQuery();
  const adminAllStudents = adminAllStudentsAPI?.data?.students;
  const navigate = useNavigate();

  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);
  const getStudentId = (id) => {
    setStudentID(id);
    setDeleteStudentModal(true);
  };

  const allStudentLoading = allStudents.isLoading;

  const [deleteStudent] = useDeleteStudentsMutation();

  const handleDeleteStudent = async () => {
    try {
      const res = await deleteStudent({
        id: studentID,
      });
      if (!res.error) {
        NotificationAlert("Student deleted successfully", "success");
      } else {
        NotificationAlert("Error While Deleting Student");
      }
    } catch (error) {
      NotificationAlert("Error While Deleting Student");
    }
  };

  return (
    <>
      <Row
        className="d-flex justify-content-center mt-5"
        style={{ gap: "2rem" }}
      >
        {role === "Instructor" ? (
          allStudentLoading ? (
            <ListLoader />
          ) : (
            allStudents?.data?.students
              ?.filter((item) =>
                item.username
                  .toLowerCase()
                  .includes(isSearchStudent.toLowerCase())
              )
              .map((card, index) => (
                <Col
                  lg="6"
                  key={index + 1}
                  className={style.main}
                  style={
                    darkmode
                      ? { background: DarkColors.bgsecondarycolordark }
                      : { background: LightColors.bgsecondarycolorlight }
                  }
                >
                  <div className={`${style.card} p-3`}>
                    <div
                      className={`${style.imgRow} d-flex justify-content-center`}
                    >
                      <img src={card?.profileImg} alt={card?.profileImg} />
                    </div>
                    <Row
                      className="d-flex justify-content-center mt-2"
                      style={
                        darkmode
                          ? {
                              color: DarkColors.fonttextcolordark,
                              fontWeight: "bold",
                            }
                          : {
                              color: LightColors.fonttextcolorlight,
                              fontWeight: "bold",
                            }
                      }
                    >
                      {card?.username}
                    </Row>
                    <Row className="d-flex justify-content-center mt-2">
                      <p className="w-auto" style={{ color: "black" }}>
                        5.0⭐
                      </p>
                      <p
                        className="w-auto"
                        style={{ color: "#A098AE", borderLeft: "1px solid" }}
                      >
                        Review (1k)
                      </p>
                    </Row>
                    <Row
                      className={`d-flex gap-2 justify-content-center align-items-center mt-1 mb-2 ${style.professionRow}`}
                    >
                      <Col
                        className={`${style.profession} w-auto gap-2 d-flex justify-content-center align-items-center`}
                        style={
                          darkmode
                            ? { color: DarkColors.fonttextcolordark }
                            : { color: LightColors.fonttextcolorlight }
                        }
                      >
                        <FontAwesomeIcon icon={faEnvelope} />
                        {card.email}
                      </Col>
                      <div
                        className="d-flex gap-2 p-0"
                        style={
                          darkmode
                            ? { color: DarkColors.fonttextcolordark }
                            : { color: LightColors.fonttextcolorlight }
                        }
                      >
                        <Col
                          className={`${style.profession} w-auto gap-2 d-flex justify-content-center align-items-center`}
                        >
                          <FontAwesomeIcon icon={faCity} />
                          {card.phone}
                        </Col>
                        <Col
                          className={`${style.profession} w-auto gap-2 d-flex justify-content-center align-items-center`}
                        >
                          <FontAwesomeIcon icon={faPhoneVolume} />
                          {card.city}
                        </Col>
                      </div>
                    </Row>
                    <Row
                      className="d-flex gap-2"
                      style={{ marginBottom: "2rem", marginTop: "2rem" }}
                    >
                      <Col className={style.achievement}>
                        <p> Achievement</p>
                        <p>100</p>
                      </Col>
                      <Col className={`${style.achievement} `}>
                        <p>Certificate</p>
                        <p>50</p>
                      </Col>
                    </Row>
                    <Row className={style.instructorAssign}>
                      <button
                        onClick={() => navigate(`/studentprofile/${card._id}`)}
                      >
                        View Profile
                      </button>
                      <button onClick={() => getStudentId(card._id)}>
                        Delete Student
                      </button>
                    </Row>
                  </div>
                </Col>
              ))
          )
        ) : allStudentLoading ? (
          <ListLoader />
        ) : (
          adminAllStudents
            ?.filter((item) =>
              item.username
                .toLowerCase()
                .includes(isSearchStudent.toLowerCase())
            )
            .map((card, index) => (
              <Col
                lg="6"
                key={index + 1}
                className={style.main}
                style={
                  darkmode
                    ? { background: DarkColors.bgsecondarycolordark }
                    : { background: LightColors.bgsecondarycolorlight }
                }
              >
                <div className={`${style.card} p-3`}>
                  <div
                    className={`${style.imgRow} d-flex justify-content-center`}
                  >
                    <img src={card?.profileImg} alt={card?.profileImg} />
                  </div>
                  <Row
                    className="d-flex justify-content-center mt-2"
                    style={
                      darkmode
                        ? {
                            color: DarkColors.fonttextcolordark,
                            fontWeight: "bold",
                          }
                        : {
                            color: LightColors.fonttextcolorlight,
                            fontWeight: "bold",
                          }
                    }
                  >
                    {card?.username}
                  </Row>
                  <Row className="d-flex justify-content-center mt-2">
                    <p className="w-auto" style={{ color: "black" }}>
                      5.0⭐
                    </p>
                    <p
                      className="w-auto"
                      style={{ color: "#A098AE", borderLeft: "1px solid" }}
                    >
                      Review (1k)
                    </p>
                  </Row>
                  <Row
                    className={`d-flex gap-2 justify-content-center align-items-center mt-1 mb-2 ${style.professionRow}`}
                  >
                    <Col
                      className={`${style.profession} w-auto gap-2 d-flex justify-content-center align-items-center`}
                      style={
                        darkmode
                          ? { color: DarkColors.fonttextcolordark }
                          : { color: LightColors.fonttextcolorlight }
                      }
                    >
                      <FontAwesomeIcon icon={faEnvelope} />
                      {card.email}
                    </Col>
                    <div
                      className="d-flex gap-2 p-0"
                      style={
                        darkmode
                          ? { color: DarkColors.fonttextcolordark }
                          : { color: LightColors.fonttextcolorlight }
                      }
                    >
                      <Col
                        className={`${style.profession} w-auto gap-2 d-flex justify-content-center align-items-center`}
                      >
                        <FontAwesomeIcon icon={faCity} />
                        {card.phone}
                      </Col>
                      <Col
                        className={`${style.profession} w-auto gap-2 d-flex justify-content-center align-items-center`}
                      >
                        <FontAwesomeIcon icon={faPhoneVolume} />
                        {card.city}
                      </Col>
                    </div>
                  </Row>
                  <Row
                    className="d-flex gap-2"
                    style={{ marginBottom: "2rem", marginTop: "2rem" }}
                  >
                    <Col className={style.achievement}>
                      <p> Achievement</p>
                      <p>100</p>
                    </Col>
                    <Col className={`${style.achievement} `}>
                      <p>Certificate</p>
                      <p>50</p>
                    </Col>
                  </Row>
                  <Row className={style.allStudentsinstructorAssign}>
                    <button
                      onClick={() => navigate(`/studentprofile/${card._id}`)}
                    >
                      View Profile
                    </button>
                    {role === "Instructor" && (
                      <button onClick={() => getStudentId(card._id)}>
                        Delete Student
                      </button>
                    )}
                  </Row>
                </div>
              </Col>
            ))
        )}
      </Row>
      {deleteStudentModal && (
        <DeletePopup
          deleteFun={handleDeleteStudent}
          setDeletePopup={setDeleteStudentModal}
        />
      )}
    </>
  );
}

export default StudentMid;
