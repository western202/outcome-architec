import React from "react";
import cup from "../../../../assets/AchievementsMedals/Cup.png";
import Planet from "../../../../assets/AchievementsMedals/Planet.png";
import Skill from "../../../../assets/AchievementsMedals/Skill.png";
import Puzzle from "../../../../assets/AchievementsMedals/Puzzle.png";
import Reading from "../../../../assets/AchievementsMedals/Reading Time.png";
import { Col, Container, Row } from "react-bootstrap";
import style from "./studenprofilemid.module.css";
import { Swiper, SwiperSlide } from "swiper/react";
import breakpoints from "../../../../Utils/AchivementBreakpoints";
import "swiper/css";
import { useParams } from "react-router-dom";
import { useState } from "react";
import { DarkContext } from "../../../../Context/DarkContext";
import { useContext } from "react";
import { useEffect } from "react";
import { DarkColors, LightColors } from "../../../../Utils/Colors";
import { useStudentSingleProfileQuery } from "../../../../Redux/StudentSlices/Student";
import { useAllStudentQuery } from "../../../../Redux/GlobalSlices/Global";

const medals = [
  cup,
  Planet,
  Skill,
  Puzzle,
  Reading,
  cup,
  Planet,
  cup,
  Planet,
  Skill,
  Puzzle,
  Reading,
  cup,
  Planet,
];

function StudentProfileMid() {
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  const allStudents = useAllStudentQuery();
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);
  const { id } = useParams();
  const StudentProfileApi = useStudentSingleProfileQuery(id, { skip: !id });
  const studentProfile = StudentProfileApi?.data;
  return (
    <>
      <Container
        className={style.ProfileWrapper}
        style={
          darkmode
            ? {
                background: DarkColors.bgsecondarycolordark,
                position: "relative",
              }
            : {
                background: LightColors.bgsecondarycolorlight,
                position: "relative",
              }
        }
      >
        {/* <button
          style={{
            position: "absolute",
            top: "1rem",
            left: "1rem",
            boxShadow: "none",
          }}
          onClick={() => navigate("/students")}
        >
          Back
        </button> */}
        <img
          src={studentProfile?.profileImg}
          className={style.ProfileImg}
          alt={studentProfile?.profileImg}
        />
        <div className={style.ProfileNames}>
          <h3
            style={
              darkmode
                ? { color: DarkColors.headingcolor }
                : { color: LightColors.headingcolor }
            }
          >
            {studentProfile?.username}
            {/* DeAnna */}
          </h3>
          <p>Member Since 2020</p>
        </div>
        <div className={style.ProfileDetail}>
          <span style={darkmode ? { background: "#4d4a4a" } : {}}>
            <p>Students</p>
            <h3>{allStudents?.data?.students?.length}</h3>
          </span>
          <span style={darkmode ? { background: "#4d4a4a" } : {}}>
            <p>Hours</p>
            <h3>5600</h3>
          </span>
          <span style={darkmode ? { background: "#4d4a4a" } : {}}>
            <p>Hours</p>
            <h3>5600</h3>
          </span>
        </div>
        <div className={style.achievements}>
          <Swiper
            spaceBetween={3}
            slidesPerView={8}
            className={style.achievementsSwiper}
            breakpoints={breakpoints}
            style={{ marginTop: "1.5rem", width: "33rem", overflow: "hidden" }}
          >
            <Row className={style.span}>
              {medals.map((items, index) => (
                <SwiperSlide key={index}>
                  <Col key={index}>
                    <img src={items} alt={items} />
                  </Col>
                </SwiperSlide>
              ))}
            </Row>
          </Swiper>
        </div>
        <div className={style.bio}>
          <h3
            style={
              darkmode
                ? { color: DarkColors.headingcolor, fontWeight: "700" }
                : { color: LightColors.headingcolor, fontWeight: "700" }
            }
          >
            Bio
          </h3>
          <span style={darkmode ? { background: "#4d4a4a" } : {}}>
            <p style={{ width: "100%", wordWrap: "break-word", margin: "0" }}>
              {studentProfile?.bio}
            </p>
          </span>
        </div>
      </Container>
    </>
  );
}

export default StudentProfileMid;
