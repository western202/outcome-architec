import style from "./upcomingschedule.module.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCalendar, faClock } from "@fortawesome/free-solid-svg-icons";
import { useState } from "react";
import { DarkContext } from "../../../../../Context/DarkContext";
import { useContext } from "react";
import { useEffect } from "react";
import { DarkColors, LightColors } from "../../../../../Utils/Colors";
import { faPenToSquare, faTrash } from "@fortawesome/free-solid-svg-icons";
import {
  useDeleteInstructorEventMutation,
  useGetAllEventQuery,
  useGetInstructorEventQuery,
  useGetStudentEventQuery,
} from "../../../../../Redux/ScheduleEventSlice/ScheduleEvent";
import ListLoader from "../../../../../components/Loader/ListLoader";
import DeletePopup from "../../../../../components/DeletePopup/DeletePopup";
import UpdateEventModal from "../../../../../components/Modal/UpdateEventModal";
import { NotificationAlert } from "../../../../../components/NotificationAlert/NotificationAlert";

function UpcomingSchedule() {
  const [deletePopup, setDeletePopup] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [updateEvent, setUpdateEvent] = useState(false);
  const [eventId, setEventId] = useState("");
  const userData = JSON.parse(localStorage.getItem("user"));
  const allEvents = useGetAllEventQuery();
  const [deleteInstructorEvent] = useDeleteInstructorEventMutation();
  const instructorEvenets = useGetInstructorEventQuery(userData.user._id, {
    skip: !userData.user._id,
    pollingInterval: 1000,
  });
  const studentEvenets = useGetStudentEventQuery(userData.user.invitedByID, {
    skip: !userData.user.invitedByID,
    pollingInterval: 1000,
  });

  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
   console.log(allEvents?.isError, 'here is console', allEvents?.data);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);

  // delete instructor event.
  const handleDeleteModal = (id) => {
    setEventId(id);
    setDeletePopup(true);
  };

  const HandledeleteEvent = async () => {
    try {
      const res = await deleteInstructorEvent({
        instructorId: userData.user._id,
        eventId,
      });
      if (!res.error) {
        NotificationAlert("Event deleted successfully", "success");
      } else {
        NotificationAlert("Error While Deleting Event");
      }
    } catch (error) {
      NotificationAlert("Error While Deleting Event");
    }
  };

  // update instructor event.
  const HandleUpdateEvent = (event) => {
    setUpdateEvent(event);
    setShowModal(true);
  };

  return (
    <main>
      <div
        className="d-flex justify-content-between "
        style={{
          paddingLeft: "2rem",
          paddingRight: "2rem",
          alignItems: "baseline",
        }}
      >
        <span>
          <h3
            className="w-auto"
            style={
              darkmode
                ? {
                    color: DarkColors.headingcolor,
                    fontWeight: "700",
                    fontSize: "1.5vmax",
                  }
                : {
                    color: LightColors.headingcolor,
                    fontWeight: "700",
                    fontSize: "1.5vmax",
                  }
            }
          >
            Upcoming Schedule
          </h3>
          <p style={{ color: "#b1acac", fontSize: "0.9vmax" }}>
            Thursday, 10th April , 2021
          </p>
        </span>
        <span className={style.addSchedule}>View All</span>
      </div>
      {/* Events w.r.t Roles... */}

      {userData?.user?.role?.[0] === "Instructor" ? (
        instructorEvenets?.isError ? (
          <span className="text-danger">Something went wrong load events </span>
        ) : instructorEvenets.isLoading ? (
          <ListLoader />
        ) : (
          instructorEvenets?.data?.map((items, index) => (
            <div
              className={`${style.scheduleCard} d-flex justify-content-between gap-4 mt-4`}
              style={{
                padding: "1rem",
                borderLeft: `13px solid #374557`,
                borderRadius: "10px",
              }}
              key={index}
            >
              <div className="d-flex flex-column gap-2">
                <div className="d-flex">
                  <h5
                    style={
                      darkmode
                        ? {
                            color: DarkColors.headingcolor,
                            fontWeight: "700",
                          }
                        : {
                            color: LightColors.headingcolor,
                            fontWeight: "700",
                          }
                    }
                    className={style.scheduleJobs}
                  >
                    {items.title}
                  </h5>
                </div>

                <span className="d-flex align-items-center justify-centent-start gap-2">
                  <img
                    src={items.profileImg}
                    style={{
                      width: "2rem",
                      borderRadius: "7px",
                      height: "2rem",
                    }}
                    className={style.scheduleImg}
                    alt={items.img}
                  />
                  <p
                    className={`${style.scheduleNames} m-0`}
                    style={{ color: "#A098AE" }}
                  >
                    {items.username}
                  </p>
                </span>
              </div>
              <div
                className={`${style.scheduleRightSide} d-flex flex-column justify-content-end align-items-center gap-3`}
              >
                <div className="w-100 d-flex justify-content-end gap-2 mb-1">
                  <FontAwesomeIcon
                    onClick={() => HandleUpdateEvent(items)}
                    style={{
                      color: "#A098AE",
                      cursor: "pointer",
                    }}
                    icon={faPenToSquare}
                  />
                  <FontAwesomeIcon
                    onClick={() => handleDeleteModal(items._id)}
                    style={{
                      color: "#FC0500",
                      cursor: "pointer",
                    }}
                    icon={faTrash}
                  />
                </div>

                <div className=" d-flex justify-content-between">
                  <span className="d-flex align-items-center gap-1">
                    <FontAwesomeIcon
                      icon={faCalendar}
                      style={{
                        color: "#A098AE",
                      }}
                      className={style.scheduleSVG}
                    />
                    <p
                      className={`${style.scheduleTimes} m-0`}
                      style={{ color: "#A098AE" }}
                    >
                      {items.date}
                    </p>
                  </span>
                  <span className="d-flex align-items-center gap-1">
                    <FontAwesomeIcon
                      icon={faClock}
                      style={{
                        color: "#A098AE",
                      }}
                      className={style.scheduleSVG}
                    />
                    <p
                      style={{ color: "#A098AE" }}
                      className={`${style.scheduleTimes} m-0`}
                    >
                      {items.startTime} {items.endTime}
                    </p>
                  </span>
                </div>
              </div>
            </div>
          ))
        )
      ) : null}

      {userData?.user?.role?.[0] === "Admin" ? (
       allEvents.isLoading ? (
        <ListLoader />
      ) :
       allEvents?.isError ? (
          <span className="text-danger">Something went wrong load events </span>
        ) :  (
          allEvents?.data?.map((items, index) => (
            <div
              className={`${style.scheduleCard} d-flex justify-content-between gap-4 mt-4`}
              style={{
                padding: "1rem",
                borderLeft: `13px solid #374557`,
                borderRadius: "10px",
              }}
              key={index}
            >
              <div className="d-flex flex-column gap-2">
                <h5
                  style={
                    darkmode
                      ? {
                          color: DarkColors.headingcolor,
                          fontWeight: "700",
                        }
                      : {
                          color: LightColors.headingcolor,
                          fontWeight: "700",
                        }
                  }
                  className={style.scheduleJobs}
                >
                  {items.title}
                </h5>
                <span className="d-flex align-items-center justify-centent-start gap-2">
                  <img
                    src={items?.instructorID?.profileImg}
                    style={{
                      width: "2rem",
                      borderRadius: "7px",
                      height: "2rem",
                    }}
                    className={style.scheduleImg}
                    alt={items.img}
                  />
                  <p
                    className={`${style.scheduleNames} m-0`}
                    style={{ color: "#A098AE" }}
                  >
                    {items?.instructorID?.username}
                  </p>
                </span>
              </div>
              <div
                className={`${style.scheduleRightSide} d-flex justify-content-between align-items-center gap-3`}
              >
                <span className="d-flex align-items-center gap-1">
                  <FontAwesomeIcon
                    icon={faCalendar}
                    style={{
                      color: "#A098AE",
                    }}
                    className={style.scheduleSVG}
                  />
                  <p
                    className={`${style.scheduleTimes} m-0`}
                    style={{ color: "#A098AE" }}
                  >
                    {items.date}
                  </p>
                </span>
                <span className="d-flex align-items-center gap-1">
                  <FontAwesomeIcon
                    icon={faClock}
                    style={{
                      color: "#A098AE",
                    }}
                    className={style.scheduleSVG}
                  />
                  <p
                    style={{ color: "#A098AE" }}
                    className={`${style.scheduleTimes} m-0`}
                  >
                    {items.startTime} {items.endTime}
                  </p>
                </span>
              </div>
            </div>
          ))
        )
      ) : null}
      {userData?.user?.role?.[0] === "Student" ? (
        studentEvenets?.isError ? (
          <span className="text-danger">Something went wrong load events </span>
        ) : studentEvenets.isLoading ? (
          <ListLoader />
        ) : (
          studentEvenets?.data?.map((items, index) => (
            <div
              className={`${style.scheduleCard} d-flex justify-content-between gap-4 mt-4`}
              style={{
                padding: "1rem",
                borderLeft: `13px solid #374557`,
                borderRadius: "10px",
              }}
              key={index}
            >
              <div className="d-flex flex-column gap-2">
                <h5
                  style={
                    darkmode
                      ? {
                          color: DarkColors.headingcolor,
                          fontWeight: "700",
                        }
                      : {
                          color: LightColors.headingcolor,
                          fontWeight: "700",
                        }
                  }
                  className={style.scheduleJobs}
                >
                  {items.title}
                </h5>
                <span className="d-flex align-items-center justify-centent-start gap-2">
                  <img
                    src={items.profileImg}
                    style={{
                      width: "2rem",
                      borderRadius: "7px",
                      height: "2rem",
                    }}
                    className={style.scheduleImg}
                    alt={items.img}
                  />
                  <p
                    className={`${style.scheduleNames} m-0`}
                    style={{ color: "#A098AE" }}
                  >
                    {items.username}
                  </p>
                </span>
              </div>
              <div
                className={`${style.scheduleRightSide} d-flex justify-content-between align-items-center gap-3`}
              >
                <span className="d-flex align-items-center gap-1">
                  <FontAwesomeIcon
                    icon={faCalendar}
                    style={{
                      color: "#A098AE",
                    }}
                    className={style.scheduleSVG}
                  />
                  <p
                    className={`${style.scheduleTimes} m-0`}
                    style={{ color: "#A098AE" }}
                  >
                    {items.date}
                  </p>
                </span>
                <span className="d-flex align-items-center gap-1">
                  <FontAwesomeIcon
                    icon={faClock}
                    style={{
                      color: "#A098AE",
                    }}
                    className={style.scheduleSVG}
                  />
                  <p
                    style={{ color: "#A098AE" }}
                    className={`${style.scheduleTimes} m-0`}
                  >
                    {items.startTime} {items.endTime}
                  </p>
                </span>
              </div>
            </div>
          ))
        )
      ) : null}

      {deletePopup && (
        <DeletePopup
          deleteFun={HandledeleteEvent}
          setDeletePopup={setDeletePopup}
        />
      )}
      {showModal && (
        <div className="modalDiv">
          <span
            className="modalSpan"
            style={
              darkmode
                ? {
                    background: DarkColors.bgsecondarycolordark,
                  }
                : { background: LightColors.bgsecondarycolorlight }
            }
          >
            <UpdateEventModal
              setShowModal={setShowModal}
              eventDetail={updateEvent}
            />
          </span>
        </div>
      )}
    </main>
  );
}

export default UpcomingSchedule;
