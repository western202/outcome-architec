import React from "react";
import { Row } from "react-bootstrap";
import UpcomingSchedule from "./ScheduleRightComp/UpcomingSchedule";

function ScheduleRight() {
  return (
    <div>
      <Row className="mt-5">
        <UpcomingSchedule />
      </Row>
    </div>
  );
}

export default ScheduleRight;
