import React from "react";
import style from "./scheduleMid.module.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faChevronRight } from "@fortawesome/free-solid-svg-icons";
import { Container, Row, Col } from "react-bootstrap";
import Loading from "../../../../components/Loading/Loading";
import Celender from "../../../../components/Celender/Celender";
import Circularchart from "../../../../components/Charts/Circularchart";
import { useState } from "react";
import { DarkContext } from "../../../../Context/DarkContext";
import { useContext } from "react";
import { useEffect } from "react";
import { DarkColors, LightColors } from "../../../../Utils/Colors";
import AddEventModal from "../../../../components/Modal/AddEventModal";

function ScheduleMid() {
  const [showModal, setShowModal] = useState(false);
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  //   get instructor Id
  const data = JSON.parse(localStorage.getItem("user"));
  const userRole = data?.user?.role?.[0];

  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);
  return (
    <>
      <Container
        fluid
        style={
          darkmode
            ? {
                marginTop: "2rem",
                background: DarkColors.bgsecondarycolordark,
                padding: "2rem",
                borderRadius: "10px",
                height: "84vh",
                overflowY: "scroll",
              }
            : {
                marginTop: "2rem",
                background: LightColors.bgsecondarycolorlight,
                padding: "2rem",
                borderRadius: "10px",
                height: "84vh",
                overflowY: "scroll",
              }
        }
      >
        <div className="mb-5">
          <div className="d-flex justify-content-between align-items-center mb-5">
            <h2
              style={
                darkmode
                  ? {
                      fontWeight: "700",
                      color: DarkColors.headingcolor,
                    }
                  : {
                      fontWeight: "700",
                      color: LightColors.headingcolor,
                    }
              }
            >
              Ongoing Class
            </h2>
            {userRole === "Instructor" && (
              <button
                className={style.add_event_btn}
                onClick={() => setShowModal(true)}
              >
                Add Event
              </button>
            )}
          </div>
          <Row className="mt-5">
            <Col className="d-flex justify-content-evenly align-items-center gap-4">
              <div className={style.percent}>75%</div>
              <div>
                <p
                  className="m-0"
                  style={
                    darkmode
                      ? {
                          color: DarkColors.fonttextcolordark,
                          fontWeight: "700",
                        }
                      : {
                          color: LightColors.fonttextcolorlight,
                          fontWeight: "700",
                        }
                  }
                >
                  Basic
                </p>
                <Loading barcolor={"#6AA22C"} percent={75} />
              </div>
              <FontAwesomeIcon
                icon={faChevronRight}
                style={{ color: "#6AA22C" }}
              />
            </Col>
            <Col className="d-flex justify-content-evenly align-items-center gap-4">
              <div className={style.percent}>50%</div>
              <div>
                <p
                  className="m-0"
                  style={
                    darkmode
                      ? {
                          color: DarkColors.fonttextcolordark,
                          fontWeight: "700",
                        }
                      : {
                          color: LightColors.fonttextcolorlight,
                          fontWeight: "700",
                        }
                  }
                >
                  Basic
                </p>
                <Loading barcolor={"#FEC64F"} percent={50} />
              </div>
              <FontAwesomeIcon
                icon={faChevronRight}
                style={{ color: "#FEC64F" }}
              />
            </Col>
          </Row>
        </div>
        <div>
          <Celender />
          <Row
            style={{ marginTop: "3rem" }}
            className="d-flex flex-column align-items-center gap-2"
          >
            <p style={{ color: "#A098AE", width: "auto" }}>
              Your Progress This Month
            </p>
            <Circularchart percentage={25} />
            <p className="m-o text-center w-auto" style={{ color: "#A098AE" }}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do.
            </p>
          </Row>
        </div>
      </Container>
      {showModal && (
        <div className="modalDiv">
          <span
            className="modalSpan"
            style={
              darkmode
                ? {
                    background: DarkColors.bgsecondarycolordark,
                  }
                : { background: LightColors.bgsecondarycolorlight }
            }
          >
            <AddEventModal setShowModal={setShowModal} />
          </span>
        </div>
      )}
    </>
  );
}

export default ScheduleMid;
