import React, { useContext, useEffect, useState } from "react";
import HomeLeft from "../../components/HomeComp/HomeLeft";
import Header from "../../components/Others/Header";
import { Col, Container, Row } from "react-bootstrap";
import style from "./schedule.module.css";
import ScheduleRight from "./ScheduleComp/ScheduleRight/ScheduleRight";
import ScheduleMid from "./ScheduleComp/ScheduleMid/ScheduleMid";
import { DarkContext } from "../../Context/DarkContext";
import { DarkColors, LightColors } from "../../Utils/Colors";

function Schedule() {
  const [darkmode, setDarkMode] = useState();
  const { themeMode } = useContext(DarkContext);
  useEffect(() => {
    setDarkMode(JSON.parse(localStorage.getItem("isdarkmode")));
  }, [themeMode]);
  return (
    <>
      <div
        className={style.ScheduleWrapper}
        style={
          darkmode
            ? { background: DarkColors.bgcolordark }
            : { background: LightColors.bgcolorlight }
        }
      >
        <Header pageName={"Schedule"} />
        <Container fluid className="p-0">
          <Row>
            <Col
              lg="3"
              style={
                darkmode
                  ? {
                      borderTop: "1px solid black",
                      padding: "0rem",
                    }
                  : {
                      backgroundColor: "white",
                      borderTop: "1px solid #0000001a",
                      padding: "0rem",
                    }
              }
            >
              <HomeLeft />
            </Col>
            <Col lg="5" className={style.ScheduleMidWrapper}>
              <ScheduleMid />
            </Col>
            <Col
              lg="4"
              className={`${style.scheduleRight} p-3`}
              style={
                darkmode
                  ? { background: DarkColors.bgsecondarycolordark }
                  : { background: LightColors.bgsecondarycolorlight }
              }
            >
              <ScheduleRight />
            </Col>
          </Row>
        </Container>
      </div>
    </>
  );
}

export default Schedule;
